import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_place_picker.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/place.dart';
import 'dart:io';
import 'dart:ui';
import '/actions/actions.dart' as action_blocks;
import '/flutter_flow/permissions_util.dart';
import '/index.dart';
import 'discovery_preferences_widget.dart' show DiscoveryPreferencesWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class DiscoveryPreferencesModel
    extends FlutterFlowModel<DiscoveryPreferencesWidget> {
  ///  Local state fields for this page.

  double? pickedLat;

  double? pickedLon;

  String? pickedCity;

  /// minimum age preference
  double? minAge;

  /// maximum age preference
  double? maxAge;

  /// distance preference in km
  double? distanceKm;

  ///  State fields for stateful widgets in this page.

  // State field(s) for Switch widget.
  bool? switchValue;
  // Stores action output result for [Action Block - GetCurrentLocation] action in Switch widget.
  LatLng? currentLocation;
  // State field(s) for PlacePicker widget.
  FFPlace placePickerValue = FFPlace();
  // State field(s) for Slider widget.
  double? sliderValue1;
  // State field(s) for Slider widget.
  double? sliderValue2;
  // State field(s) for MaxAgeSlider widget.
  double? maxAgeSliderValue;

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
