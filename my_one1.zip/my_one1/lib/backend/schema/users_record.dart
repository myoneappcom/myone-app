import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class UsersRecord extends FirestoreRecord {
  UsersRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "email" field.
  String? _email;
  String get email => _email ?? '';
  bool hasEmail() => _email != null;

  // "photo_url" field.
  String? _photoUrl;
  String get photoUrl => _photoUrl ?? '';
  bool hasPhotoUrl() => _photoUrl != null;

  // "uid" field.
  String? _uid;
  String get uid => _uid ?? '';
  bool hasUid() => _uid != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "phone_number" field.
  String? _phoneNumber;
  String get phoneNumber => _phoneNumber ?? '';
  bool hasPhoneNumber() => _phoneNumber != null;

  // "height_cm" field.
  int? _heightCm;
  int get heightCm => _heightCm ?? 0;
  bool hasHeightCm() => _heightCm != null;

  // "weight_kg" field.
  int? _weightKg;
  int get weightKg => _weightKg ?? 0;
  bool hasWeightKg() => _weightKg != null;

  // "company" field.
  String? _company;
  String get company => _company ?? '';
  bool hasCompany() => _company != null;

  // "school" field.
  String? _school;
  String get school => _school ?? '';
  bool hasSchool() => _school != null;

  // "living_in" field.
  String? _livingIn;
  String get livingIn => _livingIn ?? '';
  bool hasLivingIn() => _livingIn != null;

  // "values_beliefs" field.
  String? _valuesBeliefs;
  String get valuesBeliefs => _valuesBeliefs ?? '';
  bool hasValuesBeliefs() => _valuesBeliefs != null;

  // "my_kind_of_date" field.
  String? _myKindOfDate;
  String get myKindOfDate => _myKindOfDate ?? '';
  bool hasMyKindOfDate() => _myKindOfDate != null;

  // "sleeping_habits" field.
  String? _sleepingHabits;
  String get sleepingHabits => _sleepingHabits ?? '';
  bool hasSleepingHabits() => _sleepingHabits != null;

  // "languages" field.
  List<String>? _languages;
  List<String> get languages => _languages ?? const [];
  bool hasLanguages() => _languages != null;

  // "relationship_intentions" field.
  String? _relationshipIntentions;
  String get relationshipIntentions => _relationshipIntentions ?? '';
  bool hasRelationshipIntentions() => _relationshipIntentions != null;

  // "family_plans" field.
  String? _familyPlans;
  String get familyPlans => _familyPlans ?? '';
  bool hasFamilyPlans() => _familyPlans != null;

  // "personality_traits" field.
  String? _personalityTraits;
  String get personalityTraits => _personalityTraits ?? '';
  bool hasPersonalityTraits() => _personalityTraits != null;

  // "workout" field.
  String? _workout;
  String get workout => _workout ?? '';
  bool hasWorkout() => _workout != null;

  // "smoking" field.
  String? _smoking;
  String get smoking => _smoking ?? '';
  bool hasSmoking() => _smoking != null;

  // "drinking" field.
  String? _drinking;
  String get drinking => _drinking ?? '';
  bool hasDrinking() => _drinking != null;

  // "bio" field.
  String? _bio;
  String get bio => _bio ?? '';
  bool hasBio() => _bio != null;

  // "birthday" field.
  DateTime? _birthday;
  DateTime? get birthday => _birthday;
  bool hasBirthday() => _birthday != null;

  // "gender" field.
  String? _gender;
  String get gender => _gender ?? '';
  bool hasGender() => _gender != null;

  // "looking_for" field.
  String? _lookingFor;
  String get lookingFor => _lookingFor ?? '';
  bool hasLookingFor() => _lookingFor != null;

  // "name" field.
  String? _name;
  String get name => _name ?? '';
  bool hasName() => _name != null;

  // "intentions" field.
  String? _intentions;
  String get intentions => _intentions ?? '';
  bool hasIntentions() => _intentions != null;

  // "display_name" field.
  String? _displayName;
  String get displayName => _displayName ?? '';
  bool hasDisplayName() => _displayName != null;

  // "love_language" field.
  String? _loveLanguage;
  String get loveLanguage => _loveLanguage ?? '';
  bool hasLoveLanguage() => _loveLanguage != null;

  // "passed_users" field.
  List<DocumentReference>? _passedUsers;
  List<DocumentReference> get passedUsers => _passedUsers ?? const [];
  bool hasPassedUsers() => _passedUsers != null;

  // "liked_users" field.
  List<DocumentReference>? _likedUsers;
  List<DocumentReference> get likedUsers => _likedUsers ?? const [];
  bool hasLikedUsers() => _likedUsers != null;

  // "superliked_users" field.
  List<DocumentReference>? _superlikedUsers;
  List<DocumentReference> get superlikedUsers => _superlikedUsers ?? const [];
  bool hasSuperlikedUsers() => _superlikedUsers != null;

  // "location" field.
  LatLng? _location;
  LatLng? get location => _location;
  bool hasLocation() => _location != null;

  // "isActive" field.
  bool? _isActive;
  bool get isActive => _isActive ?? false;
  bool hasIsActive() => _isActive != null;

  // "Message" field.
  String? _message;
  String get message => _message ?? '';
  bool hasMessage() => _message != null;

  // "NumberMessage" field.
  int? _numberMessage;
  int get numberMessage => _numberMessage ?? 0;
  bool hasNumberMessage() => _numberMessage != null;

  // "is_verified" field.
  bool? _isVerified;
  bool get isVerified => _isVerified ?? false;
  bool hasIsVerified() => _isVerified != null;

  // "min_age_preference" field.
  int? _minAgePreference;
  int get minAgePreference => _minAgePreference ?? 0;
  bool hasMinAgePreference() => _minAgePreference != null;

  // "max_age_preference" field.
  int? _maxAgePreference;
  int get maxAgePreference => _maxAgePreference ?? 0;
  bool hasMaxAgePreference() => _maxAgePreference != null;

  // "max_distance_preference" field.
  int? _maxDistancePreference;
  int get maxDistancePreference => _maxDistancePreference ?? 0;
  bool hasMaxDistancePreference() => _maxDistancePreference != null;

  // "job_title" field.
  String? _jobTitle;
  String get jobTitle => _jobTitle ?? '';
  bool hasJobTitle() => _jobTitle != null;

  // "boost_left" field.
  int? _boostLeft;
  int get boostLeft => _boostLeft ?? 0;
  bool hasBoostLeft() => _boostLeft != null;

  // "last_active" field.
  DateTime? _lastActive;
  DateTime? get lastActive => _lastActive;
  bool hasLastActive() => _lastActive != null;

  // "matches" field.
  List<DocumentReference>? _matches;
  List<DocumentReference> get matches => _matches ?? const [];
  bool hasMatches() => _matches != null;

  // "liked_by_users" field.
  List<DocumentReference>? _likedByUsers;
  List<DocumentReference> get likedByUsers => _likedByUsers ?? const [];
  bool hasLikedByUsers() => _likedByUsers != null;

  // "location_enabled" field.
  bool? _locationEnabled;
  bool get locationEnabled => _locationEnabled ?? false;
  bool hasLocationEnabled() => _locationEnabled != null;

  // "education" field.
  String? _education;
  String get education => _education ?? '';
  bool hasEducation() => _education != null;

  // "photo1" field.
  String? _photo1;
  String get photo1 => _photo1 ?? '';
  bool hasPhoto1() => _photo1 != null;

  // "photo2" field.
  String? _photo2;
  String get photo2 => _photo2 ?? '';
  bool hasPhoto2() => _photo2 != null;

  // "photo3" field.
  String? _photo3;
  String get photo3 => _photo3 ?? '';
  bool hasPhoto3() => _photo3 != null;

  // "photo4" field.
  String? _photo4;
  String get photo4 => _photo4 ?? '';
  bool hasPhoto4() => _photo4 != null;

  // "photo5" field.
  String? _photo5;
  String get photo5 => _photo5 ?? '';
  bool hasPhoto5() => _photo5 != null;

  // "blocked_users" field.
  List<String>? _blockedUsers;
  List<String> get blockedUsers => _blockedUsers ?? const [];
  bool hasBlockedUsers() => _blockedUsers != null;

  // "reported_users" field.
  List<String>? _reportedUsers;
  List<String> get reportedUsers => _reportedUsers ?? const [];
  bool hasReportedUsers() => _reportedUsers != null;

  // "min_age_pref" field.
  double? _minAgePref;
  double get minAgePref => _minAgePref ?? 0.0;
  bool hasMinAgePref() => _minAgePref != null;

  // "max_age_pref" field.
  double? _maxAgePref;
  double get maxAgePref => _maxAgePref ?? 0.0;
  bool hasMaxAgePref() => _maxAgePref != null;

  // "max_distance_pref" field.
  double? _maxDistancePref;
  double get maxDistancePref => _maxDistancePref ?? 0.0;
  bool hasMaxDistancePref() => _maxDistancePref != null;

  // "age" field.
  double? _age;
  double get age => _age ?? 0.0;
  bool hasAge() => _age != null;

  // "distance" field.
  double? _distance;
  double get distance => _distance ?? 0.0;
  bool hasDistance() => _distance != null;

  // "latitude" field.
  double? _latitude;
  double get latitude => _latitude ?? 0.0;
  bool hasLatitude() => _latitude != null;

  // "longitude" field.
  double? _longitude;
  double get longitude => _longitude ?? 0.0;
  bool hasLongitude() => _longitude != null;

  // "travel_enabled" field.
  bool? _travelEnabled;
  bool get travelEnabled => _travelEnabled ?? false;
  bool hasTravelEnabled() => _travelEnabled != null;

  // "travel_lat" field.
  double? _travelLat;
  double get travelLat => _travelLat ?? 0.0;
  bool hasTravelLat() => _travelLat != null;

  // "travel_lon" field.
  double? _travelLon;
  double get travelLon => _travelLon ?? 0.0;
  bool hasTravelLon() => _travelLon != null;

  // "travel_city" field.
  String? _travelCity;
  String get travelCity => _travelCity ?? '';
  bool hasTravelCity() => _travelCity != null;

  // "get_current_location" field.
  double? _getCurrentLocation;
  double get getCurrentLocation => _getCurrentLocation ?? 0.0;
  bool hasGetCurrentLocation() => _getCurrentLocation != null;

  void _initializeFields() {
    _email = snapshotData['email'] as String?;
    _photoUrl = snapshotData['photo_url'] as String?;
    _uid = snapshotData['uid'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _phoneNumber = snapshotData['phone_number'] as String?;
    _heightCm = castToType<int>(snapshotData['height_cm']);
    _weightKg = castToType<int>(snapshotData['weight_kg']);
    _company = snapshotData['company'] as String?;
    _school = snapshotData['school'] as String?;
    _livingIn = snapshotData['living_in'] as String?;
    _valuesBeliefs = snapshotData['values_beliefs'] as String?;
    _myKindOfDate = snapshotData['my_kind_of_date'] as String?;
    _sleepingHabits = snapshotData['sleeping_habits'] as String?;
    _languages = getDataList(snapshotData['languages']);
    _relationshipIntentions =
        snapshotData['relationship_intentions'] as String?;
    _familyPlans = snapshotData['family_plans'] as String?;
    _personalityTraits = snapshotData['personality_traits'] as String?;
    _workout = snapshotData['workout'] as String?;
    _smoking = snapshotData['smoking'] as String?;
    _drinking = snapshotData['drinking'] as String?;
    _bio = snapshotData['bio'] as String?;
    _birthday = snapshotData['birthday'] as DateTime?;
    _gender = snapshotData['gender'] as String?;
    _lookingFor = snapshotData['looking_for'] as String?;
    _name = snapshotData['name'] as String?;
    _intentions = snapshotData['intentions'] as String?;
    _displayName = snapshotData['display_name'] as String?;
    _loveLanguage = snapshotData['love_language'] as String?;
    _passedUsers = getDataList(snapshotData['passed_users']);
    _likedUsers = getDataList(snapshotData['liked_users']);
    _superlikedUsers = getDataList(snapshotData['superliked_users']);
    _location = snapshotData['location'] as LatLng?;
    _isActive = snapshotData['isActive'] as bool?;
    _message = snapshotData['Message'] as String?;
    _numberMessage = castToType<int>(snapshotData['NumberMessage']);
    _isVerified = snapshotData['is_verified'] as bool?;
    _minAgePreference = castToType<int>(snapshotData['min_age_preference']);
    _maxAgePreference = castToType<int>(snapshotData['max_age_preference']);
    _maxDistancePreference =
        castToType<int>(snapshotData['max_distance_preference']);
    _jobTitle = snapshotData['job_title'] as String?;
    _boostLeft = castToType<int>(snapshotData['boost_left']);
    _lastActive = snapshotData['last_active'] as DateTime?;
    _matches = getDataList(snapshotData['matches']);
    _likedByUsers = getDataList(snapshotData['liked_by_users']);
    _locationEnabled = snapshotData['location_enabled'] as bool?;
    _education = snapshotData['education'] as String?;
    _photo1 = snapshotData['photo1'] as String?;
    _photo2 = snapshotData['photo2'] as String?;
    _photo3 = snapshotData['photo3'] as String?;
    _photo4 = snapshotData['photo4'] as String?;
    _photo5 = snapshotData['photo5'] as String?;
    _blockedUsers = getDataList(snapshotData['blocked_users']);
    _reportedUsers = getDataList(snapshotData['reported_users']);
    _minAgePref = castToType<double>(snapshotData['min_age_pref']);
    _maxAgePref = castToType<double>(snapshotData['max_age_pref']);
    _maxDistancePref = castToType<double>(snapshotData['max_distance_pref']);
    _age = castToType<double>(snapshotData['age']);
    _distance = castToType<double>(snapshotData['distance']);
    _latitude = castToType<double>(snapshotData['latitude']);
    _longitude = castToType<double>(snapshotData['longitude']);
    _travelEnabled = snapshotData['travel_enabled'] as bool?;
    _travelLat = castToType<double>(snapshotData['travel_lat']);
    _travelLon = castToType<double>(snapshotData['travel_lon']);
    _travelCity = snapshotData['travel_city'] as String?;
    _getCurrentLocation =
        castToType<double>(snapshotData['get_current_location']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('users');

  static Stream<UsersRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => UsersRecord.fromSnapshot(s));

  static Future<UsersRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => UsersRecord.fromSnapshot(s));

  static UsersRecord fromSnapshot(DocumentSnapshot snapshot) => UsersRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static UsersRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      UsersRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'UsersRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is UsersRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createUsersRecordData({
  String? email,
  String? photoUrl,
  String? uid,
  DateTime? createdTime,
  String? phoneNumber,
  int? heightCm,
  int? weightKg,
  String? company,
  String? school,
  String? livingIn,
  String? valuesBeliefs,
  String? myKindOfDate,
  String? sleepingHabits,
  String? relationshipIntentions,
  String? familyPlans,
  String? personalityTraits,
  String? workout,
  String? smoking,
  String? drinking,
  String? bio,
  DateTime? birthday,
  String? gender,
  String? lookingFor,
  String? name,
  String? intentions,
  String? displayName,
  String? loveLanguage,
  LatLng? location,
  bool? isActive,
  String? message,
  int? numberMessage,
  bool? isVerified,
  int? minAgePreference,
  int? maxAgePreference,
  int? maxDistancePreference,
  String? jobTitle,
  int? boostLeft,
  DateTime? lastActive,
  bool? locationEnabled,
  String? education,
  String? photo1,
  String? photo2,
  String? photo3,
  String? photo4,
  String? photo5,
  double? minAgePref,
  double? maxAgePref,
  double? maxDistancePref,
  double? age,
  double? distance,
  double? latitude,
  double? longitude,
  bool? travelEnabled,
  double? travelLat,
  double? travelLon,
  String? travelCity,
  double? getCurrentLocation,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'email': email,
      'photo_url': photoUrl,
      'uid': uid,
      'created_time': createdTime,
      'phone_number': phoneNumber,
      'height_cm': heightCm,
      'weight_kg': weightKg,
      'company': company,
      'school': school,
      'living_in': livingIn,
      'values_beliefs': valuesBeliefs,
      'my_kind_of_date': myKindOfDate,
      'sleeping_habits': sleepingHabits,
      'relationship_intentions': relationshipIntentions,
      'family_plans': familyPlans,
      'personality_traits': personalityTraits,
      'workout': workout,
      'smoking': smoking,
      'drinking': drinking,
      'bio': bio,
      'birthday': birthday,
      'gender': gender,
      'looking_for': lookingFor,
      'name': name,
      'intentions': intentions,
      'display_name': displayName,
      'love_language': loveLanguage,
      'location': location,
      'isActive': isActive,
      'Message': message,
      'NumberMessage': numberMessage,
      'is_verified': isVerified,
      'min_age_preference': minAgePreference,
      'max_age_preference': maxAgePreference,
      'max_distance_preference': maxDistancePreference,
      'job_title': jobTitle,
      'boost_left': boostLeft,
      'last_active': lastActive,
      'location_enabled': locationEnabled,
      'education': education,
      'photo1': photo1,
      'photo2': photo2,
      'photo3': photo3,
      'photo4': photo4,
      'photo5': photo5,
      'min_age_pref': minAgePref,
      'max_age_pref': maxAgePref,
      'max_distance_pref': maxDistancePref,
      'age': age,
      'distance': distance,
      'latitude': latitude,
      'longitude': longitude,
      'travel_enabled': travelEnabled,
      'travel_lat': travelLat,
      'travel_lon': travelLon,
      'travel_city': travelCity,
      'get_current_location': getCurrentLocation,
    }.withoutNulls,
  );

  return firestoreData;
}

class UsersRecordDocumentEquality implements Equality<UsersRecord> {
  const UsersRecordDocumentEquality();

  @override
  bool equals(UsersRecord? e1, UsersRecord? e2) {
    const listEquality = ListEquality();
    return e1?.email == e2?.email &&
        e1?.photoUrl == e2?.photoUrl &&
        e1?.uid == e2?.uid &&
        e1?.createdTime == e2?.createdTime &&
        e1?.phoneNumber == e2?.phoneNumber &&
        e1?.heightCm == e2?.heightCm &&
        e1?.weightKg == e2?.weightKg &&
        e1?.company == e2?.company &&
        e1?.school == e2?.school &&
        e1?.livingIn == e2?.livingIn &&
        e1?.valuesBeliefs == e2?.valuesBeliefs &&
        e1?.myKindOfDate == e2?.myKindOfDate &&
        e1?.sleepingHabits == e2?.sleepingHabits &&
        listEquality.equals(e1?.languages, e2?.languages) &&
        e1?.relationshipIntentions == e2?.relationshipIntentions &&
        e1?.familyPlans == e2?.familyPlans &&
        e1?.personalityTraits == e2?.personalityTraits &&
        e1?.workout == e2?.workout &&
        e1?.smoking == e2?.smoking &&
        e1?.drinking == e2?.drinking &&
        e1?.bio == e2?.bio &&
        e1?.birthday == e2?.birthday &&
        e1?.gender == e2?.gender &&
        e1?.lookingFor == e2?.lookingFor &&
        e1?.name == e2?.name &&
        e1?.intentions == e2?.intentions &&
        e1?.displayName == e2?.displayName &&
        e1?.loveLanguage == e2?.loveLanguage &&
        listEquality.equals(e1?.passedUsers, e2?.passedUsers) &&
        listEquality.equals(e1?.likedUsers, e2?.likedUsers) &&
        listEquality.equals(e1?.superlikedUsers, e2?.superlikedUsers) &&
        e1?.location == e2?.location &&
        e1?.isActive == e2?.isActive &&
        e1?.message == e2?.message &&
        e1?.numberMessage == e2?.numberMessage &&
        e1?.isVerified == e2?.isVerified &&
        e1?.minAgePreference == e2?.minAgePreference &&
        e1?.maxAgePreference == e2?.maxAgePreference &&
        e1?.maxDistancePreference == e2?.maxDistancePreference &&
        e1?.jobTitle == e2?.jobTitle &&
        e1?.boostLeft == e2?.boostLeft &&
        e1?.lastActive == e2?.lastActive &&
        listEquality.equals(e1?.matches, e2?.matches) &&
        listEquality.equals(e1?.likedByUsers, e2?.likedByUsers) &&
        e1?.locationEnabled == e2?.locationEnabled &&
        e1?.education == e2?.education &&
        e1?.photo1 == e2?.photo1 &&
        e1?.photo2 == e2?.photo2 &&
        e1?.photo3 == e2?.photo3 &&
        e1?.photo4 == e2?.photo4 &&
        e1?.photo5 == e2?.photo5 &&
        listEquality.equals(e1?.blockedUsers, e2?.blockedUsers) &&
        listEquality.equals(e1?.reportedUsers, e2?.reportedUsers) &&
        e1?.minAgePref == e2?.minAgePref &&
        e1?.maxAgePref == e2?.maxAgePref &&
        e1?.maxDistancePref == e2?.maxDistancePref &&
        e1?.age == e2?.age &&
        e1?.distance == e2?.distance &&
        e1?.latitude == e2?.latitude &&
        e1?.longitude == e2?.longitude &&
        e1?.travelEnabled == e2?.travelEnabled &&
        e1?.travelLat == e2?.travelLat &&
        e1?.travelLon == e2?.travelLon &&
        e1?.travelCity == e2?.travelCity &&
        e1?.getCurrentLocation == e2?.getCurrentLocation;
  }

  @override
  int hash(UsersRecord? e) => const ListEquality().hash([
        e?.email,
        e?.photoUrl,
        e?.uid,
        e?.createdTime,
        e?.phoneNumber,
        e?.heightCm,
        e?.weightKg,
        e?.company,
        e?.school,
        e?.livingIn,
        e?.valuesBeliefs,
        e?.myKindOfDate,
        e?.sleepingHabits,
        e?.languages,
        e?.relationshipIntentions,
        e?.familyPlans,
        e?.personalityTraits,
        e?.workout,
        e?.smoking,
        e?.drinking,
        e?.bio,
        e?.birthday,
        e?.gender,
        e?.lookingFor,
        e?.name,
        e?.intentions,
        e?.displayName,
        e?.loveLanguage,
        e?.passedUsers,
        e?.likedUsers,
        e?.superlikedUsers,
        e?.location,
        e?.isActive,
        e?.message,
        e?.numberMessage,
        e?.isVerified,
        e?.minAgePreference,
        e?.maxAgePreference,
        e?.maxDistancePreference,
        e?.jobTitle,
        e?.boostLeft,
        e?.lastActive,
        e?.matches,
        e?.likedByUsers,
        e?.locationEnabled,
        e?.education,
        e?.photo1,
        e?.photo2,
        e?.photo3,
        e?.photo4,
        e?.photo5,
        e?.blockedUsers,
        e?.reportedUsers,
        e?.minAgePref,
        e?.maxAgePref,
        e?.maxDistancePref,
        e?.age,
        e?.distance,
        e?.latitude,
        e?.longitude,
        e?.travelEnabled,
        e?.travelLat,
        e?.travelLon,
        e?.travelCity,
        e?.getCurrentLocation
      ]);

  @override
  bool isValidKey(Object? o) => o is UsersRecord;
}
