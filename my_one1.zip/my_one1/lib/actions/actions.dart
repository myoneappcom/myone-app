import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/actions/actions.dart' as action_blocks;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

Future<LatLng?> getCurrentLocation(BuildContext context) async {
  await action_blocks.getCurrentLocation(context);

  return null;
}

Future setTravelFromPlacePicker(
  BuildContext context, {
  double? travelLat,
  double? travelLon,
  String? travelCity,
}) async {
  await currentUserReference!.update(createUsersRecordData(
    travelEnabled: true,
    travelLat: travelLat,
    travelLon: travelLon,
    travelCity: travelCity,
  ));
}
