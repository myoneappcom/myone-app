// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/actions/actions.dart' as action_blocks;
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:just_audio/just_audio.dart';

class CustomAudioPlayer extends StatefulWidget {
  const CustomAudioPlayer({
    Key? key,
    this.audioPath =
        'https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3',
    this.width,
    this.height,
  }) : super(key: key);

  final String audioPath;
  final double? width;
  final double? height;

  @override
  State<CustomAudioPlayer> createState() => _CustomAudioPlayerState();
}

class _CustomAudioPlayerState extends State<CustomAudioPlayer> {
  late AudioPlayer _audioPlayer;
  Duration _position = Duration.zero;
  Duration _duration = Duration.zero;
  bool _isPlaying = false;
  bool _isDragging = false;
  double? _dragProgress;

  final List<double> _waveformHeights = [
    12,
    8,
    16,
    4,
    20,
    10,
    24,
    6,
    28,
    12,
    32,
    16,
    28,
    20,
    24,
    12,
    20,
    8,
    16,
    4,
    12,
    8,
    16,
    20,
    24,
    12,
    28,
    16,
    32,
    8,
  ];

  @override
  void initState() {
    super.initState();
    _audioPlayer = AudioPlayer();
    _initAudio();
    _setupListeners();
  }

  Future<void> _initAudio() async {
    try {
      await _audioPlayer.setUrl(widget.audioPath);
    } catch (e) {
      debugPrint('Audio init error: $e');
    }
  }

  void _setupListeners() {
    _audioPlayer.positionStream.listen((pos) {
      if (!_isDragging && mounted) {
        setState(() => _position = pos);
      }
    });

    _audioPlayer.durationStream.listen((dur) {
      if (dur != null && mounted) {
        setState(() => _duration = dur);
      }
    });

    _audioPlayer.playerStateStream.listen((state) {
      if (!mounted) return;
      setState(() => _isPlaying = state.playing);

      if (state.processingState == ProcessingState.completed) {
        _audioPlayer.seek(Duration.zero);
        _audioPlayer.pause();
        setState(() => _position = Duration.zero);
      }
    });
  }

  Future<void> _togglePlayPause() async {
    if (_isPlaying) {
      await _audioPlayer.pause();
    } else {
      if (_audioPlayer.processingState != ProcessingState.ready) {
        await _initAudio();
      }
      await _audioPlayer.play();
    }
  }

  Future<void> _seekToProgress(double progress) async {
    final newPos = _duration * progress;
    await _audioPlayer.seek(newPos);
  }

  String _formatTime(Duration d) {
    final minutes = d.inMinutes.toString().padLeft(2, '0');
    final seconds = (d.inSeconds % 60).toString().padLeft(2, '0');
    return '$minutes:$seconds';
  }

  @override
  void dispose() {
    _audioPlayer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;
    final effectiveProgress = _duration.inMilliseconds == 0
        ? 0.0
        : _dragProgress ?? _position.inMilliseconds / _duration.inMilliseconds;

    return Container(
      width: widget.width ?? double.infinity,
      height: widget.height ?? 80,
      padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
      decoration: BoxDecoration(
        color: isDarkMode ? const Color(0xFF2A2A2A) : Colors.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(isDarkMode ? 0.3 : 0.1),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          Material(
            color: const Color(0xFFC156FF),
            shape: const CircleBorder(),
            child: InkWell(
              customBorder: const CircleBorder(),
              onTap: _togglePlayPause,
              child: SizedBox(
                width: 48,
                height: 48,
                child: Center(
                  child: Image.network(
                    _isPlaying
                        ? 'https://storage.googleapis.com/flutterflow-io-6f20.appspot.com/projects/moody-f3k0wb/assets/uw1z1ia538oi/pauseIcon.png'
                        : 'https://storage.googleapis.com/flutterflow-io-6f20.appspot.com/projects/moody-f3k0wb/assets/8drkln350gmo/playIcon.png',
                    width: 18,
                    height: 18,
                    fit: BoxFit.contain,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 12),
          SizedBox(
            width: 50,
            child: Text(
              _formatTime(_dragProgress != null
                  ? _duration * _dragProgress!
                  : _position),
              style: TextStyle(
                fontSize: 14,
                fontWeight: FontWeight.w500,
                color: isDarkMode
                    ? Colors.white.withOpacity(0.8)
                    : const Color(0xFFC156FF),
              ),
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: LayoutBuilder(
              builder: (context, constraints) {
                final waveformWidth = constraints.maxWidth;

                return GestureDetector(
                  onHorizontalDragStart: (_) =>
                      setState(() => _isDragging = true),
                  onHorizontalDragUpdate: (details) {
                    final box = context.findRenderObject() as RenderBox?;
                    if (box != null) {
                      final local = box.globalToLocal(details.globalPosition);
                      final relative =
                          (local.dx / waveformWidth).clamp(0.0, 1.0);
                      setState(() => _dragProgress = relative);
                    }
                  },
                  onHorizontalDragEnd: (_) async {
                    if (_dragProgress != null) {
                      await _seekToProgress(_dragProgress!);
                    }
                    setState(() {
                      _isDragging = false;
                      _dragProgress = null;
                    });
                  },
                  onTapDown: (details) async {
                    final box = context.findRenderObject() as RenderBox?;
                    if (box != null) {
                      final local = box.globalToLocal(details.globalPosition);
                      final relative =
                          (local.dx / waveformWidth).clamp(0.0, 1.0);
                      await _seekToProgress(relative);
                    }
                  },
                  child: Container(
                    height: 40,
                    alignment: Alignment.centerLeft,
                    child: CustomPaint(
                      painter: _WaveformPainter(
                        progress: effectiveProgress,
                        waveformHeights: _waveformHeights,
                        filledColor: const Color(0xFFC156FF),
                        unfilledColor: isDarkMode
                            ? Colors.white.withOpacity(0.2)
                            : Colors.grey.shade400,
                      ),
                      size: Size(waveformWidth, 40),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
    );
  }
}

class _WaveformPainter extends CustomPainter {
  final double progress;
  final List<double> waveformHeights;
  final Color filledColor;
  final Color unfilledColor;

  _WaveformPainter({
    required this.progress,
    required this.waveformHeights,
    required this.filledColor,
    required this.unfilledColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final barWidth = 3.0;
    final spacing = 2.0;
    final totalBars = waveformHeights.length;
    final totalWidth = totalBars * barWidth + (totalBars - 1) * spacing;
    final startX = (size.width - totalWidth) / 2;

    for (var i = 0; i < totalBars; i++) {
      final barHeight = waveformHeights[i];
      final barX = startX + i * (barWidth + spacing);
      final barProgress = i / totalBars;
      final isFilled = barProgress <= progress;

      final paint = Paint()
        ..color = isFilled ? filledColor : unfilledColor
        ..style = PaintingStyle.fill;

      canvas.drawRRect(
        RRect.fromRectAndRadius(
          Rect.fromLTWH(
            barX,
            (size.height - barHeight) / 2,
            barWidth,
            barHeight,
          ),
          const Radius.circular(2),
        ),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant _WaveformPainter oldDelegate) {
    return oldDelegate.progress != progress ||
        oldDelegate.waveformHeights != waveformHeights ||
        oldDelegate.filledColor != filledColor ||
        oldDelegate.unfilledColor != unfilledColor;
  }
}

// Set your widget name, define your parameter, and then add the
// boilerplate code using the green button on the right!
