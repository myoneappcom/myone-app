import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class PushNotificationsRecord extends FirestoreRecord {
  PushNotificationsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "title" field.
  String? _title;
  String get title => _title ?? '';
  bool hasTitle() => _title != null;

  // "receiverld" field.
  String? _receiverld;
  String get receiverld => _receiverld ?? '';
  bool hasReceiverld() => _receiverld != null;

  void _initializeFields() {
    _title = snapshotData['title'] as String?;
    _receiverld = snapshotData['receiverld'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('push_notifications');

  static Stream<PushNotificationsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => PushNotificationsRecord.fromSnapshot(s));

  static Future<PushNotificationsRecord> getDocumentOnce(
          DocumentReference ref) =>
      ref.get().then((s) => PushNotificationsRecord.fromSnapshot(s));

  static PushNotificationsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      PushNotificationsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static PushNotificationsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      PushNotificationsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'PushNotificationsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is PushNotificationsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createPushNotificationsRecordData({
  String? title,
  String? receiverld,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'title': title,
      'receiverld': receiverld,
    }.withoutNulls,
  );

  return firestoreData;
}

class PushNotificationsRecordDocumentEquality
    implements Equality<PushNotificationsRecord> {
  const PushNotificationsRecordDocumentEquality();

  @override
  bool equals(PushNotificationsRecord? e1, PushNotificationsRecord? e2) {
    return e1?.title == e2?.title && e1?.receiverld == e2?.receiverld;
  }

  @override
  int hash(PushNotificationsRecord? e) =>
      const ListEquality().hash([e?.title, e?.receiverld]);

  @override
  bool isValidKey(Object? o) => o is PushNotificationsRecord;
}
