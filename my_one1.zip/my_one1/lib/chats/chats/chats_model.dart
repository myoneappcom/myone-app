import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/chats/components/new_matches/new_matches_widget.dart';
import '/chats/components/skeleton_loading_chats/skeleton_loading_chats_widget.dart';
import '/chats/components/skeleton_loading_match/skeleton_loading_match_widget.dart';
import '/chats/components/skeleton_loading_new_matches/skeleton_loading_new_matches_widget.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/home/navbar/navbar_widget.dart';
import '/matches/components/single_options/single_options_widget.dart';
import 'dart:ui';
import '/index.dart';
import 'chats_widget.dart' show ChatsWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ChatsModel extends FlutterFlowModel<ChatsWidget> {
  ///  State fields for stateful widgets in this page.

  // Models for NewMatches dynamic component.
  late FlutterFlowDynamicModels<NewMatchesModel> newMatchesModels;
  // Stores action output result for [Backend Call - Create Document] action in NewMatches widget.
  ChatsRecord? chatRef;
  // Model for Navbar component.
  late NavbarModel navbarModel;

  @override
  void initState(BuildContext context) {
    newMatchesModels = FlutterFlowDynamicModels(() => NewMatchesModel());
    navbarModel = createModel(context, () => NavbarModel());
  }

  @override
  void dispose() {
    newMatchesModels.dispose();
    navbarModel.dispose();
  }
}
