import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/backend/firebase_storage/storage.dart';
import '/flutter_flow/flutter_flow_choice_chips.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/form_field_controller.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/index.dart';
import 'profile_edit_widget.dart' show ProfileEditWidget;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class ProfileEditModel extends FlutterFlowModel<ProfileEditWidget> {
  ///  State fields for stateful widgets in this page.

  bool isDataUploading_uploadDataH0n = false;
  FFUploadedFile uploadedLocalFile_uploadDataH0n =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl_uploadDataH0n = '';

  bool isDataUploading_uploadDataQqq = false;
  FFUploadedFile uploadedLocalFile_uploadDataQqq =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl_uploadDataQqq = '';

  bool isDataUploading_uploadDataTkx = false;
  FFUploadedFile uploadedLocalFile_uploadDataTkx =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl_uploadDataTkx = '';

  bool isDataUploading_uploadDataFom = false;
  FFUploadedFile uploadedLocalFile_uploadDataFom =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl_uploadDataFom = '';

  bool isDataUploading_uploadDataXiu = false;
  FFUploadedFile uploadedLocalFile_uploadDataXiu =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl_uploadDataXiu = '';

  bool isDataUploading_uploadData8nx = false;
  FFUploadedFile uploadedLocalFile_uploadData8nx =
      FFUploadedFile(bytes: Uint8List.fromList([]));
  String uploadedFileUrl_uploadData8nx = '';

  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode1;
  TextEditingController? textController1;
  String? Function(BuildContext, String?)? textController1Validator;
  // State field(s) for TextField widget.
  FocusNode? textFieldFocusNode2;
  TextEditingController? textController2;
  String? Function(BuildContext, String?)? textController2Validator;
  // State field(s) for IntensionsChips widget.
  FormFieldController<List<String>>? intensionsChipsValueController;
  String? get intensionsChipsValue =>
      intensionsChipsValueController?.value?.firstOrNull;
  set intensionsChipsValue(String? val) =>
      intensionsChipsValueController?.value = val != null ? [val] : [];
  // State field(s) for BioTextField widget.
  FocusNode? bioTextFieldFocusNode;
  TextEditingController? bioTextFieldTextController;
  String? Function(BuildContext, String?)? bioTextFieldTextControllerValidator;
  // State field(s) for FamilyplansChips widget.
  FormFieldController<List<String>>? familyplansChipsValueController;
  String? get familyplansChipsValue =>
      familyplansChipsValueController?.value?.firstOrNull;
  set familyplansChipsValue(String? val) =>
      familyplansChipsValueController?.value = val != null ? [val] : [];
  // State field(s) for PersonalityTraitsChips widget.
  FormFieldController<List<String>>? personalityTraitsChipsValueController;
  String? get personalityTraitsChipsValue =>
      personalityTraitsChipsValueController?.value?.firstOrNull;
  set personalityTraitsChipsValue(String? val) =>
      personalityTraitsChipsValueController?.value = val != null ? [val] : [];
  // State field(s) for LoveLanguageChips widget.
  FormFieldController<List<String>>? loveLanguageChipsValueController;
  String? get loveLanguageChipsValue =>
      loveLanguageChipsValueController?.value?.firstOrNull;
  set loveLanguageChipsValue(String? val) =>
      loveLanguageChipsValueController?.value = val != null ? [val] : [];
  // State field(s) for WorkoutChips widget.
  FormFieldController<List<String>>? workoutChipsValueController;
  String? get workoutChipsValue =>
      workoutChipsValueController?.value?.firstOrNull;
  set workoutChipsValue(String? val) =>
      workoutChipsValueController?.value = val != null ? [val] : [];
  // State field(s) for SmokingChips widget.
  FormFieldController<List<String>>? smokingChipsValueController;
  String? get smokingChipsValue =>
      smokingChipsValueController?.value?.firstOrNull;
  set smokingChipsValue(String? val) =>
      smokingChipsValueController?.value = val != null ? [val] : [];
  // State field(s) for DrinkingChips widget.
  FormFieldController<List<String>>? drinkingChipsValueController;
  String? get drinkingChipsValue =>
      drinkingChipsValueController?.value?.firstOrNull;
  set drinkingChipsValue(String? val) =>
      drinkingChipsValueController?.value = val != null ? [val] : [];

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {
    textFieldFocusNode1?.dispose();
    textController1?.dispose();

    textFieldFocusNode2?.dispose();
    textController2?.dispose();

    bioTextFieldFocusNode?.dispose();
    bioTextFieldTextController?.dispose();
  }
}
