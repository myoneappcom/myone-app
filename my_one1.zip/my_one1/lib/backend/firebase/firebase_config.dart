import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyBEC-e3UL6Ng8cJ8QCJmaM_ZTM0OGFbLK0",
            authDomain: "myone-8893b.firebaseapp.com",
            projectId: "myone-8893b",
            storageBucket: "myone-8893b.firebasestorage.app",
            messagingSenderId: "105765197463",
            appId: "1:105765197463:web:49e909b5a76cef3f827bd2",
            measurementId: "G-PSCB16MD2M"));
  } else {
    await Firebase.initializeApp();
  }
}
