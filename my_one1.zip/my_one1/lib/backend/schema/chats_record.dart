import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class ChatsRecord extends FirestoreRecord {
  ChatsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "userA_id" field.
  String? _userAId;
  String get userAId => _userAId ?? '';
  bool hasUserAId() => _userAId != null;

  // "userB_id" field.
  String? _userBId;
  String get userBId => _userBId ?? '';
  bool hasUserBId() => _userBId != null;

  // "userA_ref" field.
  DocumentReference? _userARef;
  DocumentReference? get userARef => _userARef;
  bool hasUserARef() => _userARef != null;

  // "userB_ref" field.
  DocumentReference? _userBRef;
  DocumentReference? get userBRef => _userBRef;
  bool hasUserBRef() => _userBRef != null;

  // "last_message" field.
  String? _lastMessage;
  String get lastMessage => _lastMessage ?? '';
  bool hasLastMessage() => _lastMessage != null;

  // "last_message_time" field.
  DateTime? _lastMessageTime;
  DateTime? get lastMessageTime => _lastMessageTime;
  bool hasLastMessageTime() => _lastMessageTime != null;

  // "last_sender_id" field.
  String? _lastSenderId;
  String get lastSenderId => _lastSenderId ?? '';
  bool hasLastSenderId() => _lastSenderId != null;

  // "userA_typing" field.
  bool? _userATyping;
  bool get userATyping => _userATyping ?? false;
  bool hasUserATyping() => _userATyping != null;

  // "userB_typing" field.
  bool? _userBTyping;
  bool get userBTyping => _userBTyping ?? false;
  bool hasUserBTyping() => _userBTyping != null;

  // "userA_unread" field.
  int? _userAUnread;
  int get userAUnread => _userAUnread ?? 0;
  bool hasUserAUnread() => _userAUnread != null;

  // "userB_unread" field.
  int? _userBUnread;
  int get userBUnread => _userBUnread ?? 0;
  bool hasUserBUnread() => _userBUnread != null;

  // "liker_id" field.
  String? _likerId;
  String get likerId => _likerId ?? '';
  bool hasLikerId() => _likerId != null;

  // "liker_ref" field.
  DocumentReference? _likerRef;
  DocumentReference? get likerRef => _likerRef;
  bool hasLikerRef() => _likerRef != null;

  // "target_id" field.
  String? _targetId;
  String get targetId => _targetId ?? '';
  bool hasTargetId() => _targetId != null;

  // "created_time" field.
  DateTime? _createdTime;
  DateTime? get createdTime => _createdTime;
  bool hasCreatedTime() => _createdTime != null;

  // "participant_ids" field.
  List<String>? _participantIds;
  List<String> get participantIds => _participantIds ?? const [];
  bool hasParticipantIds() => _participantIds != null;

  // "participants" field.
  List<DocumentReference>? _participants;
  List<DocumentReference> get participants => _participants ?? const [];
  bool hasParticipants() => _participants != null;

  void _initializeFields() {
    _userAId = snapshotData['userA_id'] as String?;
    _userBId = snapshotData['userB_id'] as String?;
    _userARef = snapshotData['userA_ref'] as DocumentReference?;
    _userBRef = snapshotData['userB_ref'] as DocumentReference?;
    _lastMessage = snapshotData['last_message'] as String?;
    _lastMessageTime = snapshotData['last_message_time'] as DateTime?;
    _lastSenderId = snapshotData['last_sender_id'] as String?;
    _userATyping = snapshotData['userA_typing'] as bool?;
    _userBTyping = snapshotData['userB_typing'] as bool?;
    _userAUnread = castToType<int>(snapshotData['userA_unread']);
    _userBUnread = castToType<int>(snapshotData['userB_unread']);
    _likerId = snapshotData['liker_id'] as String?;
    _likerRef = snapshotData['liker_ref'] as DocumentReference?;
    _targetId = snapshotData['target_id'] as String?;
    _createdTime = snapshotData['created_time'] as DateTime?;
    _participantIds = getDataList(snapshotData['participant_ids']);
    _participants = getDataList(snapshotData['participants']);
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('chats');

  static Stream<ChatsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => ChatsRecord.fromSnapshot(s));

  static Future<ChatsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => ChatsRecord.fromSnapshot(s));

  static ChatsRecord fromSnapshot(DocumentSnapshot snapshot) => ChatsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static ChatsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      ChatsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'ChatsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is ChatsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createChatsRecordData({
  String? userAId,
  String? userBId,
  DocumentReference? userARef,
  DocumentReference? userBRef,
  String? lastMessage,
  DateTime? lastMessageTime,
  String? lastSenderId,
  bool? userATyping,
  bool? userBTyping,
  int? userAUnread,
  int? userBUnread,
  String? likerId,
  DocumentReference? likerRef,
  String? targetId,
  DateTime? createdTime,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'userA_id': userAId,
      'userB_id': userBId,
      'userA_ref': userARef,
      'userB_ref': userBRef,
      'last_message': lastMessage,
      'last_message_time': lastMessageTime,
      'last_sender_id': lastSenderId,
      'userA_typing': userATyping,
      'userB_typing': userBTyping,
      'userA_unread': userAUnread,
      'userB_unread': userBUnread,
      'liker_id': likerId,
      'liker_ref': likerRef,
      'target_id': targetId,
      'created_time': createdTime,
    }.withoutNulls,
  );

  return firestoreData;
}

class ChatsRecordDocumentEquality implements Equality<ChatsRecord> {
  const ChatsRecordDocumentEquality();

  @override
  bool equals(ChatsRecord? e1, ChatsRecord? e2) {
    const listEquality = ListEquality();
    return e1?.userAId == e2?.userAId &&
        e1?.userBId == e2?.userBId &&
        e1?.userARef == e2?.userARef &&
        e1?.userBRef == e2?.userBRef &&
        e1?.lastMessage == e2?.lastMessage &&
        e1?.lastMessageTime == e2?.lastMessageTime &&
        e1?.lastSenderId == e2?.lastSenderId &&
        e1?.userATyping == e2?.userATyping &&
        e1?.userBTyping == e2?.userBTyping &&
        e1?.userAUnread == e2?.userAUnread &&
        e1?.userBUnread == e2?.userBUnread &&
        e1?.likerId == e2?.likerId &&
        e1?.likerRef == e2?.likerRef &&
        e1?.targetId == e2?.targetId &&
        e1?.createdTime == e2?.createdTime &&
        listEquality.equals(e1?.participantIds, e2?.participantIds) &&
        listEquality.equals(e1?.participants, e2?.participants);
  }

  @override
  int hash(ChatsRecord? e) => const ListEquality().hash([
        e?.userAId,
        e?.userBId,
        e?.userARef,
        e?.userBRef,
        e?.lastMessage,
        e?.lastMessageTime,
        e?.lastSenderId,
        e?.userATyping,
        e?.userBTyping,
        e?.userAUnread,
        e?.userBUnread,
        e?.likerId,
        e?.likerRef,
        e?.targetId,
        e?.createdTime,
        e?.participantIds,
        e?.participants
      ]);

  @override
  bool isValidKey(Object? o) => o is ChatsRecord;
}
