package myoneapp.org

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
