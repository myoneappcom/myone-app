import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_animations.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/matches/components/single_options/single_options_widget.dart';
import '/matches/components/skeleton_loading_single_page/skeleton_loading_single_page_widget.dart';
import 'dart:math';
import 'dart:ui';
import 'package:carousel_slider/carousel_slider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:flutter_animate/flutter_animate.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'single_page_model.dart';
export 'single_page_model.dart';

class SinglePageWidget extends StatefulWidget {
  const SinglePageWidget({
    super.key,
    required this.userRef,
  });

  final DocumentReference? userRef;

  static String routeName = 'SinglePage';
  static String routePath = '/singlePage';

  @override
  State<SinglePageWidget> createState() => _SinglePageWidgetState();
}

class _SinglePageWidgetState extends State<SinglePageWidget>
    with TickerProviderStateMixin {
  late SinglePageModel _model;

  final scaffoldKey = GlobalKey<ScaffoldState>();

  final animationsMap = <String, AnimationInfo>{};

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SinglePageModel());

    animationsMap.addAll({
      'stackOnPageLoadAnimation': AnimationInfo(
        trigger: AnimationTrigger.onPageLoad,
        effectsBuilder: () => [
          FadeEffect(
            curve: Curves.easeInOut,
            delay: 0.0.ms,
            duration: 150.0.ms,
            begin: 0.0,
            end: 1.0,
          ),
        ],
      ),
    });

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.dispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<UsersRecord>(
      stream: UsersRecord.getDocument(widget!.userRef!),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Scaffold(
            backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
            body: SkeletonLoadingSinglePageWidget(),
          );
        }

        final singlePageUsersRecord = snapshot.data!;

        return GestureDetector(
          onTap: () {
            FocusScope.of(context).unfocus();
            FocusManager.instance.primaryFocus?.unfocus();
          },
          child: Scaffold(
            key: scaffoldKey,
            backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
            appBar: AppBar(
              backgroundColor: FlutterFlowTheme.of(context).secondaryBackground,
              automaticallyImplyLeading: false,
              leading: Padding(
                padding: EdgeInsetsDirectional.fromSTEB(6.0, 6.0, 6.0, 6.0),
                child: FlutterFlowIconButton(
                  borderColor: FlutterFlowTheme.of(context).transparent,
                  borderRadius: 30.0,
                  borderWidth: 0.0,
                  buttonSize: 40.0,
                  fillColor: FlutterFlowTheme.of(context).transparent,
                  icon: Icon(
                    FFIcons.karrowLeft,
                    color: FlutterFlowTheme.of(context).primaryText,
                    size: 25.0,
                  ),
                  onPressed: () async {
                    context.safePop();
                  },
                ),
              ),
              title: Text(
                FFLocalizations.of(context).getText(
                  'lb2xukih' /* Profile */,
                ),
                style: FlutterFlowTheme.of(context).titleMedium.override(
                      fontFamily: 'Onest',
                      color: Color(0xFF0B0B0B),
                      fontSize: 20.0,
                      letterSpacing: 0.0,
                    ),
              ),
              actions: [
                Padding(
                  padding: EdgeInsetsDirectional.fromSTEB(6.0, 6.0, 6.0, 6.0),
                  child: FlutterFlowIconButton(
                    borderColor: FlutterFlowTheme.of(context).transparent,
                    borderRadius: 30.0,
                    borderWidth: 0.0,
                    buttonSize: 40.0,
                    fillColor: FlutterFlowTheme.of(context).transparent,
                    icon: Icon(
                      FFIcons.kmoreVertical,
                      color: FlutterFlowTheme.of(context).primaryText,
                      size: 24.0,
                    ),
                    onPressed: () async {
                      await showModalBottomSheet(
                        isScrollControlled: true,
                        backgroundColor:
                            FlutterFlowTheme.of(context).transparent,
                        barrierColor: FlutterFlowTheme.of(context).accent3,
                        context: context,
                        builder: (context) {
                          return GestureDetector(
                            onTap: () {
                              FocusScope.of(context).unfocus();
                              FocusManager.instance.primaryFocus?.unfocus();
                            },
                            child: Padding(
                              padding: MediaQuery.viewInsetsOf(context),
                              child: SingleOptionsWidget(),
                            ),
                          );
                        },
                      ).then((value) => safeSetState(() {}));
                    },
                  ),
                ),
              ],
              flexibleSpace: FlexibleSpaceBar(
                background: Container(
                  width: 100.0,
                  height: 100.0,
                  decoration: BoxDecoration(
                    color: FlutterFlowTheme.of(context).secondaryBackground,
                  ),
                ),
              ),
              centerTitle: true,
              elevation: 0.0,
            ),
            body: Stack(
              alignment: AlignmentDirectional(0.0, 1.0),
              children: [
                Column(
                  mainAxisSize: MainAxisSize.max,
                  children: [
                    Expanded(
                      child: SingleChildScrollView(
                        child: Column(
                          mainAxisSize: MainAxisSize.max,
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Align(
                              alignment: AlignmentDirectional(0.0, -1.0),
                              child: Container(
                                width: 379.05,
                                height: 379.05,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context)
                                      .primaryBackground,
                                  shape: BoxShape.circle,
                                ),
                                child: Container(
                                  width: double.infinity,
                                  height: 200.0,
                                  child: CarouselSlider(
                                    items: [
                                      Stack(
                                        children: [
                                          if (singlePageUsersRecord.photoUrl !=
                                                  null &&
                                              singlePageUsersRecord.photoUrl !=
                                                  '')
                                            ClipRRect(
                                              borderRadius:
                                                  BorderRadius.circular(8.0),
                                              child: Image.network(
                                                singlePageUsersRecord.photoUrl,
                                                width: 395.7,
                                                height: 385.9,
                                                fit: BoxFit.cover,
                                              ),
                                            ),
                                          Stack(
                                            children: [],
                                          ),
                                          Align(
                                            alignment: AlignmentDirectional(
                                                -0.91, 0.96),
                                            child: Text(
                                              valueOrDefault<String>(
                                                singlePageUsersRecord.age
                                                    .toString(),
                                                '...',
                                              ),
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily: 'Onest',
                                                        fontSize: 18.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                      ),
                                            ),
                                          ),
                                          Align(
                                            alignment: AlignmentDirectional(
                                                -0.91, 0.86),
                                            child: Text(
                                              valueOrDefault<String>(
                                                singlePageUsersRecord.name,
                                                '...',
                                              ),
                                              style:
                                                  FlutterFlowTheme.of(context)
                                                      .bodyMedium
                                                      .override(
                                                        fontFamily: 'Onest',
                                                        fontSize: 18.0,
                                                        letterSpacing: 0.0,
                                                        fontWeight:
                                                            FontWeight.w600,
                                                      ),
                                            ),
                                          ),
                                          if (singlePageUsersRecord.isVerified)
                                            Align(
                                              alignment: AlignmentDirectional(
                                                  0.98, -0.98),
                                              child: Icon(
                                                Icons.verified_sharp,
                                                color: Color(0xFF1D08C4),
                                                size: 24.0,
                                              ),
                                            ),
                                        ],
                                      ),
                                      Visibility(
                                        visible: singlePageUsersRecord.photo1 !=
                                                null &&
                                            singlePageUsersRecord.photo1 != '',
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                          child: Image.network(
                                            singlePageUsersRecord.photo1,
                                            width: 200.0,
                                            height: 200.0,
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                      Visibility(
                                        visible: singlePageUsersRecord.photo2 !=
                                                null &&
                                            singlePageUsersRecord.photo2 != '',
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                          child: Image.network(
                                            singlePageUsersRecord.photo2,
                                            width: 200.0,
                                            height: 200.0,
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                      Visibility(
                                        visible: singlePageUsersRecord.photo3 !=
                                                null &&
                                            singlePageUsersRecord.photo3 != '',
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                          child: Image.network(
                                            singlePageUsersRecord.photo3,
                                            width: 200.0,
                                            height: 200.0,
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                      Visibility(
                                        visible: singlePageUsersRecord.photo4 !=
                                                null &&
                                            singlePageUsersRecord.photo4 != '',
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                          child: Image.network(
                                            singlePageUsersRecord.photo4,
                                            width: 200.0,
                                            height: 200.0,
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                      Visibility(
                                        visible: singlePageUsersRecord.photo5 !=
                                                null &&
                                            singlePageUsersRecord.photo5 != '',
                                        child: ClipRRect(
                                          borderRadius:
                                              BorderRadius.circular(8.0),
                                          child: Image.network(
                                            singlePageUsersRecord.photo5,
                                            width: 200.0,
                                            height: 200.0,
                                            fit: BoxFit.cover,
                                          ),
                                        ),
                                      ),
                                    ],
                                    carouselController:
                                        _model.carouselController ??=
                                            CarouselSliderController(),
                                    options: CarouselOptions(
                                      initialPage: 0,
                                      viewportFraction: 1.0,
                                      disableCenter: true,
                                      enlargeCenterPage: true,
                                      enlargeFactor: 0.25,
                                      enableInfiniteScroll: true,
                                      scrollDirection: Axis.horizontal,
                                      autoPlay: false,
                                      onPageChanged: (index, _) =>
                                          _model.carouselCurrentIndex = index,
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Icon(
                              Icons.location_on,
                              color: FlutterFlowTheme.of(context).primaryText,
                              size: 15.0,
                            ),
                            Padding(
                              padding: EdgeInsets.all(6.0),
                              child: Container(
                                width: 532.0,
                                height: 35.97,
                                decoration: BoxDecoration(
                                  color: Color(0xFFF8F4F4),
                                ),
                                child: StreamBuilder<UsersRecord>(
                                  stream:
                                      UsersRecord.getDocument(widget!.userRef!),
                                  builder: (context, snapshot) {
                                    // Customize what your widget looks like when it's loading.
                                    if (!snapshot.hasData) {
                                      return Center(
                                        child: SizedBox(
                                          width: 30.0,
                                          height: 30.0,
                                          child: SpinKitFadingCircle(
                                            color: FlutterFlowTheme.of(context)
                                                .primary,
                                            size: 30.0,
                                          ),
                                        ),
                                      );
                                    }

                                    final textUsersRecord = snapshot.data!;

                                    return Text(
                                      valueOrDefault<String>(
                                        singlePageUsersRecord.location
                                            ?.toString(),
                                        '...',
                                      ),
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Onest',
                                            fontSize: 15.0,
                                            letterSpacing: 0.0,
                                            fontWeight: FontWeight.w500,
                                          ),
                                    );
                                  },
                                ),
                              ),
                            ),
                            if (singlePageUsersRecord.intentions != null &&
                                singlePageUsersRecord.intentions != '')
                              Padding(
                                padding: EdgeInsets.all(8.0),
                                child: Text(
                                  FFLocalizations.of(context).getText(
                                    'w9sew78v' /* Intenions */,
                                  ),
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Onest',
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.w600,
                                      ),
                                ),
                              ),
                            Padding(
                              padding: EdgeInsets.all(8.0),
                              child: Container(
                                width: 440.5,
                                height: 48.31,
                                decoration: BoxDecoration(
                                  color: Color(0xFFFBFAFA),
                                ),
                                child: Visibility(
                                  visible: singlePageUsersRecord.intentions !=
                                          null &&
                                      singlePageUsersRecord.intentions != '',
                                  child: Padding(
                                    padding: EdgeInsets.all(4.0),
                                    child: FutureBuilder<List<UsersRecord>>(
                                      future: queryUsersRecordOnce(
                                        queryBuilder: (usersRecord) =>
                                            usersRecord.where(
                                          'uid',
                                          isEqualTo: currentUserUid,
                                        ),
                                        singleRecord: true,
                                      ),
                                      builder: (context, snapshot) {
                                        // Customize what your widget looks like when it's loading.
                                        if (!snapshot.hasData) {
                                          return Center(
                                            child: SizedBox(
                                              width: 30.0,
                                              height: 30.0,
                                              child: SpinKitFadingCircle(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primary,
                                                size: 30.0,
                                              ),
                                            ),
                                          );
                                        }
                                        List<UsersRecord> textUsersRecordList =
                                            snapshot.data!;
                                        // Return an empty Container when the item does not exist.
                                        if (snapshot.data!.isEmpty) {
                                          return Container();
                                        }
                                        final textUsersRecord =
                                            textUsersRecordList.isNotEmpty
                                                ? textUsersRecordList.first
                                                : null;

                                        return Text(
                                          valueOrDefault<String>(
                                            textUsersRecord?.intentions,
                                            '...',
                                          ),
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Onest',
                                                fontSize: 15.0,
                                                letterSpacing: 0.0,
                                              ),
                                        );
                                      },
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            if (singlePageUsersRecord.jobTitle != null &&
                                singlePageUsersRecord.jobTitle != '')
                              Padding(
                                padding: EdgeInsets.all(6.0),
                                child: Text(
                                  FFLocalizations.of(context).getText(
                                    'qh3j65pa' /* Job Title */,
                                  ),
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Onest',
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.w600,
                                      ),
                                ),
                              ),
                            Padding(
                              padding: EdgeInsets.all(6.0),
                              child: Container(
                                width: 449.4,
                                height: 47.4,
                                decoration: BoxDecoration(
                                  color: Color(0xFFFDFAFA),
                                ),
                                child: Visibility(
                                  visible:
                                      singlePageUsersRecord.jobTitle != null &&
                                          singlePageUsersRecord.jobTitle != '',
                                  child: Text(
                                    valueOrDefault<String>(
                                      singlePageUsersRecord.jobTitle,
                                      '...',
                                    ),
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Onest',
                                          fontSize: 15.0,
                                          letterSpacing: 0.0,
                                        ),
                                  ),
                                ),
                              ),
                            ),
                            if (singlePageUsersRecord.education != null &&
                                singlePageUsersRecord.education != '')
                              Padding(
                                padding: EdgeInsets.all(8.0),
                                child: Text(
                                  FFLocalizations.of(context).getText(
                                    'z7qinlh5' /* Education */,
                                  ),
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Onest',
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.w600,
                                      ),
                                ),
                              ),
                            Padding(
                              padding: EdgeInsets.all(6.0),
                              child: Container(
                                width: 424.5,
                                height: 48.48,
                                decoration: BoxDecoration(
                                  color: Color(0xFFFBFAFA),
                                ),
                                child: Visibility(
                                  visible:
                                      singlePageUsersRecord.jobTitle != null &&
                                          singlePageUsersRecord.jobTitle != '',
                                  child: Padding(
                                    padding: EdgeInsets.all(8.0),
                                    child: Text(
                                      valueOrDefault<String>(
                                        singlePageUsersRecord.jobTitle,
                                        '...',
                                      ),
                                      style: FlutterFlowTheme.of(context)
                                          .bodyMedium
                                          .override(
                                            fontFamily: 'Onest',
                                            fontSize: 15.0,
                                            letterSpacing: 0.0,
                                            fontWeight: FontWeight.normal,
                                          ),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            if (singlePageUsersRecord.bio != null &&
                                singlePageUsersRecord.bio != '')
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    15.0, 15.0, 0.0, 15.0),
                                child: Text(
                                  FFLocalizations.of(context).getText(
                                    'a4jz9iii' /* Bio */,
                                  ),
                                  style: FlutterFlowTheme.of(context)
                                      .titleMedium
                                      .override(
                                        fontFamily: 'Onest',
                                        color: Color(0xFF040404),
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                      ),
                                ),
                              ),
                            Padding(
                              padding: EdgeInsets.all(10.0),
                              child: Container(
                                width: 412.0,
                                height: 148.13,
                                decoration: BoxDecoration(
                                  color: Color(0xFFF8F4F4),
                                ),
                                child: Visibility(
                                  visible: singlePageUsersRecord.bio != null &&
                                      singlePageUsersRecord.bio != '',
                                  child: Text(
                                    valueOrDefault<String>(
                                      singlePageUsersRecord.bio,
                                      '...',
                                    ),
                                    style: FlutterFlowTheme.of(context)
                                        .bodyMedium
                                        .override(
                                          fontFamily: 'Onest',
                                          fontSize: 15.0,
                                          letterSpacing: 0.0,
                                        ),
                                  ),
                                ),
                              ),
                            ),
                            if (singlePageUsersRecord.familyPlans != null &&
                                singlePageUsersRecord.familyPlans != '')
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    15.0, 25.0, 0.0, 15.0),
                                child: Text(
                                  FFLocalizations.of(context).getText(
                                    'b3d4o26w' /* Familyplans */,
                                  ),
                                  style: FlutterFlowTheme.of(context)
                                      .titleMedium
                                      .override(
                                        fontFamily: 'Onest',
                                        color: Color(0xFF0A0A0A),
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                      ),
                                ),
                              ),
                            Padding(
                              padding: EdgeInsets.all(18.0),
                              child: Container(
                                width: 516.0,
                                height: 41.3,
                                decoration: BoxDecoration(
                                  color: Color(0xFFFAF6F6),
                                ),
                                child: Visibility(
                                  visible: singlePageUsersRecord.familyPlans !=
                                          null &&
                                      singlePageUsersRecord.familyPlans != '',
                                  child: FutureBuilder<List<UsersRecord>>(
                                    future: queryUsersRecordOnce(
                                      queryBuilder: (usersRecord) =>
                                          usersRecord.where(
                                        'uid',
                                        isEqualTo: currentUserUid,
                                      ),
                                      singleRecord: true,
                                    ),
                                    builder: (context, snapshot) {
                                      // Customize what your widget looks like when it's loading.
                                      if (!snapshot.hasData) {
                                        return Center(
                                          child: SizedBox(
                                            width: 30.0,
                                            height: 30.0,
                                            child: SpinKitFadingCircle(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .primary,
                                              size: 30.0,
                                            ),
                                          ),
                                        );
                                      }
                                      List<UsersRecord> textUsersRecordList =
                                          snapshot.data!;
                                      // Return an empty Container when the item does not exist.
                                      if (snapshot.data!.isEmpty) {
                                        return Container();
                                      }
                                      final textUsersRecord =
                                          textUsersRecordList.isNotEmpty
                                              ? textUsersRecordList.first
                                              : null;

                                      return Text(
                                        valueOrDefault<String>(
                                          textUsersRecord?.familyPlans,
                                          '...',
                                        ),
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                              fontFamily: 'Onest',
                                              fontSize: 15.0,
                                              letterSpacing: 0.0,
                                            ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                            ),
                            if (singlePageUsersRecord.personalityTraits !=
                                    null &&
                                singlePageUsersRecord.personalityTraits != '')
                              Padding(
                                padding: EdgeInsets.all(12.0),
                                child: Text(
                                  FFLocalizations.of(context).getText(
                                    '4sg1ueao' /* Personality Traits */,
                                  ),
                                  style: FlutterFlowTheme.of(context)
                                      .bodyMedium
                                      .override(
                                        fontFamily: 'Onest',
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                        fontWeight: FontWeight.w600,
                                      ),
                                ),
                              ),
                            Padding(
                              padding: EdgeInsets.all(8.0),
                              child: Container(
                                width: 549.8,
                                height: 44.04,
                                decoration: BoxDecoration(
                                  color: Color(0xFFFAF6F6),
                                ),
                                child: Visibility(
                                  visible: singlePageUsersRecord
                                              .personalityTraits !=
                                          null &&
                                      singlePageUsersRecord.personalityTraits !=
                                          '',
                                  child: Padding(
                                    padding: EdgeInsets.all(2.0),
                                    child: FutureBuilder<List<UsersRecord>>(
                                      future: queryUsersRecordOnce(
                                        queryBuilder: (usersRecord) =>
                                            usersRecord.where(
                                          'uid',
                                          isEqualTo: currentUserUid,
                                        ),
                                        singleRecord: true,
                                      ),
                                      builder: (context, snapshot) {
                                        // Customize what your widget looks like when it's loading.
                                        if (!snapshot.hasData) {
                                          return Center(
                                            child: SizedBox(
                                              width: 30.0,
                                              height: 30.0,
                                              child: SpinKitFadingCircle(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primary,
                                                size: 30.0,
                                              ),
                                            ),
                                          );
                                        }
                                        List<UsersRecord> textUsersRecordList =
                                            snapshot.data!;
                                        // Return an empty Container when the item does not exist.
                                        if (snapshot.data!.isEmpty) {
                                          return Container();
                                        }
                                        final textUsersRecord =
                                            textUsersRecordList.isNotEmpty
                                                ? textUsersRecordList.first
                                                : null;

                                        return Text(
                                          valueOrDefault<String>(
                                            textUsersRecord?.personalityTraits,
                                            '...',
                                          ),
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Onest',
                                                fontSize: 15.0,
                                                letterSpacing: 0.0,
                                              ),
                                        );
                                      },
                                    ),
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  15.0, 18.0, 15.0, 18.0),
                              child: Container(
                                width: double.infinity,
                                height: 1.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context).accent1,
                                ),
                              ),
                            ),
                            if (singlePageUsersRecord.loveLanguage != null &&
                                singlePageUsersRecord.loveLanguage != '')
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    15.0, 0.0, 0.0, 15.0),
                                child: Text(
                                  FFLocalizations.of(context).getText(
                                    'ztq3uxd8' /* Love Language */,
                                  ),
                                  style: FlutterFlowTheme.of(context)
                                      .titleMedium
                                      .override(
                                        fontFamily: 'Onest',
                                        color: Color(0xFF0A0A0A),
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                      ),
                                ),
                              ),
                            Padding(
                              padding: EdgeInsets.all(18.0),
                              child: Container(
                                width: 448.5,
                                height: 42.2,
                                decoration: BoxDecoration(
                                  color: Color(0xFFF7F1F1),
                                ),
                                child: Visibility(
                                  visible: singlePageUsersRecord.loveLanguage !=
                                          null &&
                                      singlePageUsersRecord.loveLanguage != '',
                                  child: FutureBuilder<List<UsersRecord>>(
                                    future: queryUsersRecordOnce(
                                      queryBuilder: (usersRecord) =>
                                          usersRecord.where(
                                        'uid',
                                        isEqualTo: currentUserUid,
                                      ),
                                      singleRecord: true,
                                    ),
                                    builder: (context, snapshot) {
                                      // Customize what your widget looks like when it's loading.
                                      if (!snapshot.hasData) {
                                        return Center(
                                          child: SizedBox(
                                            width: 30.0,
                                            height: 30.0,
                                            child: SpinKitFadingCircle(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .primary,
                                              size: 30.0,
                                            ),
                                          ),
                                        );
                                      }
                                      List<UsersRecord>
                                          lovelanguageTextUsersRecordList =
                                          snapshot.data!;
                                      // Return an empty Container when the item does not exist.
                                      if (snapshot.data!.isEmpty) {
                                        return Container();
                                      }
                                      final lovelanguageTextUsersRecord =
                                          lovelanguageTextUsersRecordList
                                                  .isNotEmpty
                                              ? lovelanguageTextUsersRecordList
                                                  .first
                                              : null;

                                      return Text(
                                        valueOrDefault<String>(
                                          lovelanguageTextUsersRecord
                                              ?.loveLanguage,
                                          '...',
                                        ),
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                              fontFamily: 'Onest',
                                              fontSize: 15.0,
                                              letterSpacing: 0.0,
                                            ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  15.0, 18.0, 15.0, 18.0),
                              child: Container(
                                width: double.infinity,
                                height: 1.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context).accent1,
                                ),
                              ),
                            ),
                            if (singlePageUsersRecord.workout != null &&
                                singlePageUsersRecord.workout != '')
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    15.0, 0.0, 0.0, 15.0),
                                child: Text(
                                  FFLocalizations.of(context).getText(
                                    'y3qzgp6t' /* Workout */,
                                  ),
                                  style: FlutterFlowTheme.of(context)
                                      .titleMedium
                                      .override(
                                        fontFamily: 'Onest',
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                      ),
                                ),
                              ),
                            Padding(
                              padding: EdgeInsets.all(18.0),
                              child: Container(
                                width: 408.5,
                                height: 44.01,
                                decoration: BoxDecoration(
                                  color: Color(0xFFF8F5F5),
                                ),
                                child: Visibility(
                                  visible:
                                      singlePageUsersRecord.workout != null &&
                                          singlePageUsersRecord.workout != '',
                                  child: FutureBuilder<List<UsersRecord>>(
                                    future: queryUsersRecordOnce(
                                      queryBuilder: (usersRecord) =>
                                          usersRecord.where(
                                        'uid',
                                        isEqualTo: currentUserUid,
                                      ),
                                      singleRecord: true,
                                    ),
                                    builder: (context, snapshot) {
                                      // Customize what your widget looks like when it's loading.
                                      if (!snapshot.hasData) {
                                        return Center(
                                          child: SizedBox(
                                            width: 30.0,
                                            height: 30.0,
                                            child: SpinKitFadingCircle(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .primary,
                                              size: 30.0,
                                            ),
                                          ),
                                        );
                                      }
                                      List<UsersRecord> textUsersRecordList =
                                          snapshot.data!;
                                      // Return an empty Container when the item does not exist.
                                      if (snapshot.data!.isEmpty) {
                                        return Container();
                                      }
                                      final textUsersRecord =
                                          textUsersRecordList.isNotEmpty
                                              ? textUsersRecordList.first
                                              : null;

                                      return Text(
                                        valueOrDefault<String>(
                                          textUsersRecord?.workout,
                                          '...',
                                        ),
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                              fontFamily: 'Onest',
                                              fontSize: 15.0,
                                              letterSpacing: 0.0,
                                            ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  15.0, 18.0, 15.0, 18.0),
                              child: Container(
                                width: double.infinity,
                                height: 1.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context).accent1,
                                ),
                              ),
                            ),
                            if (singlePageUsersRecord.smoking != null &&
                                singlePageUsersRecord.smoking != '')
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    15.0, 0.0, 0.0, 15.0),
                                child: Text(
                                  FFLocalizations.of(context).getText(
                                    'u3tzojn1' /* Smoking */,
                                  ),
                                  style: FlutterFlowTheme.of(context)
                                      .titleMedium
                                      .override(
                                        fontFamily: 'Onest',
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                      ),
                                ),
                              ),
                            Padding(
                              padding: EdgeInsets.all(18.0),
                              child: Container(
                                width: 433.4,
                                height: 45.69,
                                decoration: BoxDecoration(
                                  color: Color(0xFFF5F1F1),
                                ),
                                child: Visibility(
                                  visible:
                                      singlePageUsersRecord.smoking != null &&
                                          singlePageUsersRecord.smoking != '',
                                  child: FutureBuilder<List<UsersRecord>>(
                                    future: queryUsersRecordOnce(
                                      queryBuilder: (usersRecord) =>
                                          usersRecord.where(
                                        'uid',
                                        isEqualTo: currentUserUid,
                                      ),
                                      singleRecord: true,
                                    ),
                                    builder: (context, snapshot) {
                                      // Customize what your widget looks like when it's loading.
                                      if (!snapshot.hasData) {
                                        return Center(
                                          child: SizedBox(
                                            width: 30.0,
                                            height: 30.0,
                                            child: SpinKitFadingCircle(
                                              color:
                                                  FlutterFlowTheme.of(context)
                                                      .primary,
                                              size: 30.0,
                                            ),
                                          ),
                                        );
                                      }
                                      List<UsersRecord> textUsersRecordList =
                                          snapshot.data!;
                                      // Return an empty Container when the item does not exist.
                                      if (snapshot.data!.isEmpty) {
                                        return Container();
                                      }
                                      final textUsersRecord =
                                          textUsersRecordList.isNotEmpty
                                              ? textUsersRecordList.first
                                              : null;

                                      return Text(
                                        valueOrDefault<String>(
                                          textUsersRecord?.smoking,
                                          '...',
                                        ),
                                        style: FlutterFlowTheme.of(context)
                                            .bodyMedium
                                            .override(
                                              fontFamily: 'Onest',
                                              fontSize: 15.0,
                                              letterSpacing: 0.0,
                                            ),
                                      );
                                    },
                                  ),
                                ),
                              ),
                            ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  15.0, 18.0, 15.0, 18.0),
                              child: Container(
                                width: double.infinity,
                                height: 1.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context).accent1,
                                ),
                              ),
                            ),
                            if (singlePageUsersRecord.drinking != null &&
                                singlePageUsersRecord.drinking != '')
                              Padding(
                                padding: EdgeInsetsDirectional.fromSTEB(
                                    15.0, 0.0, 0.0, 15.0),
                                child: Text(
                                  FFLocalizations.of(context).getText(
                                    'z50n80tl' /* Drinking */,
                                  ),
                                  style: FlutterFlowTheme.of(context)
                                      .titleMedium
                                      .override(
                                        fontFamily: 'Onest',
                                        fontSize: 14.0,
                                        letterSpacing: 0.0,
                                      ),
                                ),
                              ),
                            if (singlePageUsersRecord.drinking != null &&
                                singlePageUsersRecord.drinking != '')
                              Padding(
                                padding: EdgeInsets.all(24.0),
                                child: Container(
                                  width: 346.3,
                                  height: 49.31,
                                  decoration: BoxDecoration(
                                    color: Color(0xFFF8F4F4),
                                  ),
                                  child: Visibility(
                                    visible: singlePageUsersRecord.drinking !=
                                            null &&
                                        singlePageUsersRecord.drinking != '',
                                    child: FutureBuilder<List<UsersRecord>>(
                                      future: queryUsersRecordOnce(
                                        queryBuilder: (usersRecord) =>
                                            usersRecord.where(
                                          'uid',
                                          isEqualTo: currentUserUid,
                                        ),
                                        singleRecord: true,
                                      ),
                                      builder: (context, snapshot) {
                                        // Customize what your widget looks like when it's loading.
                                        if (!snapshot.hasData) {
                                          return Center(
                                            child: SizedBox(
                                              width: 30.0,
                                              height: 30.0,
                                              child: SpinKitFadingCircle(
                                                color:
                                                    FlutterFlowTheme.of(context)
                                                        .primary,
                                                size: 30.0,
                                              ),
                                            ),
                                          );
                                        }
                                        List<UsersRecord> textUsersRecordList =
                                            snapshot.data!;
                                        // Return an empty Container when the item does not exist.
                                        if (snapshot.data!.isEmpty) {
                                          return Container();
                                        }
                                        final textUsersRecord =
                                            textUsersRecordList.isNotEmpty
                                                ? textUsersRecordList.first
                                                : null;

                                        return Text(
                                          valueOrDefault<String>(
                                            textUsersRecord?.drinking,
                                            '...',
                                          ),
                                          style: FlutterFlowTheme.of(context)
                                              .bodyMedium
                                              .override(
                                                fontFamily: 'Onest',
                                                fontSize: 15.0,
                                                letterSpacing: 0.0,
                                                fontWeight: FontWeight.normal,
                                              ),
                                        );
                                      },
                                    ),
                                  ),
                                ),
                              ),
                            Padding(
                              padding: EdgeInsetsDirectional.fromSTEB(
                                  15.0, 18.0, 15.0, 18.0),
                              child: Container(
                                width: double.infinity,
                                height: 1.0,
                                decoration: BoxDecoration(
                                  color: FlutterFlowTheme.of(context).accent1,
                                ),
                              ),
                            ),
                          ]
                              .addToStart(SizedBox(height: 10.0))
                              .addToEnd(SizedBox(height: 80.0)),
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ).animateOnPageLoad(animationsMap['stackOnPageLoadAnimation']!),
          ),
        );
      },
    );
  }
}
