import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/home/navbar/navbar_widget.dart';
import '/matches/components/user_card/user_card_widget.dart';
import 'dart:ui';
import '/index.dart';
import 'likes_widget.dart' show LikesWidget;
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class LikesModel extends FlutterFlowModel<LikesWidget> {
  ///  State fields for stateful widgets in this page.

  // Models for UserCard dynamic component.
  late FlutterFlowDynamicModels<UserCardModel> userCardModels1;
  // Models for UserCard dynamic component.
  late FlutterFlowDynamicModels<UserCardModel> userCardModels2;
  // Model for Navbar component.
  late NavbarModel navbarModel;

  @override
  void initState(BuildContext context) {
    userCardModels1 = FlutterFlowDynamicModels(() => UserCardModel());
    userCardModels2 = FlutterFlowDynamicModels(() => UserCardModel());
    navbarModel = createModel(context, () => NavbarModel());
  }

  @override
  void dispose() {
    userCardModels1.dispose();
    userCardModels2.dispose();
    navbarModel.dispose();
  }
}
