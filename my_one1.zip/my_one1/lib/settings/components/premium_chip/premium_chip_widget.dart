import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/index.dart';
import 'package:flutter/material.dart';
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'premium_chip_model.dart';
export 'premium_chip_model.dart';

class PremiumChipWidget extends StatefulWidget {
  const PremiumChipWidget({super.key});

  @override
  State<PremiumChipWidget> createState() => _PremiumChipWidgetState();
}

class _PremiumChipWidgetState extends State<PremiumChipWidget> {
  late PremiumChipModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => PremiumChipModel());

    WidgetsBinding.instance.addPostFrameCallback((_) => safeSetState(() {}));
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return FFButtonWidget(
      onPressed: () async {
        context.pushNamed(SubscriptionWidget.routeName);
      },
      text: FFLocalizations.of(context).getText(
        'uneo2cpt' /* Get Premium (from $18,66) */,
      ),
      options: FFButtonOptions(
        width: double.infinity,
        height: 48.0,
        padding: EdgeInsetsDirectional.fromSTEB(20.0, 0.0, 20.0, 0.0),
        iconPadding: EdgeInsetsDirectional.fromSTEB(0.0, 0.0, 0.0, 0.0),
        color: Colors.white,
        textStyle: FlutterFlowTheme.of(context).titleSmall.override(
              fontFamily: 'Onest',
              color: Color(0xFF0A0A0A),
              fontSize: 16.0,
              letterSpacing: 0.0,
              fontWeight: FontWeight.w600,
            ),
        elevation: 0.0,
        borderRadius: BorderRadius.circular(50.0),
      ),
      showLoadingIndicator: false,
    );
  }
}
