// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/actions/actions.dart' as action_blocks;
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:flutter/cupertino.dart';

class AgePicker extends StatefulWidget {
  AgePicker({
    Key? key,
    this.width,
    this.height,
  }) : super(key: key);

  final double? width;
  final double? height;

  @override
  _AgePickerState createState() => _AgePickerState();
}

class _AgePickerState extends State<AgePicker> {
  final List<int> ages = List.generate(85, (index) => 16 + index); // 16 to 100
  int selectedIndex = 2; // Default to age 18

  @override
  void initState() {
    super.initState();

    // Set initial user age in app state
    FFAppState().update(() {
      FFAppState().userAge = ages[selectedIndex];
    });
  }

  void _onAgeChanged(int index) {
    setState(() {
      selectedIndex = index;
    });

    // Update global app state
    FFAppState().update(() {
      FFAppState().userAge = ages[index];
    });
  }

  @override
  Widget build(BuildContext context) {
    final isDarkMode = Theme.of(context).brightness == Brightness.dark;

    return Container(
      height: widget.height ?? 420.0,
      padding: const EdgeInsets.all(16.0),
      child: CupertinoPicker(
        itemExtent: 60.0,
        scrollController:
            FixedExtentScrollController(initialItem: selectedIndex),
        onSelectedItemChanged: _onAgeChanged,
        children: List.generate(ages.length, (index) {
          final bool isSelected = index == selectedIndex;
          return Center(
            child: Text(
              ages[index].toString(),
              style: TextStyle(
                fontFamily: 'Open Sans',
                color: isSelected
                    ? const Color(0xFFA80FFF)
                    : isDarkMode
                        ? const Color(0xFFededed)
                        : Colors.black,
                fontSize: isSelected ? 40 : 25,
                fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
              ),
            ),
          );
        }),
      ),
    );
  }
}
