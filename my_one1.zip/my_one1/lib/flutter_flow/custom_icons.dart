import 'package:flutter/widgets.dart';

class FFIcons {
  FFIcons._();

  static const String _cooliconsFlutterMartComFamily =
      'CooliconsFlutterMartCom';
  static const String _heroicons2FlutterMartComFamily =
      'Heroicons2FlutterMartCom';
  static const String _datingerIconFamily = 'DatingerIcon';
  static const String _untitledUiFamily = 'UntitledUi';
  static const String _untitledFilledFamily = 'UntitledFilled';
  static const String _closeIconFamily = 'CloseIcon';
  static const String _crownDiamondFamily = 'CrownDiamond';

  // Coolicons_FlutterMart_com
  static const IconData kaddColumn =
      IconData(0xe900, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kaddMinusSquare =
      IconData(0xe901, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kaddPlus =
      IconData(0xe902, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kaddPlusCircle =
      IconData(0xe903, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kaddPlusSquare =
      IconData(0xe904, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kaddRow =
      IconData(0xe905, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kaddToQueue =
      IconData(0xe906, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kairplay =
      IconData(0xe907, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kalarm =
      IconData(0xe908, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karchive =
      IconData(0xe909, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowCircleDown =
      IconData(0xe90a, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowCircleDownLeft =
      IconData(0xe90b, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowCircleDownRight =
      IconData(0xe90c, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowCircleLeft =
      IconData(0xe90d, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowCircleRight =
      IconData(0xe90e, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowCircleUp =
      IconData(0xe90f, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowCircleUpLeft =
      IconData(0xe910, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowCircleUpRight =
      IconData(0xe911, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowDownLeftLG =
      IconData(0xe912, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowDownLeftMD =
      IconData(0xe913, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowDownLeftSM =
      IconData(0xe914, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowDownLG =
      IconData(0xe915, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowDownMD =
      IconData(0xe916, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowDownRightLG =
      IconData(0xe917, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowDownRightMD =
      IconData(0xe918, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowDownRightSM =
      IconData(0xe919, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowDownSM =
      IconData(0xe91a, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowDownUp =
      IconData(0xe91b, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowLeftLG =
      IconData(0xe91c, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowLeftMD =
      IconData(0xe91d, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowLeftRight =
      IconData(0xe91e, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowLeftSM =
      IconData(0xe91f, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowReload02 =
      IconData(0xe920, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowRightLG =
      IconData(0xe921, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowRightMD =
      IconData(0xe922, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowRightSM =
      IconData(0xe923, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowSubDownLeft =
      IconData(0xe924, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowSubDownRight =
      IconData(0xe925, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowSubLeftDown =
      IconData(0xe926, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowSubLeftUp =
      IconData(0xe927, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowSubRightDown =
      IconData(0xe928, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowSubRightUp =
      IconData(0xe929, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowSubUpLeft =
      IconData(0xe92a, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowSubUpRight =
      IconData(0xe92b, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowUndoDownLeft =
      IconData(0xe92c, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowUndoDownRight =
      IconData(0xe92d, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowUndoUpLeft =
      IconData(0xe92e, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowUndoUpRight =
      IconData(0xe92f, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowUpLeftLG =
      IconData(0xe930, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowUpLeftMD =
      IconData(0xe931, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowUpLeftSM =
      IconData(0xe932, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowUpLG =
      IconData(0xe933, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowUpMD =
      IconData(0xe934, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowUpRightLG =
      IconData(0xe935, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowUpRightMD =
      IconData(0xe936, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowUpRightSM =
      IconData(0xe937, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowUpSM =
      IconData(0xe938, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData karrowsReload01 =
      IconData(0xe939, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kbarBottom =
      IconData(0xe93a, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kbarLeft =
      IconData(0xe93b, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kbarRight =
      IconData(0xe93c, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kbarTop =
      IconData(0xe93d, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kbell =
      IconData(0xe93e, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kbellAdd =
      IconData(0xe93f, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kbellClose =
      IconData(0xe940, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kbellNotification =
      IconData(0xe941, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kbellOff =
      IconData(0xe942, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kbellRemove =
      IconData(0xe943, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kbellRing =
      IconData(0xe944, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kbold =
      IconData(0xe945, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kbook =
      IconData(0xe946, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kbookOpen =
      IconData(0xe947, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kbookmark =
      IconData(0xe948, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kbuilding01 =
      IconData(0xe949, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kbuilding02 =
      IconData(0xe94a, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kbuilding03 =
      IconData(0xe94b, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kbuilding04 =
      IconData(0xe94c, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kbulb =
      IconData(0xe94d, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcalendar =
      IconData(0xe94e, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcalendarAdd =
      IconData(0xe94f, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcalendarCheck =
      IconData(0xe950, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcalendarClose =
      IconData(0xe951, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcalendarDays =
      IconData(0xe952, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcalendarEvent =
      IconData(0xe953, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcalendarRemove =
      IconData(0xe954, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcalendarWeek =
      IconData(0xe955, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcamera =
      IconData(0xe956, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcarAuto =
      IconData(0xe957, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcaretCircleDown =
      IconData(0xe958, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcaretCircleLeft =
      IconData(0xe959, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcaretCircleRight =
      IconData(0xe95a, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcaretCircleUp =
      IconData(0xe95b, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcaretDownMD =
      IconData(0xe95c, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcaretDownSM =
      IconData(0xe95d, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcaretLeftSM =
      IconData(0xe95e, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcaretRightSM =
      IconData(0xe95f, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcaretUpMD =
      IconData(0xe960, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcaretUpSM =
      IconData(0xe961, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchartBarHorizontal01 =
      IconData(0xe962, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchartBarVertical01 =
      IconData(0xe963, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchartLine =
      IconData(0xe964, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchartPie =
      IconData(0xe965, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchat =
      IconData(0xe966, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchatAdd =
      IconData(0xe967, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchatCheck =
      IconData(0xe968, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchatCircle =
      IconData(0xe969, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchatCircleAdd =
      IconData(0xe96a, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchatCircleCheck =
      IconData(0xe96b, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchatCircleClose =
      IconData(0xe96c, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchatCircleDots =
      IconData(0xe96d, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchatCircleRemove =
      IconData(0xe96e, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchatClose =
      IconData(0xe96f, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchatConversation =
      IconData(0xe970, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchatConversationCircle =
      IconData(0xe971, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchatDots =
      IconData(0xe972, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchatRemove =
      IconData(0xe973, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcheck =
      IconData(0xe974, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcheckAll =
      IconData(0xe975, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcheckAllBig =
      IconData(0xe976, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcheckBig =
      IconData(0xe977, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcheckboxCheck =
      IconData(0xe978, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcheckboxFill =
      IconData(0xe979, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcheckboxUnchecked =
      IconData(0xe97a, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchevronDown =
      IconData(0xe97b, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchevronDownDuo =
      IconData(0xe97c, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchevronLeft =
      IconData(0xe97d, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchevronLeftDuo =
      IconData(0xe97e, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchevronLeftMD =
      IconData(0xe97f, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchevronRight =
      IconData(0xe980, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchevronRightDuo =
      IconData(0xe981, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchevronRightMD =
      IconData(0xe982, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchevronUp =
      IconData(0xe983, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchevronUpDuo =
      IconData(0xe984, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kchromecast =
      IconData(0xe985, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcircle =
      IconData(0xe986, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcircleCheck =
      IconData(0xe987, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcircleHelp =
      IconData(0xe988, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcircleWarning =
      IconData(0xe989, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kclock =
      IconData(0xe98a, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcloseCircle =
      IconData(0xe98b, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcloseLG =
      IconData(0xe98c, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcloseMD =
      IconData(0xe98d, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcloseSM =
      IconData(0xe98e, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcloseSquare =
      IconData(0xe98f, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcloud =
      IconData(0xe990, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcloudAdd =
      IconData(0xe991, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcloudCheck =
      IconData(0xe992, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcloudClose =
      IconData(0xe993, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcloudDownload =
      IconData(0xe994, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcloudOff =
      IconData(0xe995, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcloudRemove =
      IconData(0xe996, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcloudUpload =
      IconData(0xe997, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcode =
      IconData(0xe998, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcoffeToGo =
      IconData(0xe999, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcoffee =
      IconData(0xe99a, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcolumns =
      IconData(0xe99b, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcombineCells =
      IconData(0xe99c, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcommand =
      IconData(0xe99d, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcompass =
      IconData(0xe99e, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcookie =
      IconData(0xe99f, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcopy =
      IconData(0xe9a0, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcreditCard01 =
      IconData(0xe9a1, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcreditCard02 =
      IconData(0xe9a2, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcrop =
      IconData(0xe9a3, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcupcake =
      IconData(0xe9a4, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kcylinder =
      IconData(0xe9a5, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kdata =
      IconData(0xe9a6, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kdeleteColumn =
      IconData(0xe9a7, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kdeleteRow =
      IconData(0xe9a8, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kdesktop =
      IconData(0xe9a9, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kdesktopTower =
      IconData(0xe9aa, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kdevices =
      IconData(0xe9ab, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kdoubleQuotesL =
      IconData(0xe9ac, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kdoubleQuotesR =
      IconData(0xe9ad, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kdownload =
      IconData(0xe9ae, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kdownloadPackage =
      IconData(0xe9af, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kdragHorizontal =
      IconData(0xe9b0, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kdragVertical =
      IconData(0xe9b1, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kdummyCircle =
      IconData(0xe9b2, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kdummyCircleSmall =
      IconData(0xe9b3, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kdummySquare =
      IconData(0xe9b4, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kdummySquareSmall =
      IconData(0xe9b5, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData keditPencil01 =
      IconData(0xe9b6, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData keditPencil02 =
      IconData(0xe9b7, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData keditPencilLine01 =
      IconData(0xe9b8, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData keditPencilLine02 =
      IconData(0xe9b9, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kexit =
      IconData(0xe9ba, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kexpand =
      IconData(0xe9bb, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kexternalLink =
      IconData(0xe9bc, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfigma =
      IconData(0xe9bd, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfileAdd =
      IconData(0xe9be, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfileBlank =
      IconData(0xe9bf, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfileCheck =
      IconData(0xe9c0, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfileClose =
      IconData(0xe9c1, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfileCode =
      IconData(0xe9c2, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfileDocument =
      IconData(0xe9c3, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfileDownload =
      IconData(0xe9c4, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfileEdit =
      IconData(0xe9c5, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfileRemove =
      IconData(0xe9c6, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfileSearch =
      IconData(0xe9c7, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfileUpload =
      IconData(0xe9c8, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfiles =
      IconData(0xe9c9, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfilter =
      IconData(0xe9ca, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfilterOff =
      IconData(0xe9cb, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfirstAid =
      IconData(0xe9cc, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kflag =
      IconData(0xe9cd, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfolder =
      IconData(0xe9ce, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfolderAdd =
      IconData(0xe9cf, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfolderCheck =
      IconData(0xe9d0, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfolderClose =
      IconData(0xe9d1, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfolderCode =
      IconData(0xe9d2, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfolderDocument =
      IconData(0xe9d3, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfolderDownload =
      IconData(0xe9d4, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfolderEdit =
      IconData(0xe9d5, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfolderOpen =
      IconData(0xe9d6, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfolderRemove =
      IconData(0xe9d7, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfolderSearch =
      IconData(0xe9d8, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfolderUpload =
      IconData(0xe9d9, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfolders =
      IconData(0xe9da, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kfont =
      IconData(0xe9db, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kforward =
      IconData(0xe9dc, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kgift =
      IconData(0xe9dd, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kglobe =
      IconData(0xe9de, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData khamburgerLG =
      IconData(0xe9df, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData khamburgerMD =
      IconData(0xe9e0, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData khandbag =
      IconData(0xe9e1, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kheading =
      IconData(0xe9e2, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kheadingH1 =
      IconData(0xe9e3, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kheadingH2 =
      IconData(0xe9e4, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kheadingH3 =
      IconData(0xe9e5, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kheadingH4 =
      IconData(0xe9e6, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kheadingH5 =
      IconData(0xe9e7, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kheadingH6 =
      IconData(0xe9e8, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kheadphones =
      IconData(0xe9e9, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kheart01 =
      IconData(0xe9ea, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kheart02 =
      IconData(0xe9eb, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData khelp =
      IconData(0xe9ec, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData khide =
      IconData(0xe9ed, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData khouse01 =
      IconData(0xe9ee, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData khouse02 =
      IconData(0xe9ef, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData khouse03 =
      IconData(0xe9f0, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData khouseAdd =
      IconData(0xe9f1, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData khouseCheck =
      IconData(0xe9f2, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData khouseClose =
      IconData(0xe9f3, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData khouseRemove =
      IconData(0xe9f4, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kimage01 =
      IconData(0xe9f5, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kimage02 =
      IconData(0xe9f6, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kinfo =
      IconData(0xe9f7, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kinstance =
      IconData(0xe9f8, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kitalic =
      IconData(0xe9f9, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kkeyboard =
      IconData(0xe9fa, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData klabel =
      IconData(0xe9fb, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData klaptop =
      IconData(0xe9fc, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData klayer =
      IconData(0xe9fd, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData klayers =
      IconData(0xe9fe, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kleaf =
      IconData(0xe9ff, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData klineL =
      IconData(0xea00, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData klineM =
      IconData(0xea01, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData klineS =
      IconData(0xea02, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData klineXl =
      IconData(0xea03, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData klink =
      IconData(0xea04, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData klinkBreak =
      IconData(0xea05, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData klinkHorizontal =
      IconData(0xea06, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData klinkHorizontalOff =
      IconData(0xea07, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData klinkVertical =
      IconData(0xea08, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData klistAdd =
      IconData(0xea09, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData klistCheck =
      IconData(0xea0a, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData klistChecklist =
      IconData(0xea0b, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData klistOrdered =
      IconData(0xea0c, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData klistRemove =
      IconData(0xea0d, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData klistUnordered =
      IconData(0xea0e, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kloading =
      IconData(0xea0f, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData klock =
      IconData(0xea10, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData klockOpen =
      IconData(0xea11, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData klogOut =
      IconData(0xea12, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmagnifyingGlassMinus =
      IconData(0xea13, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmagnifyingGlassPlus =
      IconData(0xea14, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmail =
      IconData(0xea15, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmailOpen =
      IconData(0xea16, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmainComponent =
      IconData(0xea17, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmap =
      IconData(0xea18, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmapPin =
      IconData(0xea19, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmention =
      IconData(0xea1a, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmenuAlt01 =
      IconData(0xea1b, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmenuAlt02 =
      IconData(0xea1c, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmenuAlt03 =
      IconData(0xea1d, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmenuAlt04 =
      IconData(0xea1e, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmenuAlt05 =
      IconData(0xea1f, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmenuDuoLG =
      IconData(0xea20, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmenuDuoMD =
      IconData(0xea21, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmobile =
      IconData(0xea22, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmobileButton =
      IconData(0xea23, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmonitor =
      IconData(0xea24, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmonitorPlay =
      IconData(0xea25, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmoon =
      IconData(0xea26, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmoreGridBig =
      IconData(0xea27, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmoreGridSmall =
      IconData(0xea28, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmoreHorizontal =
      IconData(0xea29, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmoreVertical =
      IconData(0xea2a, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmouse =
      IconData(0xea2b, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmove =
      IconData(0xea2c, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmoveHorizontal =
      IconData(0xea2d, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmoveVertical =
      IconData(0xea2e, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kmovingDesk =
      IconData(0xea2f, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData knavigation =
      IconData(0xea30, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData knote =
      IconData(0xea31, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData knoteEdit =
      IconData(0xea32, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData knoteSearch =
      IconData(0xea33, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData knotebook =
      IconData(0xea34, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData koctagon =
      IconData(0xea35, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData koctagonCheck =
      IconData(0xea36, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData koctagonHelp =
      IconData(0xea37, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData koctagonWarning =
      IconData(0xea38, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData koption =
      IconData(0xea39, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kpaperPlane =
      IconData(0xea3a, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kpaperclipAttechmentHorizontal =
      IconData(0xea3b, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kpaperclipAttechmentTilt =
      IconData(0xea3c, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kparagraph =
      IconData(0xea3d, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kpath =
      IconData(0xea3e, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kpause =
      IconData(0xea3f, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kpauseCircle =
      IconData(0xea40, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kphone =
      IconData(0xea41, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kplanet =
      IconData(0xea42, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kplay =
      IconData(0xea43, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kplayCircle =
      IconData(0xea44, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kprinter =
      IconData(0xea45, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kpuzzle =
      IconData(0xea46, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kqrCode =
      IconData(0xea47, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kradioFill =
      IconData(0xea48, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kradioUnchecked =
      IconData(0xea49, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData krainbow =
      IconData(0xea4a, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kredo =
      IconData(0xea4b, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kremoveMinus =
      IconData(0xea4c, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kremoveMinusCircle =
      IconData(0xea4d, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData krewind =
      IconData(0xea4e, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData krows =
      IconData(0xea4f, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kruler =
      IconData(0xea50, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ksave =
      IconData(0xea51, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ksearchMagnifyingGlass =
      IconData(0xea52, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kselectMultiple =
      IconData(0xea53, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ksettings =
      IconData(0xea54, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ksettingsFuture =
      IconData(0xea55, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kshareAndroid =
      IconData(0xea56, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kshareIOSExport =
      IconData(0xea57, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kshield =
      IconData(0xea58, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kshieldCheck =
      IconData(0xea59, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kshieldWarning =
      IconData(0xea5a, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kshoppingBag01 =
      IconData(0xea5b, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kshoppingBag02 =
      IconData(0xea5c, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kshoppingCart01 =
      IconData(0xea5d, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kshoppingCart02 =
      IconData(0xea5e, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kshow =
      IconData(0xea5f, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kshrink =
      IconData(0xea60, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kshuffle =
      IconData(0xea61, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ksingleQuotesL =
      IconData(0xea62, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ksingleQuotesR =
      IconData(0xea63, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kskipBack =
      IconData(0xea64, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kskipForward =
      IconData(0xea65, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kslider01 =
      IconData(0xea66, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kslider02 =
      IconData(0xea67, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kslider03 =
      IconData(0xea68, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ksortAscending =
      IconData(0xea69, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ksortDescending =
      IconData(0xea6a, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ksquare =
      IconData(0xea6b, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ksquareCheck =
      IconData(0xea6c, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ksquareHelp =
      IconData(0xea6d, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ksquareWarning =
      IconData(0xea6e, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kstar =
      IconData(0xea6f, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kstop =
      IconData(0xea70, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kstopCircle =
      IconData(0xea71, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kstopSign =
      IconData(0xea72, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kstrikethrough =
      IconData(0xea73, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ksuitcase =
      IconData(0xea74, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ksun =
      IconData(0xea75, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kswatchesPalette =
      IconData(0xea76, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kswichtLeft =
      IconData(0xea77, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kswichtRight =
      IconData(0xea78, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ktable =
      IconData(0xea79, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ktableAdd =
      IconData(0xea7a, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ktableRemove =
      IconData(0xea7b, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ktablet =
      IconData(0xea7c, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ktabletButton =
      IconData(0xea7d, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ktag =
      IconData(0xea7e, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kterminal =
      IconData(0xea7f, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ktext =
      IconData(0xea80, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ktextAlignCenter =
      IconData(0xea81, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ktextAlignJustify =
      IconData(0xea82, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ktextAlignLeft =
      IconData(0xea83, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ktextAlignRight =
      IconData(0xea84, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kticketVoucher =
      IconData(0xea85, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ktimer =
      IconData(0xea86, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ktimerAdd =
      IconData(0xea87, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ktimerClose =
      IconData(0xea88, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ktimerRemove =
      IconData(0xea89, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ktrashEmpty =
      IconData(0xea8a, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ktrashFull =
      IconData(0xea8b, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ktrendingDown =
      IconData(0xea8c, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ktrendingUp =
      IconData(0xea8d, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ktriangle =
      IconData(0xea8e, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ktriangleCheck =
      IconData(0xea8f, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData ktriangleWarning =
      IconData(0xea90, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kunderline =
      IconData(0xea91, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kundo =
      IconData(0xea92, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kunfoldLess =
      IconData(0xea93, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kunfoldMore =
      IconData(0xea94, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kuser01 =
      IconData(0xea95, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kuser02 =
      IconData(0xea96, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kuser03 =
      IconData(0xea97, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kuserAdd =
      IconData(0xea98, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kuserCardID =
      IconData(0xea99, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kuserCheck =
      IconData(0xea9a, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kuserCircle =
      IconData(0xea9b, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kuserClose =
      IconData(0xea9c, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kuserRemove =
      IconData(0xea9d, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kuserSquare =
      IconData(0xea9e, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kuserVoice =
      IconData(0xea9f, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kusers =
      IconData(0xeaa0, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kusersGroup =
      IconData(0xeaa1, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kvolumeMax =
      IconData(0xeaa2, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kvolumeMin =
      IconData(0xeaa3, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kvolumeMinus =
      IconData(0xeaa4, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kvolumeOff =
      IconData(0xeaa5, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kvolumeOff02 =
      IconData(0xeaa6, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kvolumePlus =
      IconData(0xeaa7, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kwarning =
      IconData(0xeaa8, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kwaterDrop =
      IconData(0xeaa9, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kwavy =
      IconData(0xeaaa, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kwavyCheck =
      IconData(0xeaab, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kwavyHelp =
      IconData(0xeaac, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kwavyWarning =
      IconData(0xeaad, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kwifiHigh =
      IconData(0xeaae, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kwifiLow =
      IconData(0xeaaf, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kwifiMedium =
      IconData(0xeab0, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kwifiNone =
      IconData(0xeab1, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kwifiOff =
      IconData(0xeab2, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kwifiProblem =
      IconData(0xeab3, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kwindow =
      IconData(0xeab4, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kwindowCheck =
      IconData(0xeab5, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kwindowClose =
      IconData(0xeab6, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kwindowCodeBlock =
      IconData(0xeab7, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kwindowSidebar =
      IconData(0xeab8, fontFamily: _cooliconsFlutterMartComFamily);
  static const IconData kwindowTerminal =
      IconData(0xeab9, fontFamily: _cooliconsFlutterMartComFamily);

  // Heroicons2_FlutterMart_com
  static const IconData kacademicCap =
      IconData(0xe900, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kadjustmentsHorizontal =
      IconData(0xe901, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kadjustmentsVertical =
      IconData(0xe902, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData karchiveBox =
      IconData(0xe903, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData karchiveBoxArrowDown =
      IconData(0xe904, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData karchiveBoxXMark =
      IconData(0xe905, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData karrowDownCircle =
      IconData(0xe906, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData karrowDownOnSquare =
      IconData(0xe907, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData karrowDownOnSquareStack =
      IconData(0xe908, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData karrowLeftCircle =
      IconData(0xe909, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData karrowRightCircle =
      IconData(0xe90a, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData karrowUpCircle =
      IconData(0xe90b, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData karrowUpOnSquare =
      IconData(0xe90c, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData karrowUpOnSquareStack =
      IconData(0xe90d, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kbackspace =
      IconData(0xe90e, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kbackward =
      IconData(0xe90f, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kbanknotes =
      IconData(0xe910, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kbattery50 =
      IconData(0xe911, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kbattery100 =
      IconData(0xe912, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kbeaker =
      IconData(0xe913, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kbellAlert =
      IconData(0xe915, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kbellSlash =
      IconData(0xe916, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kbellSnooze =
      IconData(0xe917, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kbolt =
      IconData(0xe919, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kboltSlash =
      IconData(0xe91a, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kbookmarkSlash =
      IconData(0xe91c, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kbookmarkSquare =
      IconData(0xe91d, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kbriefcase =
      IconData(0xe91f, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kbugAnt =
      IconData(0xe920, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kbuildingLibrary =
      IconData(0xe921, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kbuildingOffice =
      IconData(0xe922, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kbuildingOffice2 =
      IconData(0xe923, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kbuildingStorefront =
      IconData(0xe924, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcake =
      IconData(0xe925, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcalculator =
      IconData(0xe926, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcalendarDateRange =
      IconData(0xe928, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kchartBar =
      IconData(0xe92b, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kchartBarSquare =
      IconData(0xe92c, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kchatBubbleBottomCenter =
      IconData(0xe92e, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kchatBubbleBottomCenterText =
      IconData(0xe92f, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kchatBubbleLeft =
      IconData(0xe930, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kchatBubbleLeftEllipsis =
      IconData(0xe931, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kchatBubbleLeftRight =
      IconData(0xe932, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kchatBubbleOvalLeft =
      IconData(0xe933, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kchatBubbleOvalLeftEllipsis =
      IconData(0xe934, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcheckBadge =
      IconData(0xe935, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcheckCircle =
      IconData(0xe936, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcircleStack =
      IconData(0xe937, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kclipboard =
      IconData(0xe938, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kclipboardDocument =
      IconData(0xe939, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kclipboardDocumentCheck =
      IconData(0xe93a, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kclipboardDocumentList =
      IconData(0xe93b, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcloudArrowDown =
      IconData(0xe93e, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcloudArrowUp =
      IconData(0xe93f, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcodeBracketSquare =
      IconData(0xe940, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcog =
      IconData(0xe941, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcog6Tooth =
      IconData(0xe942, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcog8Tooth =
      IconData(0xe943, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcommandLine =
      IconData(0xe944, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcomputerDesktop =
      IconData(0xe945, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcpuChip =
      IconData(0xe946, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcreditCard =
      IconData(0xe947, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcube =
      IconData(0xe948, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcurrencyBangladeshi =
      IconData(0xe949, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcurrencyDollar =
      IconData(0xe94a, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcurrencyEuro =
      IconData(0xe94b, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcurrencyPound =
      IconData(0xe94c, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcurrencyRupee =
      IconData(0xe94d, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kcurrencyYen =
      IconData(0xe94e, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kdocument =
      IconData(0xe94f, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kdocumentArrowDown =
      IconData(0xe950, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kdocumentArrowUp =
      IconData(0xe951, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kdocumentChartBar =
      IconData(0xe952, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kdocumentCheck =
      IconData(0xe953, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kdocumentCurrencyBangladeshi =
      IconData(0xe954, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kdocumentCurrencyDollar =
      IconData(0xe955, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kdocumentCurrencyEuro =
      IconData(0xe956, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kdocumentCurrencyPound =
      IconData(0xe957, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kdocumentCurrencyRupee =
      IconData(0xe958, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kdocumentCurrencyYen =
      IconData(0xe959, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kdocumentDuplicate =
      IconData(0xe95a, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kdocumentMagnifyingGlass =
      IconData(0xe95b, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kdocumentMinus =
      IconData(0xe95c, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kdocumentPlus =
      IconData(0xe95d, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kdocumentText =
      IconData(0xe95e, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kellipsisHorizontalCircle =
      IconData(0xe95f, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kenvelope =
      IconData(0xe960, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kenvelopeOpen =
      IconData(0xe961, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kexclamationCircle =
      IconData(0xe962, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kexclamationTriangle =
      IconData(0xe963, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData keye =
      IconData(0xe964, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData keyeDropper =
      IconData(0xe965, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData keyeSlash =
      IconData(0xe966, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kfaceFrown =
      IconData(0xe967, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kfaceSmile =
      IconData(0xe968, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kfilm =
      IconData(0xe969, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kfire =
      IconData(0xe96a, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kfolderArrowDown =
      IconData(0xe96d, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kfolderMinus =
      IconData(0xe96e, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kfolderPlus =
      IconData(0xe970, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kfunnel =
      IconData(0xe972, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kgif =
      IconData(0xe973, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kgiftTop =
      IconData(0xe975, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kglobeAlt =
      IconData(0xe976, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kglobeAmericas =
      IconData(0xe977, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kglobeAsiaAustralia =
      IconData(0xe978, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kglobeEuropeAfrica =
      IconData(0xe979, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData khandRaised =
      IconData(0xe97a, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData khandThumbDown =
      IconData(0xe97b, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData khandThumbUp =
      IconData(0xe97c, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kheart =
      IconData(0xe97d, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData khome =
      IconData(0xe97e, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData khomeModern =
      IconData(0xe97f, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kidentification =
      IconData(0xe980, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kinbox =
      IconData(0xe981, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kinboxArrowDown =
      IconData(0xe982, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kinboxStack =
      IconData(0xe983, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kinformationCircle =
      IconData(0xe984, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kkey =
      IconData(0xe985, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData klifebuoy =
      IconData(0xe986, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData klightBulb =
      IconData(0xe987, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData klockClosed =
      IconData(0xe988, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kmagnifyingGlassCircle =
      IconData(0xe98a, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kmegaphone =
      IconData(0xe98d, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kmicrophone =
      IconData(0xe98e, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kminusCircle =
      IconData(0xe98f, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData knewspaper =
      IconData(0xe991, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kpaintBrush =
      IconData(0xe992, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kpaperAirplane =
      IconData(0xe993, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kpencil =
      IconData(0xe996, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kpercentBadge =
      IconData(0xe997, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kphoneArrowDownLeft =
      IconData(0xe999, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kphoneArrowUpRight =
      IconData(0xe99a, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kphoneXMark =
      IconData(0xe99b, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kphoto =
      IconData(0xe99c, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kplayPause =
      IconData(0xe99f, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kplusCircle =
      IconData(0xe9a0, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kpresentationChartLine =
      IconData(0xe9a1, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kpuzzlePiece =
      IconData(0xe9a3, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kquestionMarkCircle =
      IconData(0xe9a4, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kradio =
      IconData(0xe9a5, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kreceiptPercent =
      IconData(0xe9a6, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kreceiptRefund =
      IconData(0xe9a7, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData krectangleGroup =
      IconData(0xe9a8, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData krectangleStack =
      IconData(0xe9a9, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData krocketLaunch =
      IconData(0xe9aa, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kscissors =
      IconData(0xe9ab, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kserver =
      IconData(0xe9ac, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kserverStack =
      IconData(0xe9ad, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kshieldExclamation =
      IconData(0xe9af, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kshoppingBag =
      IconData(0xe9b0, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kshoppingCart =
      IconData(0xe9b1, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData ksparkles =
      IconData(0xe9b2, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kspeakerWave =
      IconData(0xe9b3, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kspeakerXMark =
      IconData(0xe9b4, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData ksquare2Stack =
      IconData(0xe9b5, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData ksquare3Stack3d =
      IconData(0xe9b6, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData ksquares2x2 =
      IconData(0xe9b7, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData ksquaresPlus =
      IconData(0xe9b8, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kswatch =
      IconData(0xe9bd, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData ktableCells =
      IconData(0xe9be, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kticket =
      IconData(0xe9c0, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData ktrash =
      IconData(0xe9c1, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData ktrophy =
      IconData(0xe9c2, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData ktruck =
      IconData(0xe9c3, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData ktv =
      IconData(0xe9c4, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kuser =
      IconData(0xe9c5, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kuserGroup =
      IconData(0xe9c7, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kuserMinus =
      IconData(0xe9c8, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kuserPlus =
      IconData(0xe9c9, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kvideoCamera =
      IconData(0xe9cb, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kvideoCameraSlash =
      IconData(0xe9cc, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kviewColumns =
      IconData(0xe9cd, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kwallet =
      IconData(0xe9ce, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kwrench =
      IconData(0xe9d0, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kwrenchScrewdriver =
      IconData(0xe9d1, fontFamily: _heroicons2FlutterMartComFamily);
  static const IconData kxCircle =
      IconData(0xe9d2, fontFamily: _heroicons2FlutterMartComFamily);

  // Datinger_icon
  static const IconData knotifications80dp000000FILL1Wght400GRAD0Opsz48 =
      IconData(0xe900, fontFamily: _datingerIconFamily);
  static const IconData knotifications80dp000000FILL0Wght400GRAD0Opsz48 =
      IconData(0xe901, fontFamily: _datingerIconFamily);
  static const IconData kforum80dp000000FILL1Wght400GRAD0Opsz48 =
      IconData(0xe902, fontFamily: _datingerIconFamily);
  static const IconData kforum80dp000000FILL0Wght400GRAD0Opsz48 =
      IconData(0xe903, fontFamily: _datingerIconFamily);
  static const IconData kchat80dp000000FILL1Wght400GRAD0Opsz48 =
      IconData(0xe904, fontFamily: _datingerIconFamily);
  static const IconData kchat80dp000000FILL0Wght400GRAD0Opsz48 =
      IconData(0xe905, fontFamily: _datingerIconFamily);
  static const IconData ksms80dp000000FILL1Wght400GRAD0Opsz48 =
      IconData(0xe906, fontFamily: _datingerIconFamily);
  static const IconData ksms80dp000000FILL0Wght400GRAD0Opsz48 =
      IconData(0xe907, fontFamily: _datingerIconFamily);
  static const IconData kperson80dp000000FILL1Wght400GRAD0Opsz48 =
      IconData(0xe908, fontFamily: _datingerIconFamily);
  static const IconData kperson80dp000000FILL0Wght400GRAD0Opsz48 =
      IconData(0xe909, fontFamily: _datingerIconFamily);
  static const IconData kgroup80dp000000FILL0Wght400GRAD0Opsz48 =
      IconData(0xe90a, fontFamily: _datingerIconFamily);
  static const IconData kgroup80dp000000FILL1Wght400GRAD0Opsz48 =
      IconData(0xe90b, fontFamily: _datingerIconFamily);
  static const IconData kawardStar80dp000000FILL1Wght400GRAD0Opsz48 =
      IconData(0xe90c, fontFamily: _datingerIconFamily);
  static const IconData kawardStar80dp000000FILL0Wght400GRAD0Opsz48 =
      IconData(0xe90d, fontFamily: _datingerIconFamily);
  static const IconData kpageInfo80dp000000FILL0Wght400GRAD0Opsz48 =
      IconData(0xe90e, fontFamily: _datingerIconFamily);
  static const IconData ksearch80dp000000FILL1Wght400GRAD0Opsz48 =
      IconData(0xe90f, fontFamily: _datingerIconFamily);
  static const IconData kgrade80dp000000FILL1Wght400GRAD0Opsz48 =
      IconData(0xe910, fontFamily: _datingerIconFamily);
  static const IconData kfavorite80dp000000FILL1Wght400GRAD0Opsz48 =
      IconData(0xe911, fontFamily: _datingerIconFamily);
  static const IconData khome80dp000000FILL1Wght400GRAD0Opsz48 =
      IconData(0xe912, fontFamily: _datingerIconFamily);
  static const IconData kgrade80dp000000FILL0Wght400GRAD0Opsz48 =
      IconData(0xe913, fontFamily: _datingerIconFamily);
  static const IconData khome80dp000000FILL0Wght400GRAD0Opsz48 =
      IconData(0xe914, fontFamily: _datingerIconFamily);
  static const IconData kfavorite80dp000000FILL0Wght400GRAD0Opsz48 =
      IconData(0xe915, fontFamily: _datingerIconFamily);
  static const IconData krefresh80dp000000FILL1Wght400GRAD0Opsz48 =
      IconData(0xe916, fontFamily: _datingerIconFamily);

  // UntitledUi
  static const IconData kactivity =
      IconData(0xe900, fontFamily: _untitledUiFamily);
  static const IconData kactivityHeart =
      IconData(0xe901, fontFamily: _untitledUiFamily);
  static const IconData kairpods =
      IconData(0xe903, fontFamily: _untitledUiFamily);
  static const IconData kalarmClock =
      IconData(0xe904, fontFamily: _untitledUiFamily);
  static const IconData kalarmClockCheck =
      IconData(0xe905, fontFamily: _untitledUiFamily);
  static const IconData kalarmClockMinus =
      IconData(0xe906, fontFamily: _untitledUiFamily);
  static const IconData kalarmClockOff =
      IconData(0xe907, fontFamily: _untitledUiFamily);
  static const IconData kalarmClockPlus =
      IconData(0xe908, fontFamily: _untitledUiFamily);
  static const IconData kalertCircle =
      IconData(0xe909, fontFamily: _untitledUiFamily);
  static const IconData kalertHexagon =
      IconData(0xe90a, fontFamily: _untitledUiFamily);
  static const IconData kalertOctagon =
      IconData(0xe90b, fontFamily: _untitledUiFamily);
  static const IconData kalertSquare =
      IconData(0xe90c, fontFamily: _untitledUiFamily);
  static const IconData kalertTriangle =
      IconData(0xe90d, fontFamily: _untitledUiFamily);
  static const IconData kalignBottom01 =
      IconData(0xe90e, fontFamily: _untitledUiFamily);
  static const IconData kalignBottom02 =
      IconData(0xe90f, fontFamily: _untitledUiFamily);
  static const IconData kalignCenter =
      IconData(0xe910, fontFamily: _untitledUiFamily);
  static const IconData kalignHorizontalCentre01 =
      IconData(0xe911, fontFamily: _untitledUiFamily);
  static const IconData kalignHorizontalCentre02 =
      IconData(0xe912, fontFamily: _untitledUiFamily);
  static const IconData kalignJustify =
      IconData(0xe913, fontFamily: _untitledUiFamily);
  static const IconData kalignLeft =
      IconData(0xe914, fontFamily: _untitledUiFamily);
  static const IconData kalignLeft01 =
      IconData(0xe915, fontFamily: _untitledUiFamily);
  static const IconData kalignLeft02 =
      IconData(0xe916, fontFamily: _untitledUiFamily);
  static const IconData kalignRight =
      IconData(0xe917, fontFamily: _untitledUiFamily);
  static const IconData kalignRight01 =
      IconData(0xe918, fontFamily: _untitledUiFamily);
  static const IconData kalignRight02 =
      IconData(0xe919, fontFamily: _untitledUiFamily);
  static const IconData kalignTop01 =
      IconData(0xe91a, fontFamily: _untitledUiFamily);
  static const IconData kalignTop02 =
      IconData(0xe91b, fontFamily: _untitledUiFamily);
  static const IconData kalignVerticalCenter01 =
      IconData(0xe91c, fontFamily: _untitledUiFamily);
  static const IconData kalignVerticalCenter02 =
      IconData(0xe91d, fontFamily: _untitledUiFamily);
  static const IconData kanchor =
      IconData(0xe91e, fontFamily: _untitledUiFamily);
  static const IconData kannotation =
      IconData(0xe91f, fontFamily: _untitledUiFamily);
  static const IconData kannotationAlert =
      IconData(0xe920, fontFamily: _untitledUiFamily);
  static const IconData kannotationCheck =
      IconData(0xe921, fontFamily: _untitledUiFamily);
  static const IconData kannotationDots =
      IconData(0xe922, fontFamily: _untitledUiFamily);
  static const IconData kannotationHeart =
      IconData(0xe923, fontFamily: _untitledUiFamily);
  static const IconData kannotationInfo =
      IconData(0xe924, fontFamily: _untitledUiFamily);
  static const IconData kannotationPlus =
      IconData(0xe925, fontFamily: _untitledUiFamily);
  static const IconData kannotationQuestion =
      IconData(0xe926, fontFamily: _untitledUiFamily);
  static const IconData kannotationX =
      IconData(0xe927, fontFamily: _untitledUiFamily);
  static const IconData kannouncement01 =
      IconData(0xe928, fontFamily: _untitledUiFamily);
  static const IconData kannouncement02 =
      IconData(0xe929, fontFamily: _untitledUiFamily);
  static const IconData kannouncement03 =
      IconData(0xe92a, fontFamily: _untitledUiFamily);
  static const IconData karrowBlockDown =
      IconData(0xe92c, fontFamily: _untitledUiFamily);
  static const IconData karrowBlockLeft =
      IconData(0xe92d, fontFamily: _untitledUiFamily);
  static const IconData karrowBlockRight =
      IconData(0xe92e, fontFamily: _untitledUiFamily);
  static const IconData karrowBlockUp =
      IconData(0xe92f, fontFamily: _untitledUiFamily);
  static const IconData karrowCircleBrokenDown =
      IconData(0xe930, fontFamily: _untitledUiFamily);
  static const IconData karrowCircleBrokenDownLeft =
      IconData(0xe931, fontFamily: _untitledUiFamily);
  static const IconData karrowCircleBrokenDownRight =
      IconData(0xe932, fontFamily: _untitledUiFamily);
  static const IconData karrowCircleBrokenLeft =
      IconData(0xe933, fontFamily: _untitledUiFamily);
  static const IconData karrowCircleBrokenRight =
      IconData(0xe934, fontFamily: _untitledUiFamily);
  static const IconData karrowCircleBrokenUp =
      IconData(0xe935, fontFamily: _untitledUiFamily);
  static const IconData karrowCircleBrokenUpLeft =
      IconData(0xe936, fontFamily: _untitledUiFamily);
  static const IconData karrowCircleBrokenUpRight =
      IconData(0xe937, fontFamily: _untitledUiFamily);
  static const IconData karrowDown =
      IconData(0xe940, fontFamily: _untitledUiFamily);
  static const IconData karrowDownLeft =
      IconData(0xe941, fontFamily: _untitledUiFamily);
  static const IconData karrowDownRight =
      IconData(0xe942, fontFamily: _untitledUiFamily);
  static const IconData karrowLeft =
      IconData(0xe943, fontFamily: _untitledUiFamily);
  static const IconData karrowNarrowDown =
      IconData(0xe944, fontFamily: _untitledUiFamily);
  static const IconData karrowNarrowDownLeft =
      IconData(0xe945, fontFamily: _untitledUiFamily);
  static const IconData karrowNarrowDownRight =
      IconData(0xe946, fontFamily: _untitledUiFamily);
  static const IconData karrowNarrowLeft =
      IconData(0xe947, fontFamily: _untitledUiFamily);
  static const IconData karrowNarrowRight =
      IconData(0xe948, fontFamily: _untitledUiFamily);
  static const IconData karrowNarrowUp =
      IconData(0xe949, fontFamily: _untitledUiFamily);
  static const IconData karrowNarrowUpLeft =
      IconData(0xe94a, fontFamily: _untitledUiFamily);
  static const IconData karrowNarrowUpRight =
      IconData(0xe94b, fontFamily: _untitledUiFamily);
  static const IconData karrowRight =
      IconData(0xe94c, fontFamily: _untitledUiFamily);
  static const IconData karrowsDown =
      IconData(0xe94d, fontFamily: _untitledUiFamily);
  static const IconData karrowsLeft =
      IconData(0xe94e, fontFamily: _untitledUiFamily);
  static const IconData karrowSquareDown =
      IconData(0xe94f, fontFamily: _untitledUiFamily);
  static const IconData karrowSquareDownLeft =
      IconData(0xe950, fontFamily: _untitledUiFamily);
  static const IconData karrowSquareDownRight =
      IconData(0xe951, fontFamily: _untitledUiFamily);
  static const IconData karrowSquareLeft =
      IconData(0xe952, fontFamily: _untitledUiFamily);
  static const IconData karrowSquareRight =
      IconData(0xe953, fontFamily: _untitledUiFamily);
  static const IconData karrowSquareUp =
      IconData(0xe954, fontFamily: _untitledUiFamily);
  static const IconData karrowSquareUpLeft =
      IconData(0xe955, fontFamily: _untitledUiFamily);
  static const IconData karrowSquareUpRight =
      IconData(0xe956, fontFamily: _untitledUiFamily);
  static const IconData karrowsRight =
      IconData(0xe957, fontFamily: _untitledUiFamily);
  static const IconData karrowsTriangle =
      IconData(0xe958, fontFamily: _untitledUiFamily);
  static const IconData karrowsUp =
      IconData(0xe959, fontFamily: _untitledUiFamily);
  static const IconData karrowUp =
      IconData(0xe95a, fontFamily: _untitledUiFamily);
  static const IconData karrowUpLeft =
      IconData(0xe95b, fontFamily: _untitledUiFamily);
  static const IconData karrowUpRight =
      IconData(0xe95c, fontFamily: _untitledUiFamily);
  static const IconData kasterisk01 =
      IconData(0xe95d, fontFamily: _untitledUiFamily);
  static const IconData kasterisk02 =
      IconData(0xe95e, fontFamily: _untitledUiFamily);
  static const IconData katom01 =
      IconData(0xe95f, fontFamily: _untitledUiFamily);
  static const IconData katom02 =
      IconData(0xe960, fontFamily: _untitledUiFamily);
  static const IconData katSign =
      IconData(0xe961, fontFamily: _untitledUiFamily);
  static const IconData kattachment01 =
      IconData(0xe962, fontFamily: _untitledUiFamily);
  static const IconData kattachment02 =
      IconData(0xe963, fontFamily: _untitledUiFamily);
  static const IconData kaward01 =
      IconData(0xe964, fontFamily: _untitledUiFamily);
  static const IconData kaward02 =
      IconData(0xe965, fontFamily: _untitledUiFamily);
  static const IconData kaward03 =
      IconData(0xe966, fontFamily: _untitledUiFamily);
  static const IconData kaward04 =
      IconData(0xe967, fontFamily: _untitledUiFamily);
  static const IconData kaward05 =
      IconData(0xe968, fontFamily: _untitledUiFamily);
  static const IconData kbackpack =
      IconData(0xe969, fontFamily: _untitledUiFamily);
  static const IconData kbank = IconData(0xe96a, fontFamily: _untitledUiFamily);
  static const IconData kbankNote01 =
      IconData(0xe96b, fontFamily: _untitledUiFamily);
  static const IconData kbankNote02 =
      IconData(0xe96c, fontFamily: _untitledUiFamily);
  static const IconData kbankNote03 =
      IconData(0xe96d, fontFamily: _untitledUiFamily);
  static const IconData kbarChart01 =
      IconData(0xe96e, fontFamily: _untitledUiFamily);
  static const IconData kbarChart02 =
      IconData(0xe96f, fontFamily: _untitledUiFamily);
  static const IconData kbarChart03 =
      IconData(0xe970, fontFamily: _untitledUiFamily);
  static const IconData kbarChart04 =
      IconData(0xe971, fontFamily: _untitledUiFamily);
  static const IconData kbarChart05 =
      IconData(0xe972, fontFamily: _untitledUiFamily);
  static const IconData kbarChart06 =
      IconData(0xe973, fontFamily: _untitledUiFamily);
  static const IconData kbarChart07 =
      IconData(0xe974, fontFamily: _untitledUiFamily);
  static const IconData kbarChart08 =
      IconData(0xe975, fontFamily: _untitledUiFamily);
  static const IconData kbarChart09 =
      IconData(0xe976, fontFamily: _untitledUiFamily);
  static const IconData kbarChart10 =
      IconData(0xe977, fontFamily: _untitledUiFamily);
  static const IconData kbarChart11 =
      IconData(0xe978, fontFamily: _untitledUiFamily);
  static const IconData kbarChart12 =
      IconData(0xe979, fontFamily: _untitledUiFamily);
  static const IconData kbarChartCircle01 =
      IconData(0xe97a, fontFamily: _untitledUiFamily);
  static const IconData kbarChartCircle02 =
      IconData(0xe97b, fontFamily: _untitledUiFamily);
  static const IconData kbarChartCircle03 =
      IconData(0xe97c, fontFamily: _untitledUiFamily);
  static const IconData kbarChartSquare01 =
      IconData(0xe97d, fontFamily: _untitledUiFamily);
  static const IconData kbarChartSquare02 =
      IconData(0xe97e, fontFamily: _untitledUiFamily);
  static const IconData kbarChartSquare03 =
      IconData(0xe97f, fontFamily: _untitledUiFamily);
  static const IconData kbarChartSquareDown =
      IconData(0xe980, fontFamily: _untitledUiFamily);
  static const IconData kbarChartSquareMinus =
      IconData(0xe981, fontFamily: _untitledUiFamily);
  static const IconData kbarChartSquarePlus =
      IconData(0xe982, fontFamily: _untitledUiFamily);
  static const IconData kbarChartSquareUp =
      IconData(0xe983, fontFamily: _untitledUiFamily);
  static const IconData kbarLineChart =
      IconData(0xe984, fontFamily: _untitledUiFamily);
  static const IconData kbatteryCharging01 =
      IconData(0xe985, fontFamily: _untitledUiFamily);
  static const IconData kbatteryCharging02 =
      IconData(0xe986, fontFamily: _untitledUiFamily);
  static const IconData kbatteryEmpty =
      IconData(0xe987, fontFamily: _untitledUiFamily);
  static const IconData kbatteryFull =
      IconData(0xe988, fontFamily: _untitledUiFamily);
  static const IconData kbatteryLow =
      IconData(0xe989, fontFamily: _untitledUiFamily);
  static const IconData kbatteryMid =
      IconData(0xe98a, fontFamily: _untitledUiFamily);
  static const IconData kbeaker01 =
      IconData(0xe98b, fontFamily: _untitledUiFamily);
  static const IconData kbeaker02 =
      IconData(0xe98c, fontFamily: _untitledUiFamily);
  static const IconData kbell01 =
      IconData(0xe98d, fontFamily: _untitledUiFamily);
  static const IconData kbell02 =
      IconData(0xe98e, fontFamily: _untitledUiFamily);
  static const IconData kbell03 =
      IconData(0xe98f, fontFamily: _untitledUiFamily);
  static const IconData kbell04 =
      IconData(0xe990, fontFamily: _untitledUiFamily);
  static const IconData kbellMinus =
      IconData(0xe991, fontFamily: _untitledUiFamily);
  static const IconData kbellOff01 =
      IconData(0xe992, fontFamily: _untitledUiFamily);
  static const IconData kbellOff02 =
      IconData(0xe993, fontFamily: _untitledUiFamily);
  static const IconData kbellOff03 =
      IconData(0xe994, fontFamily: _untitledUiFamily);
  static const IconData kbellPlus =
      IconData(0xe995, fontFamily: _untitledUiFamily);
  static const IconData kbellRinging01 =
      IconData(0xe996, fontFamily: _untitledUiFamily);
  static const IconData kbellRinging02 =
      IconData(0xe997, fontFamily: _untitledUiFamily);
  static const IconData kbellRinging03 =
      IconData(0xe998, fontFamily: _untitledUiFamily);
  static const IconData kbellRinging04 =
      IconData(0xe999, fontFamily: _untitledUiFamily);
  static const IconData kbezierCurve01 =
      IconData(0xe99a, fontFamily: _untitledUiFamily);
  static const IconData kbezierCurve02 =
      IconData(0xe99b, fontFamily: _untitledUiFamily);
  static const IconData kbezierCurve03 =
      IconData(0xe99c, fontFamily: _untitledUiFamily);
  static const IconData kbluetoothConnect =
      IconData(0xe99d, fontFamily: _untitledUiFamily);
  static const IconData kbluetoothOff =
      IconData(0xe99e, fontFamily: _untitledUiFamily);
  static const IconData kbluetoothOn =
      IconData(0xe99f, fontFamily: _untitledUiFamily);
  static const IconData kbluetoothSignal =
      IconData(0xe9a0, fontFamily: _untitledUiFamily);
  static const IconData kbold01 =
      IconData(0xe9a1, fontFamily: _untitledUiFamily);
  static const IconData kbold02 =
      IconData(0xe9a2, fontFamily: _untitledUiFamily);
  static const IconData kboldSquare =
      IconData(0xe9a3, fontFamily: _untitledUiFamily);
  static const IconData kbookClosed =
      IconData(0xe9a4, fontFamily: _untitledUiFamily);
  static const IconData kbookmarkAdd =
      IconData(0xe9a6, fontFamily: _untitledUiFamily);
  static const IconData kbookmarkCheck =
      IconData(0xe9a7, fontFamily: _untitledUiFamily);
  static const IconData kbookmarkMinus =
      IconData(0xe9a8, fontFamily: _untitledUiFamily);
  static const IconData kbookmarkX =
      IconData(0xe9a9, fontFamily: _untitledUiFamily);
  static const IconData kbookOpen01 =
      IconData(0xe9aa, fontFamily: _untitledUiFamily);
  static const IconData kbookOpen02 =
      IconData(0xe9ab, fontFamily: _untitledUiFamily);
  static const IconData kbox = IconData(0xe9ac, fontFamily: _untitledUiFamily);
  static const IconData kbrackets =
      IconData(0xe9ad, fontFamily: _untitledUiFamily);
  static const IconData kbracketsCheck =
      IconData(0xe9ae, fontFamily: _untitledUiFamily);
  static const IconData kbracketsEllipses =
      IconData(0xe9af, fontFamily: _untitledUiFamily);
  static const IconData kbracketsMinus =
      IconData(0xe9b0, fontFamily: _untitledUiFamily);
  static const IconData kbracketsPlus =
      IconData(0xe9b1, fontFamily: _untitledUiFamily);
  static const IconData kbracketsSlash =
      IconData(0xe9b2, fontFamily: _untitledUiFamily);
  static const IconData kbracketsX =
      IconData(0xe9b3, fontFamily: _untitledUiFamily);
  static const IconData kbriefcase01 =
      IconData(0xe9b4, fontFamily: _untitledUiFamily);
  static const IconData kbriefcase02 =
      IconData(0xe9b5, fontFamily: _untitledUiFamily);
  static const IconData kbrowser =
      IconData(0xe9b6, fontFamily: _untitledUiFamily);
  static const IconData kbrush01 =
      IconData(0xe9b7, fontFamily: _untitledUiFamily);
  static const IconData kbrush02 =
      IconData(0xe9b8, fontFamily: _untitledUiFamily);
  static const IconData kbrush03 =
      IconData(0xe9b9, fontFamily: _untitledUiFamily);
  static const IconData kbuilding05 =
      IconData(0xe9be, fontFamily: _untitledUiFamily);
  static const IconData kbuilding06 =
      IconData(0xe9bf, fontFamily: _untitledUiFamily);
  static const IconData kbuilding07 =
      IconData(0xe9c0, fontFamily: _untitledUiFamily);
  static const IconData kbuilding08 =
      IconData(0xe9c1, fontFamily: _untitledUiFamily);
  static const IconData kbus = IconData(0xe9c2, fontFamily: _untitledUiFamily);
  static const IconData kcalendarCheck01 =
      IconData(0xe9c5, fontFamily: _untitledUiFamily);
  static const IconData kcalendarCheck02 =
      IconData(0xe9c6, fontFamily: _untitledUiFamily);
  static const IconData kcalendarDate =
      IconData(0xe9c7, fontFamily: _untitledUiFamily);
  static const IconData kcalendarHeart01 =
      IconData(0xe9c8, fontFamily: _untitledUiFamily);
  static const IconData kcalendarHeart02 =
      IconData(0xe9c9, fontFamily: _untitledUiFamily);
  static const IconData kcalendarMinus01 =
      IconData(0xe9ca, fontFamily: _untitledUiFamily);
  static const IconData kcalendarMinus02 =
      IconData(0xe9cb, fontFamily: _untitledUiFamily);
  static const IconData kcalendarPlus01 =
      IconData(0xe9cc, fontFamily: _untitledUiFamily);
  static const IconData kcalendarPlus02 =
      IconData(0xe9cd, fontFamily: _untitledUiFamily);
  static const IconData kcamera01 =
      IconData(0xe9ce, fontFamily: _untitledUiFamily);
  static const IconData kcamera02 =
      IconData(0xe9cf, fontFamily: _untitledUiFamily);
  static const IconData kcamera03 =
      IconData(0xe9d0, fontFamily: _untitledUiFamily);
  static const IconData kcameraLens =
      IconData(0xe9d1, fontFamily: _untitledUiFamily);
  static const IconData kcameraOff =
      IconData(0xe9d2, fontFamily: _untitledUiFamily);
  static const IconData kcameraPlus =
      IconData(0xe9d3, fontFamily: _untitledUiFamily);
  static const IconData kcar01 =
      IconData(0xe9d4, fontFamily: _untitledUiFamily);
  static const IconData kcar02 =
      IconData(0xe9d5, fontFamily: _untitledUiFamily);
  static const IconData kcertificate01 =
      IconData(0xe9d6, fontFamily: _untitledUiFamily);
  static const IconData kcertificate02 =
      IconData(0xe9d7, fontFamily: _untitledUiFamily);
  static const IconData kchartBreakoutCircle =
      IconData(0xe9d8, fontFamily: _untitledUiFamily);
  static const IconData kchartBreakoutSquare =
      IconData(0xe9d9, fontFamily: _untitledUiFamily);
  static const IconData kcheckCircleBroken =
      IconData(0xe9dc, fontFamily: _untitledUiFamily);
  static const IconData kcheckDone01 =
      IconData(0xe9dd, fontFamily: _untitledUiFamily);
  static const IconData kcheckDone02 =
      IconData(0xe9de, fontFamily: _untitledUiFamily);
  static const IconData kcheckHeart =
      IconData(0xe9df, fontFamily: _untitledUiFamily);
  static const IconData kcheckSquare =
      IconData(0xe9e0, fontFamily: _untitledUiFamily);
  static const IconData kcheckSquareBroken =
      IconData(0xe9e1, fontFamily: _untitledUiFamily);
  static const IconData kcheckVerified01 =
      IconData(0xe9e2, fontFamily: _untitledUiFamily);
  static const IconData kcheckVerified02 =
      IconData(0xe9e3, fontFamily: _untitledUiFamily);
  static const IconData kcheckVerified03 =
      IconData(0xe9e4, fontFamily: _untitledUiFamily);
  static const IconData kchevronDownDouble =
      IconData(0xe9e6, fontFamily: _untitledUiFamily);
  static const IconData kchevronLeftDouble =
      IconData(0xe9e8, fontFamily: _untitledUiFamily);
  static const IconData kchevronRightDouble =
      IconData(0xe9ea, fontFamily: _untitledUiFamily);
  static const IconData kchevronSelectorHorizontal =
      IconData(0xe9eb, fontFamily: _untitledUiFamily);
  static const IconData kchevronSelectorVertical =
      IconData(0xe9ec, fontFamily: _untitledUiFamily);
  static const IconData kchevronUpDouble =
      IconData(0xe9ee, fontFamily: _untitledUiFamily);
  static const IconData kchromeCast =
      IconData(0xe9ef, fontFamily: _untitledUiFamily);
  static const IconData kcircleCut =
      IconData(0xe9f1, fontFamily: _untitledUiFamily);
  static const IconData kclapperboard =
      IconData(0xe9f2, fontFamily: _untitledUiFamily);
  static const IconData kclipboardAttachment =
      IconData(0xe9f4, fontFamily: _untitledUiFamily);
  static const IconData kclipboardCheck =
      IconData(0xe9f5, fontFamily: _untitledUiFamily);
  static const IconData kclipboardDownload =
      IconData(0xe9f6, fontFamily: _untitledUiFamily);
  static const IconData kclipboardMinus =
      IconData(0xe9f7, fontFamily: _untitledUiFamily);
  static const IconData kclipboardPlus =
      IconData(0xe9f8, fontFamily: _untitledUiFamily);
  static const IconData kclipboardX =
      IconData(0xe9f9, fontFamily: _untitledUiFamily);
  static const IconData kclockCheck =
      IconData(0xe9fb, fontFamily: _untitledUiFamily);
  static const IconData kclockFastForward =
      IconData(0xe9fc, fontFamily: _untitledUiFamily);
  static const IconData kclockPlus =
      IconData(0xe9fd, fontFamily: _untitledUiFamily);
  static const IconData kclockRefresh =
      IconData(0xe9fe, fontFamily: _untitledUiFamily);
  static const IconData kclockRewind =
      IconData(0xe9ff, fontFamily: _untitledUiFamily);
  static const IconData kclockSnooze =
      IconData(0xea00, fontFamily: _untitledUiFamily);
  static const IconData kclockStopwatch =
      IconData(0xea01, fontFamily: _untitledUiFamily);
  static const IconData kcloud01 =
      IconData(0xea02, fontFamily: _untitledUiFamily);
  static const IconData kcloud02 =
      IconData(0xea03, fontFamily: _untitledUiFamily);
  static const IconData kcloud03 =
      IconData(0xea04, fontFamily: _untitledUiFamily);
  static const IconData kcloudBlank01 =
      IconData(0xea05, fontFamily: _untitledUiFamily);
  static const IconData kcloudBlank02 =
      IconData(0xea06, fontFamily: _untitledUiFamily);
  static const IconData kcloudLightning =
      IconData(0xea07, fontFamily: _untitledUiFamily);
  static const IconData kcloudMoon =
      IconData(0xea08, fontFamily: _untitledUiFamily);
  static const IconData kcloudRaining01 =
      IconData(0xea0a, fontFamily: _untitledUiFamily);
  static const IconData kcloudRaining02 =
      IconData(0xea0b, fontFamily: _untitledUiFamily);
  static const IconData kcloudRaining03 =
      IconData(0xea0c, fontFamily: _untitledUiFamily);
  static const IconData kcloudRaining04 =
      IconData(0xea0d, fontFamily: _untitledUiFamily);
  static const IconData kcloudRaining05 =
      IconData(0xea0e, fontFamily: _untitledUiFamily);
  static const IconData kcloudRaining06 =
      IconData(0xea0f, fontFamily: _untitledUiFamily);
  static const IconData kcloudSnowing01 =
      IconData(0xea10, fontFamily: _untitledUiFamily);
  static const IconData kcloudSnowing02 =
      IconData(0xea11, fontFamily: _untitledUiFamily);
  static const IconData kcloudSun01 =
      IconData(0xea12, fontFamily: _untitledUiFamily);
  static const IconData kcloudSun02 =
      IconData(0xea13, fontFamily: _untitledUiFamily);
  static const IconData kcloudSun03 =
      IconData(0xea14, fontFamily: _untitledUiFamily);
  static const IconData kcode01 =
      IconData(0xea15, fontFamily: _untitledUiFamily);
  static const IconData kcode02 =
      IconData(0xea16, fontFamily: _untitledUiFamily);
  static const IconData kcodeBrowser =
      IconData(0xea17, fontFamily: _untitledUiFamily);
  static const IconData kcodeCircle01 =
      IconData(0xea18, fontFamily: _untitledUiFamily);
  static const IconData kcodeCircle02 =
      IconData(0xea19, fontFamily: _untitledUiFamily);
  static const IconData kcodeCircle03 =
      IconData(0xea1a, fontFamily: _untitledUiFamily);
  static const IconData kcodepen =
      IconData(0xea1b, fontFamily: _untitledUiFamily);
  static const IconData kcodeSnippet01 =
      IconData(0xea1c, fontFamily: _untitledUiFamily);
  static const IconData kcodeSnippet02 =
      IconData(0xea1d, fontFamily: _untitledUiFamily);
  static const IconData kcodeSquare01 =
      IconData(0xea1e, fontFamily: _untitledUiFamily);
  static const IconData kcodeSquare02 =
      IconData(0xea1f, fontFamily: _untitledUiFamily);
  static const IconData kcoins01 =
      IconData(0xea20, fontFamily: _untitledUiFamily);
  static const IconData kcoins02 =
      IconData(0xea21, fontFamily: _untitledUiFamily);
  static const IconData kcoins03 =
      IconData(0xea22, fontFamily: _untitledUiFamily);
  static const IconData kcoins04 =
      IconData(0xea23, fontFamily: _untitledUiFamily);
  static const IconData kcoinsHand =
      IconData(0xea24, fontFamily: _untitledUiFamily);
  static const IconData kcoinsStacked01 =
      IconData(0xea25, fontFamily: _untitledUiFamily);
  static const IconData kcoinsStacked02 =
      IconData(0xea26, fontFamily: _untitledUiFamily);
  static const IconData kcoinsStacked03 =
      IconData(0xea27, fontFamily: _untitledUiFamily);
  static const IconData kcoinsStacked04 =
      IconData(0xea28, fontFamily: _untitledUiFamily);
  static const IconData kcoinsSwap01 =
      IconData(0xea29, fontFamily: _untitledUiFamily);
  static const IconData kcoinsSwap02 =
      IconData(0xea2a, fontFamily: _untitledUiFamily);
  static const IconData kcolors =
      IconData(0xea2b, fontFamily: _untitledUiFamily);
  static const IconData kcolumns01 =
      IconData(0xea2c, fontFamily: _untitledUiFamily);
  static const IconData kcolumns02 =
      IconData(0xea2d, fontFamily: _untitledUiFamily);
  static const IconData kcolumns03 =
      IconData(0xea2e, fontFamily: _untitledUiFamily);
  static const IconData kcompass01 =
      IconData(0xea31, fontFamily: _untitledUiFamily);
  static const IconData kcompass02 =
      IconData(0xea32, fontFamily: _untitledUiFamily);
  static const IconData kcompass03 =
      IconData(0xea33, fontFamily: _untitledUiFamily);
  static const IconData kcontainer =
      IconData(0xea34, fontFamily: _untitledUiFamily);
  static const IconData kcontrast01 =
      IconData(0xea35, fontFamily: _untitledUiFamily);
  static const IconData kcontrast02 =
      IconData(0xea36, fontFamily: _untitledUiFamily);
  static const IconData kcontrast03 =
      IconData(0xea37, fontFamily: _untitledUiFamily);
  static const IconData kcopy01 =
      IconData(0xea38, fontFamily: _untitledUiFamily);
  static const IconData kcopy02 =
      IconData(0xea39, fontFamily: _untitledUiFamily);
  static const IconData kcopy03 =
      IconData(0xea3a, fontFamily: _untitledUiFamily);
  static const IconData kcopy04 =
      IconData(0xea3b, fontFamily: _untitledUiFamily);
  static const IconData kcopy05 =
      IconData(0xea3c, fontFamily: _untitledUiFamily);
  static const IconData kcopy06 =
      IconData(0xea3d, fontFamily: _untitledUiFamily);
  static const IconData kcopy07 =
      IconData(0xea3e, fontFamily: _untitledUiFamily);
  static const IconData kcornerDownLeft =
      IconData(0xea3f, fontFamily: _untitledUiFamily);
  static const IconData kcornerDownRight =
      IconData(0xea40, fontFamily: _untitledUiFamily);
  static const IconData kcornerLeftDown =
      IconData(0xea41, fontFamily: _untitledUiFamily);
  static const IconData kcornerLeftUp =
      IconData(0xea42, fontFamily: _untitledUiFamily);
  static const IconData kcornerRightDown =
      IconData(0xea43, fontFamily: _untitledUiFamily);
  static const IconData kcornerRightUp =
      IconData(0xea44, fontFamily: _untitledUiFamily);
  static const IconData kcornerUpLeft =
      IconData(0xea45, fontFamily: _untitledUiFamily);
  static const IconData kcornerUpRight =
      IconData(0xea46, fontFamily: _untitledUiFamily);
  static const IconData kcpuChip01 =
      IconData(0xea47, fontFamily: _untitledUiFamily);
  static const IconData kcpuChip02 =
      IconData(0xea48, fontFamily: _untitledUiFamily);
  static const IconData kcreditCardCheck =
      IconData(0xea4b, fontFamily: _untitledUiFamily);
  static const IconData kcreditCardDown =
      IconData(0xea4c, fontFamily: _untitledUiFamily);
  static const IconData kcreditCardDownload =
      IconData(0xea4d, fontFamily: _untitledUiFamily);
  static const IconData kcreditCardEdit =
      IconData(0xea4e, fontFamily: _untitledUiFamily);
  static const IconData kcreditCardLock =
      IconData(0xea4f, fontFamily: _untitledUiFamily);
  static const IconData kcreditCardMinus =
      IconData(0xea50, fontFamily: _untitledUiFamily);
  static const IconData kcreditCardPlus =
      IconData(0xea51, fontFamily: _untitledUiFamily);
  static const IconData kcreditCardRefresh =
      IconData(0xea52, fontFamily: _untitledUiFamily);
  static const IconData kcreditCardSearch =
      IconData(0xea53, fontFamily: _untitledUiFamily);
  static const IconData kcreditCardShield =
      IconData(0xea54, fontFamily: _untitledUiFamily);
  static const IconData kcreditCardUp =
      IconData(0xea55, fontFamily: _untitledUiFamily);
  static const IconData kcreditCardUpload =
      IconData(0xea56, fontFamily: _untitledUiFamily);
  static const IconData kcreditCardX =
      IconData(0xea57, fontFamily: _untitledUiFamily);
  static const IconData kcrop01 =
      IconData(0xea58, fontFamily: _untitledUiFamily);
  static const IconData kcrop02 =
      IconData(0xea59, fontFamily: _untitledUiFamily);
  static const IconData kcryptocurrency01 =
      IconData(0xea5a, fontFamily: _untitledUiFamily);
  static const IconData kcryptocurrency02 =
      IconData(0xea5b, fontFamily: _untitledUiFamily);
  static const IconData kcryptocurrency03 =
      IconData(0xea5c, fontFamily: _untitledUiFamily);
  static const IconData kcryptocurrency04 =
      IconData(0xea5d, fontFamily: _untitledUiFamily);
  static const IconData kcube01 =
      IconData(0xea5e, fontFamily: _untitledUiFamily);
  static const IconData kcube02 =
      IconData(0xea5f, fontFamily: _untitledUiFamily);
  static const IconData kcube03 =
      IconData(0xea60, fontFamily: _untitledUiFamily);
  static const IconData kcube04 =
      IconData(0xea61, fontFamily: _untitledUiFamily);
  static const IconData kcubeOutline =
      IconData(0xea62, fontFamily: _untitledUiFamily);
  static const IconData kcurrencyBitcoin =
      IconData(0xea63, fontFamily: _untitledUiFamily);
  static const IconData kcurrencyBitcoinCircle =
      IconData(0xea64, fontFamily: _untitledUiFamily);
  static const IconData kcurrencyDollarCircle =
      IconData(0xea66, fontFamily: _untitledUiFamily);
  static const IconData kcurrencyEthereum =
      IconData(0xea67, fontFamily: _untitledUiFamily);
  static const IconData kcurrencyEthereumCircle =
      IconData(0xea68, fontFamily: _untitledUiFamily);
  static const IconData kcurrencyEuroCircle =
      IconData(0xea6a, fontFamily: _untitledUiFamily);
  static const IconData kcurrencyPoundCircle =
      IconData(0xea6c, fontFamily: _untitledUiFamily);
  static const IconData kcurrencyRuble =
      IconData(0xea6d, fontFamily: _untitledUiFamily);
  static const IconData kcurrencyRubleCircle =
      IconData(0xea6e, fontFamily: _untitledUiFamily);
  static const IconData kcurrencyRupeeCircle =
      IconData(0xea70, fontFamily: _untitledUiFamily);
  static const IconData kcurrencyYenCircle =
      IconData(0xea72, fontFamily: _untitledUiFamily);
  static const IconData kcursor01 =
      IconData(0xea73, fontFamily: _untitledUiFamily);
  static const IconData kcursor02 =
      IconData(0xea74, fontFamily: _untitledUiFamily);
  static const IconData kcursor03 =
      IconData(0xea75, fontFamily: _untitledUiFamily);
  static const IconData kcursor04 =
      IconData(0xea76, fontFamily: _untitledUiFamily);
  static const IconData kcursorBox =
      IconData(0xea77, fontFamily: _untitledUiFamily);
  static const IconData kcursorClick01 =
      IconData(0xea78, fontFamily: _untitledUiFamily);
  static const IconData kcursorClick02 =
      IconData(0xea79, fontFamily: _untitledUiFamily);
  static const IconData kdatabase01 =
      IconData(0xea7b, fontFamily: _untitledUiFamily);
  static const IconData kdatabase02 =
      IconData(0xea7c, fontFamily: _untitledUiFamily);
  static const IconData kdatabase03 =
      IconData(0xea7d, fontFamily: _untitledUiFamily);
  static const IconData kdataflow01 =
      IconData(0xea7e, fontFamily: _untitledUiFamily);
  static const IconData kdataflow02 =
      IconData(0xea7f, fontFamily: _untitledUiFamily);
  static const IconData kdataflow03 =
      IconData(0xea80, fontFamily: _untitledUiFamily);
  static const IconData kdataflow04 =
      IconData(0xea81, fontFamily: _untitledUiFamily);
  static const IconData kdelete =
      IconData(0xea82, fontFamily: _untitledUiFamily);
  static const IconData kdiamond01 =
      IconData(0xea83, fontFamily: _untitledUiFamily);
  static const IconData kdiamond02 =
      IconData(0xea84, fontFamily: _untitledUiFamily);
  static const IconData kdice1 =
      IconData(0xea85, fontFamily: _untitledUiFamily);
  static const IconData kdice2 =
      IconData(0xea86, fontFamily: _untitledUiFamily);
  static const IconData kdice3 =
      IconData(0xea87, fontFamily: _untitledUiFamily);
  static const IconData kdice4 =
      IconData(0xea88, fontFamily: _untitledUiFamily);
  static const IconData kdice5 =
      IconData(0xea89, fontFamily: _untitledUiFamily);
  static const IconData kdice6 =
      IconData(0xea8a, fontFamily: _untitledUiFamily);
  static const IconData kdisc01 =
      IconData(0xea8b, fontFamily: _untitledUiFamily);
  static const IconData kdisc02 =
      IconData(0xea8c, fontFamily: _untitledUiFamily);
  static const IconData kdistributeSpacingHorizontal =
      IconData(0xea8d, fontFamily: _untitledUiFamily);
  static const IconData kdistributeSpacingVertical =
      IconData(0xea8e, fontFamily: _untitledUiFamily);
  static const IconData kdivide01 =
      IconData(0xea8f, fontFamily: _untitledUiFamily);
  static const IconData kdivide02 =
      IconData(0xea90, fontFamily: _untitledUiFamily);
  static const IconData kdivide03 =
      IconData(0xea91, fontFamily: _untitledUiFamily);
  static const IconData kdivider =
      IconData(0xea92, fontFamily: _untitledUiFamily);
  static const IconData kdotpoints01 =
      IconData(0xea93, fontFamily: _untitledUiFamily);
  static const IconData kdotpoints02 =
      IconData(0xea94, fontFamily: _untitledUiFamily);
  static const IconData kdotsGrid =
      IconData(0xea95, fontFamily: _untitledUiFamily);
  static const IconData kdotsHorizontal =
      IconData(0xea96, fontFamily: _untitledUiFamily);
  static const IconData kdotsVertical =
      IconData(0xea97, fontFamily: _untitledUiFamily);
  static const IconData kdownload01 =
      IconData(0xea98, fontFamily: _untitledUiFamily);
  static const IconData kdownload02 =
      IconData(0xea99, fontFamily: _untitledUiFamily);
  static const IconData kdownload03 =
      IconData(0xea9a, fontFamily: _untitledUiFamily);
  static const IconData kdownload04 =
      IconData(0xea9b, fontFamily: _untitledUiFamily);
  static const IconData kdownloadCloud01 =
      IconData(0xea9c, fontFamily: _untitledUiFamily);
  static const IconData kdownloadCloud02 =
      IconData(0xea9d, fontFamily: _untitledUiFamily);
  static const IconData kdrop = IconData(0xea9e, fontFamily: _untitledUiFamily);
  static const IconData kdroplets01 =
      IconData(0xea9f, fontFamily: _untitledUiFamily);
  static const IconData kdroplets02 =
      IconData(0xeaa0, fontFamily: _untitledUiFamily);
  static const IconData kdroplets03 =
      IconData(0xeaa1, fontFamily: _untitledUiFamily);
  static const IconData kdropper =
      IconData(0xeaa2, fontFamily: _untitledUiFamily);
  static const IconData kedit01 =
      IconData(0xeaa3, fontFamily: _untitledUiFamily);
  static const IconData kedit02 =
      IconData(0xeaa4, fontFamily: _untitledUiFamily);
  static const IconData kedit03 =
      IconData(0xeaa5, fontFamily: _untitledUiFamily);
  static const IconData kedit04 =
      IconData(0xeaa6, fontFamily: _untitledUiFamily);
  static const IconData kedit05 =
      IconData(0xeaa7, fontFamily: _untitledUiFamily);
  static const IconData kequal =
      IconData(0xeaa8, fontFamily: _untitledUiFamily);
  static const IconData kequalNot =
      IconData(0xeaa9, fontFamily: _untitledUiFamily);
  static const IconData keraser =
      IconData(0xeaaa, fontFamily: _untitledUiFamily);
  static const IconData kexpand01 =
      IconData(0xeaab, fontFamily: _untitledUiFamily);
  static const IconData kexpand02 =
      IconData(0xeaac, fontFamily: _untitledUiFamily);
  static const IconData kexpand03 =
      IconData(0xeaad, fontFamily: _untitledUiFamily);
  static const IconData kexpand04 =
      IconData(0xeaae, fontFamily: _untitledUiFamily);
  static const IconData kexpand05 =
      IconData(0xeaaf, fontFamily: _untitledUiFamily);
  static const IconData kexpand06 =
      IconData(0xeab0, fontFamily: _untitledUiFamily);
  static const IconData keyeOff =
      IconData(0xeab2, fontFamily: _untitledUiFamily);
  static const IconData kfaceContent =
      IconData(0xeab3, fontFamily: _untitledUiFamily);
  static const IconData kfaceHappy =
      IconData(0xeab5, fontFamily: _untitledUiFamily);
  static const IconData kfaceId =
      IconData(0xeab6, fontFamily: _untitledUiFamily);
  static const IconData kfaceIdSquare =
      IconData(0xeab7, fontFamily: _untitledUiFamily);
  static const IconData kfaceNeutral =
      IconData(0xeab8, fontFamily: _untitledUiFamily);
  static const IconData kfaceSad =
      IconData(0xeab9, fontFamily: _untitledUiFamily);
  static const IconData kfaceWink =
      IconData(0xeabb, fontFamily: _untitledUiFamily);
  static const IconData kfastBackward =
      IconData(0xeabc, fontFamily: _untitledUiFamily);
  static const IconData kfastForward =
      IconData(0xeabd, fontFamily: _untitledUiFamily);
  static const IconData kfeather =
      IconData(0xeabe, fontFamily: _untitledUiFamily);
  static const IconData kfile01 =
      IconData(0xeac0, fontFamily: _untitledUiFamily);
  static const IconData kfile02 =
      IconData(0xeac1, fontFamily: _untitledUiFamily);
  static const IconData kfile03 =
      IconData(0xeac2, fontFamily: _untitledUiFamily);
  static const IconData kfile04 =
      IconData(0xeac3, fontFamily: _untitledUiFamily);
  static const IconData kfile05 =
      IconData(0xeac4, fontFamily: _untitledUiFamily);
  static const IconData kfile06 =
      IconData(0xeac5, fontFamily: _untitledUiFamily);
  static const IconData kfile07 =
      IconData(0xeac6, fontFamily: _untitledUiFamily);
  static const IconData kfileAttachment01 =
      IconData(0xeac7, fontFamily: _untitledUiFamily);
  static const IconData kfileAttachment02 =
      IconData(0xeac8, fontFamily: _untitledUiFamily);
  static const IconData kfileAttachment03 =
      IconData(0xeac9, fontFamily: _untitledUiFamily);
  static const IconData kfileAttachment04 =
      IconData(0xeaca, fontFamily: _untitledUiFamily);
  static const IconData kfileAttachment05 =
      IconData(0xeacb, fontFamily: _untitledUiFamily);
  static const IconData kfileCheck01 =
      IconData(0xeacc, fontFamily: _untitledUiFamily);
  static const IconData kfileCheck02 =
      IconData(0xeacd, fontFamily: _untitledUiFamily);
  static const IconData kfileCheck03 =
      IconData(0xeace, fontFamily: _untitledUiFamily);
  static const IconData kfileCode01 =
      IconData(0xeacf, fontFamily: _untitledUiFamily);
  static const IconData kfileCode02 =
      IconData(0xead0, fontFamily: _untitledUiFamily);
  static const IconData kfileDownload01 =
      IconData(0xead1, fontFamily: _untitledUiFamily);
  static const IconData kfileDownload02 =
      IconData(0xead2, fontFamily: _untitledUiFamily);
  static const IconData kfileDownload03 =
      IconData(0xead3, fontFamily: _untitledUiFamily);
  static const IconData kfileHeart01 =
      IconData(0xead4, fontFamily: _untitledUiFamily);
  static const IconData kfileHeart02 =
      IconData(0xead5, fontFamily: _untitledUiFamily);
  static const IconData kfileHeart03 =
      IconData(0xead6, fontFamily: _untitledUiFamily);
  static const IconData kfileLock01 =
      IconData(0xead7, fontFamily: _untitledUiFamily);
  static const IconData kfileLock02 =
      IconData(0xead8, fontFamily: _untitledUiFamily);
  static const IconData kfileLock03 =
      IconData(0xead9, fontFamily: _untitledUiFamily);
  static const IconData kfileMinus01 =
      IconData(0xeada, fontFamily: _untitledUiFamily);
  static const IconData kfileMinus02 =
      IconData(0xeadb, fontFamily: _untitledUiFamily);
  static const IconData kfileMinus03 =
      IconData(0xeadc, fontFamily: _untitledUiFamily);
  static const IconData kfilePlus01 =
      IconData(0xeadd, fontFamily: _untitledUiFamily);
  static const IconData kfilePlus02 =
      IconData(0xeade, fontFamily: _untitledUiFamily);
  static const IconData kfilePlus03 =
      IconData(0xeadf, fontFamily: _untitledUiFamily);
  static const IconData kfileQuestion01 =
      IconData(0xeae0, fontFamily: _untitledUiFamily);
  static const IconData kfileQuestion02 =
      IconData(0xeae1, fontFamily: _untitledUiFamily);
  static const IconData kfileQuestion03 =
      IconData(0xeae2, fontFamily: _untitledUiFamily);
  static const IconData kfileSearch01 =
      IconData(0xeae3, fontFamily: _untitledUiFamily);
  static const IconData kfileSearch02 =
      IconData(0xeae4, fontFamily: _untitledUiFamily);
  static const IconData kfileSearch03 =
      IconData(0xeae5, fontFamily: _untitledUiFamily);
  static const IconData kfileShield01 =
      IconData(0xeae6, fontFamily: _untitledUiFamily);
  static const IconData kfileShield02 =
      IconData(0xeae7, fontFamily: _untitledUiFamily);
  static const IconData kfileShield03 =
      IconData(0xeae8, fontFamily: _untitledUiFamily);
  static const IconData kfileX01 =
      IconData(0xeae9, fontFamily: _untitledUiFamily);
  static const IconData kfileX02 =
      IconData(0xeaea, fontFamily: _untitledUiFamily);
  static const IconData kfileX03 =
      IconData(0xeaeb, fontFamily: _untitledUiFamily);
  static const IconData kfilm01 =
      IconData(0xeaec, fontFamily: _untitledUiFamily);
  static const IconData kfilm02 =
      IconData(0xeaed, fontFamily: _untitledUiFamily);
  static const IconData kfilm03 =
      IconData(0xeaee, fontFamily: _untitledUiFamily);
  static const IconData kfilterFunnel01 =
      IconData(0xeaef, fontFamily: _untitledUiFamily);
  static const IconData kfilterFunnel02 =
      IconData(0xeaf0, fontFamily: _untitledUiFamily);
  static const IconData kfilterLines =
      IconData(0xeaf1, fontFamily: _untitledUiFamily);
  static const IconData kfingerprint01 =
      IconData(0xeaf2, fontFamily: _untitledUiFamily);
  static const IconData kfingerprint02 =
      IconData(0xeaf3, fontFamily: _untitledUiFamily);
  static const IconData kfingerprint03 =
      IconData(0xeaf4, fontFamily: _untitledUiFamily);
  static const IconData kfingerprint04 =
      IconData(0xeaf5, fontFamily: _untitledUiFamily);
  static const IconData kflag01 =
      IconData(0xeaf6, fontFamily: _untitledUiFamily);
  static const IconData kflag02 =
      IconData(0xeaf7, fontFamily: _untitledUiFamily);
  static const IconData kflag03 =
      IconData(0xeaf8, fontFamily: _untitledUiFamily);
  static const IconData kflag04 =
      IconData(0xeaf9, fontFamily: _untitledUiFamily);
  static const IconData kflag05 =
      IconData(0xeafa, fontFamily: _untitledUiFamily);
  static const IconData kflag06 =
      IconData(0xeafb, fontFamily: _untitledUiFamily);
  static const IconData kflash =
      IconData(0xeafc, fontFamily: _untitledUiFamily);
  static const IconData kflashOff =
      IconData(0xeafd, fontFamily: _untitledUiFamily);
  static const IconData kflexAlignBottom =
      IconData(0xeafe, fontFamily: _untitledUiFamily);
  static const IconData kflexAlignLeft =
      IconData(0xeaff, fontFamily: _untitledUiFamily);
  static const IconData kflexAlignRight =
      IconData(0xeb00, fontFamily: _untitledUiFamily);
  static const IconData kflexAlignTop =
      IconData(0xeb01, fontFamily: _untitledUiFamily);
  static const IconData kflipBackward =
      IconData(0xeb02, fontFamily: _untitledUiFamily);
  static const IconData kflipForward =
      IconData(0xeb03, fontFamily: _untitledUiFamily);
  static const IconData kfolderClosed =
      IconData(0xeb06, fontFamily: _untitledUiFamily);
  static const IconData kfolderLock =
      IconData(0xeb09, fontFamily: _untitledUiFamily);
  static const IconData kfolderQuestion =
      IconData(0xeb0c, fontFamily: _untitledUiFamily);
  static const IconData kfolderShield =
      IconData(0xeb0e, fontFamily: _untitledUiFamily);
  static const IconData kfolderX =
      IconData(0xeb0f, fontFamily: _untitledUiFamily);
  static const IconData kframer =
      IconData(0xeb10, fontFamily: _untitledUiFamily);
  static const IconData kgamingPad01 =
      IconData(0xeb11, fontFamily: _untitledUiFamily);
  static const IconData kgamingPad02 =
      IconData(0xeb12, fontFamily: _untitledUiFamily);
  static const IconData kgift01 =
      IconData(0xeb13, fontFamily: _untitledUiFamily);
  static const IconData kgift02 =
      IconData(0xeb14, fontFamily: _untitledUiFamily);
  static const IconData kgitBranch01 =
      IconData(0xeb15, fontFamily: _untitledUiFamily);
  static const IconData kgitBranch02 =
      IconData(0xeb16, fontFamily: _untitledUiFamily);
  static const IconData kgitCommit =
      IconData(0xeb17, fontFamily: _untitledUiFamily);
  static const IconData kgitMerge =
      IconData(0xeb18, fontFamily: _untitledUiFamily);
  static const IconData kgitPullRequest =
      IconData(0xeb19, fontFamily: _untitledUiFamily);
  static const IconData kglasses01 =
      IconData(0xeb1a, fontFamily: _untitledUiFamily);
  static const IconData kglasses02 =
      IconData(0xeb1b, fontFamily: _untitledUiFamily);
  static const IconData kglobe01 =
      IconData(0xeb1c, fontFamily: _untitledUiFamily);
  static const IconData kglobe02 =
      IconData(0xeb1d, fontFamily: _untitledUiFamily);
  static const IconData kglobe03 =
      IconData(0xeb1e, fontFamily: _untitledUiFamily);
  static const IconData kglobe04 =
      IconData(0xeb1f, fontFamily: _untitledUiFamily);
  static const IconData kglobe05 =
      IconData(0xeb20, fontFamily: _untitledUiFamily);
  static const IconData kglobe06 =
      IconData(0xeb21, fontFamily: _untitledUiFamily);
  static const IconData kglobeSlated01 =
      IconData(0xeb22, fontFamily: _untitledUiFamily);
  static const IconData kglobeSlated02 =
      IconData(0xeb23, fontFamily: _untitledUiFamily);
  static const IconData kgoogleChrome =
      IconData(0xeb24, fontFamily: _untitledUiFamily);
  static const IconData kgraduationHat01 =
      IconData(0xeb25, fontFamily: _untitledUiFamily);
  static const IconData kgraduationHat02 =
      IconData(0xeb26, fontFamily: _untitledUiFamily);
  static const IconData kgrid01 =
      IconData(0xeb27, fontFamily: _untitledUiFamily);
  static const IconData kgrid02 =
      IconData(0xeb28, fontFamily: _untitledUiFamily);
  static const IconData kgrid03 =
      IconData(0xeb29, fontFamily: _untitledUiFamily);
  static const IconData kgridDotsBlank =
      IconData(0xeb2a, fontFamily: _untitledUiFamily);
  static const IconData kgridDotsBottom =
      IconData(0xeb2b, fontFamily: _untitledUiFamily);
  static const IconData kgridDotsHorizontalCenter =
      IconData(0xeb2c, fontFamily: _untitledUiFamily);
  static const IconData kgridDotsLeft =
      IconData(0xeb2d, fontFamily: _untitledUiFamily);
  static const IconData kgridDotsOuter =
      IconData(0xeb2e, fontFamily: _untitledUiFamily);
  static const IconData kgridDotsRight =
      IconData(0xeb2f, fontFamily: _untitledUiFamily);
  static const IconData kgridDotsTop =
      IconData(0xeb30, fontFamily: _untitledUiFamily);
  static const IconData kgridDotsVerticalCenter =
      IconData(0xeb31, fontFamily: _untitledUiFamily);
  static const IconData khand = IconData(0xeb32, fontFamily: _untitledUiFamily);
  static const IconData khardDrive =
      IconData(0xeb33, fontFamily: _untitledUiFamily);
  static const IconData khash01 =
      IconData(0xeb34, fontFamily: _untitledUiFamily);
  static const IconData khash02 =
      IconData(0xeb35, fontFamily: _untitledUiFamily);
  static const IconData kheading01 =
      IconData(0xeb36, fontFamily: _untitledUiFamily);
  static const IconData kheading02 =
      IconData(0xeb37, fontFamily: _untitledUiFamily);
  static const IconData kheadingSquare =
      IconData(0xeb38, fontFamily: _untitledUiFamily);
  static const IconData kheadphones01 =
      IconData(0xeb39, fontFamily: _untitledUiFamily);
  static const IconData kheadphones02 =
      IconData(0xeb3a, fontFamily: _untitledUiFamily);
  static const IconData kheartCircle =
      IconData(0xeb3c, fontFamily: _untitledUiFamily);
  static const IconData kheartHand =
      IconData(0xeb3d, fontFamily: _untitledUiFamily);
  static const IconData kheartHexagon =
      IconData(0xeb3e, fontFamily: _untitledUiFamily);
  static const IconData kheartOctagon =
      IconData(0xeb3f, fontFamily: _untitledUiFamily);
  static const IconData kheartRounded =
      IconData(0xeb40, fontFamily: _untitledUiFamily);
  static const IconData khearts =
      IconData(0xeb41, fontFamily: _untitledUiFamily);
  static const IconData kheartSquare =
      IconData(0xeb42, fontFamily: _untitledUiFamily);
  static const IconData khelpCircle =
      IconData(0xeb43, fontFamily: _untitledUiFamily);
  static const IconData khelpHexagon =
      IconData(0xeb44, fontFamily: _untitledUiFamily);
  static const IconData khelpOctagon =
      IconData(0xeb45, fontFamily: _untitledUiFamily);
  static const IconData khelpSquare =
      IconData(0xeb46, fontFamily: _untitledUiFamily);
  static const IconData khexagon01 =
      IconData(0xeb47, fontFamily: _untitledUiFamily);
  static const IconData khexagon02 =
      IconData(0xeb48, fontFamily: _untitledUiFamily);
  static const IconData khome01 =
      IconData(0xeb49, fontFamily: _untitledUiFamily);
  static const IconData khome02 =
      IconData(0xeb4a, fontFamily: _untitledUiFamily);
  static const IconData khome03 =
      IconData(0xeb4b, fontFamily: _untitledUiFamily);
  static const IconData khome04 =
      IconData(0xeb4c, fontFamily: _untitledUiFamily);
  static const IconData khome05 =
      IconData(0xeb4d, fontFamily: _untitledUiFamily);
  static const IconData khomeLine =
      IconData(0xeb4e, fontFamily: _untitledUiFamily);
  static const IconData khomeSmile =
      IconData(0xeb4f, fontFamily: _untitledUiFamily);
  static const IconData khorizontalBarChart01 =
      IconData(0xeb50, fontFamily: _untitledUiFamily);
  static const IconData khorizontalBarChart02 =
      IconData(0xeb51, fontFamily: _untitledUiFamily);
  static const IconData khorizontalBarChart03 =
      IconData(0xeb52, fontFamily: _untitledUiFamily);
  static const IconData khourglass01 =
      IconData(0xeb53, fontFamily: _untitledUiFamily);
  static const IconData khourglass02 =
      IconData(0xeb54, fontFamily: _untitledUiFamily);
  static const IconData khourglass03 =
      IconData(0xeb55, fontFamily: _untitledUiFamily);
  static const IconData khurricane01 =
      IconData(0xeb56, fontFamily: _untitledUiFamily);
  static const IconData khurricane02 =
      IconData(0xeb57, fontFamily: _untitledUiFamily);
  static const IconData khurricane03 =
      IconData(0xeb58, fontFamily: _untitledUiFamily);
  static const IconData kimage03 =
      IconData(0xeb5b, fontFamily: _untitledUiFamily);
  static const IconData kimage04 =
      IconData(0xeb5c, fontFamily: _untitledUiFamily);
  static const IconData kimage05 =
      IconData(0xeb5d, fontFamily: _untitledUiFamily);
  static const IconData kimageCheck =
      IconData(0xeb5e, fontFamily: _untitledUiFamily);
  static const IconData kimageDown =
      IconData(0xeb5f, fontFamily: _untitledUiFamily);
  static const IconData kimageIndentLeft =
      IconData(0xeb60, fontFamily: _untitledUiFamily);
  static const IconData kimageIndentRight =
      IconData(0xeb61, fontFamily: _untitledUiFamily);
  static const IconData kimageLeft =
      IconData(0xeb62, fontFamily: _untitledUiFamily);
  static const IconData kimagePlus =
      IconData(0xeb63, fontFamily: _untitledUiFamily);
  static const IconData kimageRight =
      IconData(0xeb64, fontFamily: _untitledUiFamily);
  static const IconData kimageUp =
      IconData(0xeb65, fontFamily: _untitledUiFamily);
  static const IconData kimageUser =
      IconData(0xeb66, fontFamily: _untitledUiFamily);
  static const IconData kimageUserCheck =
      IconData(0xeb67, fontFamily: _untitledUiFamily);
  static const IconData kimageUserDown =
      IconData(0xeb68, fontFamily: _untitledUiFamily);
  static const IconData kimageUserLeft =
      IconData(0xeb69, fontFamily: _untitledUiFamily);
  static const IconData kimageUserPlus =
      IconData(0xeb6a, fontFamily: _untitledUiFamily);
  static const IconData kimageUserRight =
      IconData(0xeb6b, fontFamily: _untitledUiFamily);
  static const IconData kimageUserUp =
      IconData(0xeb6c, fontFamily: _untitledUiFamily);
  static const IconData kimageUserX =
      IconData(0xeb6d, fontFamily: _untitledUiFamily);
  static const IconData kimageX =
      IconData(0xeb6e, fontFamily: _untitledUiFamily);
  static const IconData kinbox01 =
      IconData(0xeb6f, fontFamily: _untitledUiFamily);
  static const IconData kinbox02 =
      IconData(0xeb70, fontFamily: _untitledUiFamily);
  static const IconData kinfinity =
      IconData(0xeb71, fontFamily: _untitledUiFamily);
  static const IconData kinfoCircle =
      IconData(0xeb72, fontFamily: _untitledUiFamily);
  static const IconData kinfoHexagon =
      IconData(0xeb73, fontFamily: _untitledUiFamily);
  static const IconData kinfoOctagon =
      IconData(0xeb74, fontFamily: _untitledUiFamily);
  static const IconData kinfoSquare =
      IconData(0xeb75, fontFamily: _untitledUiFamily);
  static const IconData kintersectCircle =
      IconData(0xeb76, fontFamily: _untitledUiFamily);
  static const IconData kintersectSquare =
      IconData(0xeb77, fontFamily: _untitledUiFamily);
  static const IconData kitalic01 =
      IconData(0xeb78, fontFamily: _untitledUiFamily);
  static const IconData kitalic02 =
      IconData(0xeb79, fontFamily: _untitledUiFamily);
  static const IconData kitalicSquare =
      IconData(0xeb7a, fontFamily: _untitledUiFamily);
  static const IconData kkey01 =
      IconData(0xeb7b, fontFamily: _untitledUiFamily);
  static const IconData kkey02 =
      IconData(0xeb7c, fontFamily: _untitledUiFamily);
  static const IconData kkeyboard01 =
      IconData(0xeb7d, fontFamily: _untitledUiFamily);
  static const IconData kkeyboard02 =
      IconData(0xeb7e, fontFamily: _untitledUiFamily);
  static const IconData klaptop01 =
      IconData(0xeb7f, fontFamily: _untitledUiFamily);
  static const IconData klaptop02 =
      IconData(0xeb80, fontFamily: _untitledUiFamily);
  static const IconData klayerSingle =
      IconData(0xeb81, fontFamily: _untitledUiFamily);
  static const IconData klayersThree01 =
      IconData(0xeb82, fontFamily: _untitledUiFamily);
  static const IconData klayersThree02 =
      IconData(0xeb83, fontFamily: _untitledUiFamily);
  static const IconData klayersTwo01 =
      IconData(0xeb84, fontFamily: _untitledUiFamily);
  static const IconData klayersTwo02 =
      IconData(0xeb85, fontFamily: _untitledUiFamily);
  static const IconData klayoutAlt01 =
      IconData(0xeb86, fontFamily: _untitledUiFamily);
  static const IconData klayoutAlt02 =
      IconData(0xeb87, fontFamily: _untitledUiFamily);
  static const IconData klayoutAlt03 =
      IconData(0xeb88, fontFamily: _untitledUiFamily);
  static const IconData klayoutAlt04 =
      IconData(0xeb89, fontFamily: _untitledUiFamily);
  static const IconData klayoutBottom =
      IconData(0xeb8a, fontFamily: _untitledUiFamily);
  static const IconData klayoutGrid01 =
      IconData(0xeb8b, fontFamily: _untitledUiFamily);
  static const IconData klayoutGrid02 =
      IconData(0xeb8c, fontFamily: _untitledUiFamily);
  static const IconData klayoutLeft =
      IconData(0xeb8d, fontFamily: _untitledUiFamily);
  static const IconData klayoutRight =
      IconData(0xeb8e, fontFamily: _untitledUiFamily);
  static const IconData klayoutTop =
      IconData(0xeb8f, fontFamily: _untitledUiFamily);
  static const IconData kleftIndent01 =
      IconData(0xeb90, fontFamily: _untitledUiFamily);
  static const IconData kleftIndent02 =
      IconData(0xeb91, fontFamily: _untitledUiFamily);
  static const IconData kletterSpacing01 =
      IconData(0xeb92, fontFamily: _untitledUiFamily);
  static const IconData kletterSpacing02 =
      IconData(0xeb93, fontFamily: _untitledUiFamily);
  static const IconData klifeBuoy01 =
      IconData(0xeb94, fontFamily: _untitledUiFamily);
  static const IconData klifeBuoy02 =
      IconData(0xeb95, fontFamily: _untitledUiFamily);
  static const IconData klightbulb01 =
      IconData(0xeb96, fontFamily: _untitledUiFamily);
  static const IconData klightbulb02 =
      IconData(0xeb97, fontFamily: _untitledUiFamily);
  static const IconData klightbulb03 =
      IconData(0xeb98, fontFamily: _untitledUiFamily);
  static const IconData klightbulb04 =
      IconData(0xeb99, fontFamily: _untitledUiFamily);
  static const IconData klightbulb05 =
      IconData(0xeb9a, fontFamily: _untitledUiFamily);
  static const IconData klightning01 =
      IconData(0xeb9b, fontFamily: _untitledUiFamily);
  static const IconData klightning02 =
      IconData(0xeb9c, fontFamily: _untitledUiFamily);
  static const IconData klineChartDown01 =
      IconData(0xeb9d, fontFamily: _untitledUiFamily);
  static const IconData klineChartDown02 =
      IconData(0xeb9e, fontFamily: _untitledUiFamily);
  static const IconData klineChartDown03 =
      IconData(0xeb9f, fontFamily: _untitledUiFamily);
  static const IconData klineChartDown04 =
      IconData(0xeba0, fontFamily: _untitledUiFamily);
  static const IconData klineChartDown05 =
      IconData(0xeba1, fontFamily: _untitledUiFamily);
  static const IconData klineChartUp01 =
      IconData(0xeba2, fontFamily: _untitledUiFamily);
  static const IconData klineChartUp02 =
      IconData(0xeba3, fontFamily: _untitledUiFamily);
  static const IconData klineChartUp03 =
      IconData(0xeba4, fontFamily: _untitledUiFamily);
  static const IconData klineChartUp04 =
      IconData(0xeba5, fontFamily: _untitledUiFamily);
  static const IconData klineChartUp05 =
      IconData(0xeba6, fontFamily: _untitledUiFamily);
  static const IconData klineHeight =
      IconData(0xeba7, fontFamily: _untitledUiFamily);
  static const IconData klink01 =
      IconData(0xeba8, fontFamily: _untitledUiFamily);
  static const IconData klink02 =
      IconData(0xeba9, fontFamily: _untitledUiFamily);
  static const IconData klink03 =
      IconData(0xebaa, fontFamily: _untitledUiFamily);
  static const IconData klink04 =
      IconData(0xebab, fontFamily: _untitledUiFamily);
  static const IconData klink05 =
      IconData(0xebac, fontFamily: _untitledUiFamily);
  static const IconData klinkBroken01 =
      IconData(0xebad, fontFamily: _untitledUiFamily);
  static const IconData klinkBroken02 =
      IconData(0xebae, fontFamily: _untitledUiFamily);
  static const IconData klinkExternal01 =
      IconData(0xebaf, fontFamily: _untitledUiFamily);
  static const IconData klinkExternal02 =
      IconData(0xebb0, fontFamily: _untitledUiFamily);
  static const IconData klist = IconData(0xebb1, fontFamily: _untitledUiFamily);
  static const IconData kloading01 =
      IconData(0xebb2, fontFamily: _untitledUiFamily);
  static const IconData kloading02 =
      IconData(0xebb3, fontFamily: _untitledUiFamily);
  static const IconData kloading03 =
      IconData(0xebb4, fontFamily: _untitledUiFamily);
  static const IconData klock01 =
      IconData(0xebb5, fontFamily: _untitledUiFamily);
  static const IconData klock02 =
      IconData(0xebb6, fontFamily: _untitledUiFamily);
  static const IconData klock03 =
      IconData(0xebb7, fontFamily: _untitledUiFamily);
  static const IconData klock04 =
      IconData(0xebb8, fontFamily: _untitledUiFamily);
  static const IconData klockKeyholeCircle =
      IconData(0xebb9, fontFamily: _untitledUiFamily);
  static const IconData klockKeyholeSquare =
      IconData(0xebba, fontFamily: _untitledUiFamily);
  static const IconData klockUnlocked01 =
      IconData(0xebbb, fontFamily: _untitledUiFamily);
  static const IconData klockUnlocked02 =
      IconData(0xebbc, fontFamily: _untitledUiFamily);
  static const IconData klockUnlocked03 =
      IconData(0xebbd, fontFamily: _untitledUiFamily);
  static const IconData klockUnlocked04 =
      IconData(0xebbe, fontFamily: _untitledUiFamily);
  static const IconData klogIn01 =
      IconData(0xebbf, fontFamily: _untitledUiFamily);
  static const IconData klogIn02 =
      IconData(0xebc0, fontFamily: _untitledUiFamily);
  static const IconData klogIn03 =
      IconData(0xebc1, fontFamily: _untitledUiFamily);
  static const IconData klogIn04 =
      IconData(0xebc2, fontFamily: _untitledUiFamily);
  static const IconData klogOut01 =
      IconData(0xebc3, fontFamily: _untitledUiFamily);
  static const IconData klogOut02 =
      IconData(0xebc4, fontFamily: _untitledUiFamily);
  static const IconData klogOut03 =
      IconData(0xebc5, fontFamily: _untitledUiFamily);
  static const IconData klogOut04 =
      IconData(0xebc6, fontFamily: _untitledUiFamily);
  static const IconData kluggage01 =
      IconData(0xebc7, fontFamily: _untitledUiFamily);
  static const IconData kluggage02 =
      IconData(0xebc8, fontFamily: _untitledUiFamily);
  static const IconData kluggage03 =
      IconData(0xebc9, fontFamily: _untitledUiFamily);
  static const IconData kmagicWand01 =
      IconData(0xebca, fontFamily: _untitledUiFamily);
  static const IconData kmagicWand02 =
      IconData(0xebcb, fontFamily: _untitledUiFamily);
  static const IconData kmail01 =
      IconData(0xebcc, fontFamily: _untitledUiFamily);
  static const IconData kmail02 =
      IconData(0xebcd, fontFamily: _untitledUiFamily);
  static const IconData kmail03 =
      IconData(0xebce, fontFamily: _untitledUiFamily);
  static const IconData kmail04 =
      IconData(0xebcf, fontFamily: _untitledUiFamily);
  static const IconData kmail05 =
      IconData(0xebd0, fontFamily: _untitledUiFamily);
  static const IconData kmap01 =
      IconData(0xebd1, fontFamily: _untitledUiFamily);
  static const IconData kmap02 =
      IconData(0xebd2, fontFamily: _untitledUiFamily);
  static const IconData kmark = IconData(0xebd3, fontFamily: _untitledUiFamily);
  static const IconData kmarkerPin01 =
      IconData(0xebd4, fontFamily: _untitledUiFamily);
  static const IconData kmarkerPin02 =
      IconData(0xebd5, fontFamily: _untitledUiFamily);
  static const IconData kmarkerPin03 =
      IconData(0xebd6, fontFamily: _untitledUiFamily);
  static const IconData kmarkerPin04 =
      IconData(0xebd7, fontFamily: _untitledUiFamily);
  static const IconData kmarkerPin05 =
      IconData(0xebd8, fontFamily: _untitledUiFamily);
  static const IconData kmarkerPin06 =
      IconData(0xebd9, fontFamily: _untitledUiFamily);
  static const IconData kmaximize01 =
      IconData(0xebda, fontFamily: _untitledUiFamily);
  static const IconData kmaximize02 =
      IconData(0xebdb, fontFamily: _untitledUiFamily);
  static const IconData kmedicalCircle =
      IconData(0xebdc, fontFamily: _untitledUiFamily);
  static const IconData kmedicalCross =
      IconData(0xebdd, fontFamily: _untitledUiFamily);
  static const IconData kmedicalSquare =
      IconData(0xebde, fontFamily: _untitledUiFamily);
  static const IconData kmenu01 =
      IconData(0xebdf, fontFamily: _untitledUiFamily);
  static const IconData kmenu02 =
      IconData(0xebe0, fontFamily: _untitledUiFamily);
  static const IconData kmenu03 =
      IconData(0xebe1, fontFamily: _untitledUiFamily);
  static const IconData kmenu04 =
      IconData(0xebe2, fontFamily: _untitledUiFamily);
  static const IconData kmenu05 =
      IconData(0xebe3, fontFamily: _untitledUiFamily);
  static const IconData kmessageAlertCircle =
      IconData(0xebe4, fontFamily: _untitledUiFamily);
  static const IconData kmessageAlertSquare =
      IconData(0xebe5, fontFamily: _untitledUiFamily);
  static const IconData kmessageChatCircle =
      IconData(0xebe6, fontFamily: _untitledUiFamily);
  static const IconData kmessageChatSquare =
      IconData(0xebe7, fontFamily: _untitledUiFamily);
  static const IconData kmessageCheckCircle =
      IconData(0xebe8, fontFamily: _untitledUiFamily);
  static const IconData kmessageCheckSquare =
      IconData(0xebe9, fontFamily: _untitledUiFamily);
  static const IconData kmessageCircle01 =
      IconData(0xebea, fontFamily: _untitledUiFamily);
  static const IconData kmessageCircle02 =
      IconData(0xebeb, fontFamily: _untitledUiFamily);
  static const IconData kmessageDotsCircle =
      IconData(0xebec, fontFamily: _untitledUiFamily);
  static const IconData kmessageDotsSquare =
      IconData(0xebed, fontFamily: _untitledUiFamily);
  static const IconData kmessageHeartCircle =
      IconData(0xebee, fontFamily: _untitledUiFamily);
  static const IconData kmessageHeartSquare =
      IconData(0xebef, fontFamily: _untitledUiFamily);
  static const IconData kmessageNotificationCircle =
      IconData(0xebf0, fontFamily: _untitledUiFamily);
  static const IconData kmessageNotificationSquare =
      IconData(0xebf1, fontFamily: _untitledUiFamily);
  static const IconData kmessagePlusCircle =
      IconData(0xebf2, fontFamily: _untitledUiFamily);
  static const IconData kmessagePlusSquare =
      IconData(0xebf3, fontFamily: _untitledUiFamily);
  static const IconData kmessageQuestionCircle =
      IconData(0xebf4, fontFamily: _untitledUiFamily);
  static const IconData kmessageQuestionSquare =
      IconData(0xebf5, fontFamily: _untitledUiFamily);
  static const IconData kmessageSmileCircle =
      IconData(0xebf6, fontFamily: _untitledUiFamily);
  static const IconData kmessageSmileSquare =
      IconData(0xebf7, fontFamily: _untitledUiFamily);
  static const IconData kmessageSquare01 =
      IconData(0xebf8, fontFamily: _untitledUiFamily);
  static const IconData kmessageSquare02 =
      IconData(0xebf9, fontFamily: _untitledUiFamily);
  static const IconData kmessageTextCircle01 =
      IconData(0xebfa, fontFamily: _untitledUiFamily);
  static const IconData kmessageTextCircle02 =
      IconData(0xebfb, fontFamily: _untitledUiFamily);
  static const IconData kmessageTextSquare01 =
      IconData(0xebfc, fontFamily: _untitledUiFamily);
  static const IconData kmessageTextSquare02 =
      IconData(0xebfd, fontFamily: _untitledUiFamily);
  static const IconData kmessageXCircle =
      IconData(0xebfe, fontFamily: _untitledUiFamily);
  static const IconData kmessageXSquare =
      IconData(0xebff, fontFamily: _untitledUiFamily);
  static const IconData kmicrophone01 =
      IconData(0xec00, fontFamily: _untitledUiFamily);
  static const IconData kmicrophone02 =
      IconData(0xec01, fontFamily: _untitledUiFamily);
  static const IconData kmicrophoneOff01 =
      IconData(0xec02, fontFamily: _untitledUiFamily);
  static const IconData kmicrophoneOff02 =
      IconData(0xec03, fontFamily: _untitledUiFamily);
  static const IconData kmicroscope =
      IconData(0xec04, fontFamily: _untitledUiFamily);
  static const IconData kminimize01 =
      IconData(0xec05, fontFamily: _untitledUiFamily);
  static const IconData kminimize02 =
      IconData(0xec06, fontFamily: _untitledUiFamily);
  static const IconData kminus =
      IconData(0xec07, fontFamily: _untitledUiFamily);
  static const IconData kminusSquare =
      IconData(0xec09, fontFamily: _untitledUiFamily);
  static const IconData kmodem01 =
      IconData(0xec0a, fontFamily: _untitledUiFamily);
  static const IconData kmodem02 =
      IconData(0xec0b, fontFamily: _untitledUiFamily);
  static const IconData kmonitor01 =
      IconData(0xec0c, fontFamily: _untitledUiFamily);
  static const IconData kmonitor02 =
      IconData(0xec0d, fontFamily: _untitledUiFamily);
  static const IconData kmonitor03 =
      IconData(0xec0e, fontFamily: _untitledUiFamily);
  static const IconData kmonitor04 =
      IconData(0xec0f, fontFamily: _untitledUiFamily);
  static const IconData kmonitor05 =
      IconData(0xec10, fontFamily: _untitledUiFamily);
  static const IconData kmoon01 =
      IconData(0xec11, fontFamily: _untitledUiFamily);
  static const IconData kmoon02 =
      IconData(0xec12, fontFamily: _untitledUiFamily);
  static const IconData kmoonEclipse =
      IconData(0xec13, fontFamily: _untitledUiFamily);
  static const IconData kmoonStar =
      IconData(0xec14, fontFamily: _untitledUiFamily);
  static const IconData kmusicNote01 =
      IconData(0xec17, fontFamily: _untitledUiFamily);
  static const IconData kmusicNote02 =
      IconData(0xec18, fontFamily: _untitledUiFamily);
  static const IconData kmusicNotePlus =
      IconData(0xec19, fontFamily: _untitledUiFamily);
  static const IconData knavigationPointer01 =
      IconData(0xec1a, fontFamily: _untitledUiFamily);
  static const IconData knavigationPointer02 =
      IconData(0xec1b, fontFamily: _untitledUiFamily);
  static const IconData knavigationPointerOff01 =
      IconData(0xec1c, fontFamily: _untitledUiFamily);
  static const IconData knavigationPointerOff02 =
      IconData(0xec1d, fontFamily: _untitledUiFamily);
  static const IconData knotificationBox =
      IconData(0xec1e, fontFamily: _untitledUiFamily);
  static const IconData knotificationMessage =
      IconData(0xec1f, fontFamily: _untitledUiFamily);
  static const IconData knotificationText =
      IconData(0xec20, fontFamily: _untitledUiFamily);
  static const IconData kpackage =
      IconData(0xec22, fontFamily: _untitledUiFamily);
  static const IconData kpackageCheck =
      IconData(0xec23, fontFamily: _untitledUiFamily);
  static const IconData kpackageMinus =
      IconData(0xec24, fontFamily: _untitledUiFamily);
  static const IconData kpackagePlus =
      IconData(0xec25, fontFamily: _untitledUiFamily);
  static const IconData kpackageSearch =
      IconData(0xec26, fontFamily: _untitledUiFamily);
  static const IconData kpackageX =
      IconData(0xec27, fontFamily: _untitledUiFamily);
  static const IconData kpaint =
      IconData(0xec28, fontFamily: _untitledUiFamily);
  static const IconData kpaintPour =
      IconData(0xec29, fontFamily: _untitledUiFamily);
  static const IconData kpalette =
      IconData(0xec2a, fontFamily: _untitledUiFamily);
  static const IconData kpaperclip =
      IconData(0xec2b, fontFamily: _untitledUiFamily);
  static const IconData kparagraphSpacing =
      IconData(0xec2c, fontFamily: _untitledUiFamily);
  static const IconData kparagraphWrap =
      IconData(0xec2d, fontFamily: _untitledUiFamily);
  static const IconData kpasscode =
      IconData(0xec2e, fontFamily: _untitledUiFamily);
  static const IconData kpasscodeLock =
      IconData(0xec2f, fontFamily: _untitledUiFamily);
  static const IconData kpassport =
      IconData(0xec30, fontFamily: _untitledUiFamily);
  static const IconData kpauseSquare =
      IconData(0xec32, fontFamily: _untitledUiFamily);
  static const IconData kpencil01 =
      IconData(0xec33, fontFamily: _untitledUiFamily);
  static const IconData kpencil02 =
      IconData(0xec34, fontFamily: _untitledUiFamily);
  static const IconData kpencilLine =
      IconData(0xec35, fontFamily: _untitledUiFamily);
  static const IconData kpentagon =
      IconData(0xec36, fontFamily: _untitledUiFamily);
  static const IconData kpenTool01 =
      IconData(0xec37, fontFamily: _untitledUiFamily);
  static const IconData kpenTool02 =
      IconData(0xec38, fontFamily: _untitledUiFamily);
  static const IconData kpenToolMinus =
      IconData(0xec39, fontFamily: _untitledUiFamily);
  static const IconData kpenToolPlus =
      IconData(0xec3a, fontFamily: _untitledUiFamily);
  static const IconData kpercent01 =
      IconData(0xec3b, fontFamily: _untitledUiFamily);
  static const IconData kpercent02 =
      IconData(0xec3c, fontFamily: _untitledUiFamily);
  static const IconData kpercent03 =
      IconData(0xec3d, fontFamily: _untitledUiFamily);
  static const IconData kperspective01 =
      IconData(0xec3e, fontFamily: _untitledUiFamily);
  static const IconData kperspective02 =
      IconData(0xec3f, fontFamily: _untitledUiFamily);
  static const IconData kphone01 =
      IconData(0xec41, fontFamily: _untitledUiFamily);
  static const IconData kphone02 =
      IconData(0xec42, fontFamily: _untitledUiFamily);
  static const IconData kphoneCall01 =
      IconData(0xec43, fontFamily: _untitledUiFamily);
  static const IconData kphoneCall02 =
      IconData(0xec44, fontFamily: _untitledUiFamily);
  static const IconData kphoneHangUp =
      IconData(0xec45, fontFamily: _untitledUiFamily);
  static const IconData kphoneIncoming01 =
      IconData(0xec46, fontFamily: _untitledUiFamily);
  static const IconData kphoneIncoming02 =
      IconData(0xec47, fontFamily: _untitledUiFamily);
  static const IconData kphoneOutgoing01 =
      IconData(0xec48, fontFamily: _untitledUiFamily);
  static const IconData kphoneOutgoing02 =
      IconData(0xec49, fontFamily: _untitledUiFamily);
  static const IconData kphonePause =
      IconData(0xec4a, fontFamily: _untitledUiFamily);
  static const IconData kphonePlus =
      IconData(0xec4b, fontFamily: _untitledUiFamily);
  static const IconData kphoneX =
      IconData(0xec4c, fontFamily: _untitledUiFamily);
  static const IconData kpieChart01 =
      IconData(0xec4d, fontFamily: _untitledUiFamily);
  static const IconData kpieChart02 =
      IconData(0xec4e, fontFamily: _untitledUiFamily);
  static const IconData kpieChart03 =
      IconData(0xec4f, fontFamily: _untitledUiFamily);
  static const IconData kpieChart04 =
      IconData(0xec50, fontFamily: _untitledUiFamily);
  static const IconData kpiggyBank01 =
      IconData(0xec51, fontFamily: _untitledUiFamily);
  static const IconData kpiggyBank02 =
      IconData(0xec52, fontFamily: _untitledUiFamily);
  static const IconData kpilcrow01 =
      IconData(0xec53, fontFamily: _untitledUiFamily);
  static const IconData kpilcrow02 =
      IconData(0xec54, fontFamily: _untitledUiFamily);
  static const IconData kpilcrowSquare =
      IconData(0xec55, fontFamily: _untitledUiFamily);
  static const IconData kpin01 =
      IconData(0xec56, fontFamily: _untitledUiFamily);
  static const IconData kpin02 =
      IconData(0xec57, fontFamily: _untitledUiFamily);
  static const IconData kplaceholder =
      IconData(0xec58, fontFamily: _untitledUiFamily);
  static const IconData kplane =
      IconData(0xec59, fontFamily: _untitledUiFamily);
  static const IconData kplaySquare =
      IconData(0xec5c, fontFamily: _untitledUiFamily);
  static const IconData kplus = IconData(0xec5d, fontFamily: _untitledUiFamily);
  static const IconData kplusSquare =
      IconData(0xec5f, fontFamily: _untitledUiFamily);
  static const IconData kpodcast =
      IconData(0xec60, fontFamily: _untitledUiFamily);
  static const IconData kpower01 =
      IconData(0xec61, fontFamily: _untitledUiFamily);
  static const IconData kpower02 =
      IconData(0xec62, fontFamily: _untitledUiFamily);
  static const IconData kpower03 =
      IconData(0xec63, fontFamily: _untitledUiFamily);
  static const IconData kpresentationChart01 =
      IconData(0xec64, fontFamily: _untitledUiFamily);
  static const IconData kpresentationChart02 =
      IconData(0xec65, fontFamily: _untitledUiFamily);
  static const IconData kpresentationChart03 =
      IconData(0xec66, fontFamily: _untitledUiFamily);
  static const IconData kpuzzlePiece01 =
      IconData(0xec68, fontFamily: _untitledUiFamily);
  static const IconData kpuzzlePiece02 =
      IconData(0xec69, fontFamily: _untitledUiFamily);
  static const IconData kqrCode01 =
      IconData(0xec6a, fontFamily: _untitledUiFamily);
  static const IconData kqrCode02 =
      IconData(0xec6b, fontFamily: _untitledUiFamily);
  static const IconData kreceipt =
      IconData(0xec6c, fontFamily: _untitledUiFamily);
  static const IconData kreceiptCheck =
      IconData(0xec6d, fontFamily: _untitledUiFamily);
  static const IconData krecording01 =
      IconData(0xec6e, fontFamily: _untitledUiFamily);
  static const IconData krecording02 =
      IconData(0xec6f, fontFamily: _untitledUiFamily);
  static const IconData krecording03 =
      IconData(0xec70, fontFamily: _untitledUiFamily);
  static const IconData kreflect01 =
      IconData(0xec71, fontFamily: _untitledUiFamily);
  static const IconData kreflect02 =
      IconData(0xec72, fontFamily: _untitledUiFamily);
  static const IconData krefreshCcw01 =
      IconData(0xec73, fontFamily: _untitledUiFamily);
  static const IconData krefreshCcw02 =
      IconData(0xec74, fontFamily: _untitledUiFamily);
  static const IconData krefreshCcw03 =
      IconData(0xec75, fontFamily: _untitledUiFamily);
  static const IconData krefreshCcw04 =
      IconData(0xec76, fontFamily: _untitledUiFamily);
  static const IconData krefreshCcw05 =
      IconData(0xec77, fontFamily: _untitledUiFamily);
  static const IconData krefreshCw01 =
      IconData(0xec78, fontFamily: _untitledUiFamily);
  static const IconData krefreshCw02 =
      IconData(0xec79, fontFamily: _untitledUiFamily);
  static const IconData krefreshCw03 =
      IconData(0xec7a, fontFamily: _untitledUiFamily);
  static const IconData krefreshCw04 =
      IconData(0xec7b, fontFamily: _untitledUiFamily);
  static const IconData krefreshCw05 =
      IconData(0xec7c, fontFamily: _untitledUiFamily);
  static const IconData krepeat01 =
      IconData(0xec7d, fontFamily: _untitledUiFamily);
  static const IconData krepeat02 =
      IconData(0xec7e, fontFamily: _untitledUiFamily);
  static const IconData krepeat03 =
      IconData(0xec7f, fontFamily: _untitledUiFamily);
  static const IconData krepeat04 =
      IconData(0xec80, fontFamily: _untitledUiFamily);
  static const IconData kreverseLeft =
      IconData(0xec81, fontFamily: _untitledUiFamily);
  static const IconData kreverseRight =
      IconData(0xec82, fontFamily: _untitledUiFamily);
  static const IconData krightIndent01 =
      IconData(0xec83, fontFamily: _untitledUiFamily);
  static const IconData krightIndent02 =
      IconData(0xec84, fontFamily: _untitledUiFamily);
  static const IconData krocket01 =
      IconData(0xec85, fontFamily: _untitledUiFamily);
  static const IconData krocket02 =
      IconData(0xec86, fontFamily: _untitledUiFamily);
  static const IconData krollerBrush =
      IconData(0xec87, fontFamily: _untitledUiFamily);
  static const IconData kroute =
      IconData(0xec88, fontFamily: _untitledUiFamily);
  static const IconData krows01 =
      IconData(0xec89, fontFamily: _untitledUiFamily);
  static const IconData krows02 =
      IconData(0xec8a, fontFamily: _untitledUiFamily);
  static const IconData krows03 =
      IconData(0xec8b, fontFamily: _untitledUiFamily);
  static const IconData krss01 =
      IconData(0xec8c, fontFamily: _untitledUiFamily);
  static const IconData krss02 =
      IconData(0xec8d, fontFamily: _untitledUiFamily);
  static const IconData ksafe = IconData(0xec8f, fontFamily: _untitledUiFamily);
  static const IconData ksale01 =
      IconData(0xec90, fontFamily: _untitledUiFamily);
  static const IconData ksale02 =
      IconData(0xec91, fontFamily: _untitledUiFamily);
  static const IconData ksale03 =
      IconData(0xec92, fontFamily: _untitledUiFamily);
  static const IconData ksale04 =
      IconData(0xec93, fontFamily: _untitledUiFamily);
  static const IconData ksave01 =
      IconData(0xec94, fontFamily: _untitledUiFamily);
  static const IconData ksave02 =
      IconData(0xec95, fontFamily: _untitledUiFamily);
  static const IconData ksave03 =
      IconData(0xec96, fontFamily: _untitledUiFamily);
  static const IconData kscale01 =
      IconData(0xec97, fontFamily: _untitledUiFamily);
  static const IconData kscale02 =
      IconData(0xec98, fontFamily: _untitledUiFamily);
  static const IconData kscale03 =
      IconData(0xec99, fontFamily: _untitledUiFamily);
  static const IconData kscales01 =
      IconData(0xec9a, fontFamily: _untitledUiFamily);
  static const IconData kscales02 =
      IconData(0xec9b, fontFamily: _untitledUiFamily);
  static const IconData kscan = IconData(0xec9c, fontFamily: _untitledUiFamily);
  static const IconData kscissors01 =
      IconData(0xec9d, fontFamily: _untitledUiFamily);
  static const IconData kscissors02 =
      IconData(0xec9e, fontFamily: _untitledUiFamily);
  static const IconData kscissorsCut01 =
      IconData(0xec9f, fontFamily: _untitledUiFamily);
  static const IconData kscissorsCut02 =
      IconData(0xeca0, fontFamily: _untitledUiFamily);
  static const IconData ksearchLg =
      IconData(0xeca1, fontFamily: _untitledUiFamily);
  static const IconData ksearchMd =
      IconData(0xeca2, fontFamily: _untitledUiFamily);
  static const IconData ksearchRefraction =
      IconData(0xeca3, fontFamily: _untitledUiFamily);
  static const IconData ksearchSm =
      IconData(0xeca4, fontFamily: _untitledUiFamily);
  static const IconData ksend01 =
      IconData(0xeca5, fontFamily: _untitledUiFamily);
  static const IconData ksend02 =
      IconData(0xeca6, fontFamily: _untitledUiFamily);
  static const IconData ksend03 =
      IconData(0xeca7, fontFamily: _untitledUiFamily);
  static const IconData kserver01 =
      IconData(0xeca8, fontFamily: _untitledUiFamily);
  static const IconData kserver02 =
      IconData(0xeca9, fontFamily: _untitledUiFamily);
  static const IconData kserver03 =
      IconData(0xecaa, fontFamily: _untitledUiFamily);
  static const IconData kserver04 =
      IconData(0xecab, fontFamily: _untitledUiFamily);
  static const IconData kserver05 =
      IconData(0xecac, fontFamily: _untitledUiFamily);
  static const IconData kserver06 =
      IconData(0xecad, fontFamily: _untitledUiFamily);
  static const IconData ksettings01 =
      IconData(0xecae, fontFamily: _untitledUiFamily);
  static const IconData ksettings02 =
      IconData(0xecaf, fontFamily: _untitledUiFamily);
  static const IconData ksettings03 =
      IconData(0xecb0, fontFamily: _untitledUiFamily);
  static const IconData ksettings04 =
      IconData(0xecb1, fontFamily: _untitledUiFamily);
  static const IconData kshare01 =
      IconData(0xecb2, fontFamily: _untitledUiFamily);
  static const IconData kshare02 =
      IconData(0xecb3, fontFamily: _untitledUiFamily);
  static const IconData kshare03 =
      IconData(0xecb4, fontFamily: _untitledUiFamily);
  static const IconData kshare04 =
      IconData(0xecb5, fontFamily: _untitledUiFamily);
  static const IconData kshare05 =
      IconData(0xecb6, fontFamily: _untitledUiFamily);
  static const IconData kshare06 =
      IconData(0xecb7, fontFamily: _untitledUiFamily);
  static const IconData kshare07 =
      IconData(0xecb8, fontFamily: _untitledUiFamily);
  static const IconData kshield01 =
      IconData(0xecb9, fontFamily: _untitledUiFamily);
  static const IconData kshield02 =
      IconData(0xecba, fontFamily: _untitledUiFamily);
  static const IconData kshield03 =
      IconData(0xecbb, fontFamily: _untitledUiFamily);
  static const IconData kshieldDollar =
      IconData(0xecbc, fontFamily: _untitledUiFamily);
  static const IconData kshieldOff =
      IconData(0xecbd, fontFamily: _untitledUiFamily);
  static const IconData kshieldPlus =
      IconData(0xecbe, fontFamily: _untitledUiFamily);
  static const IconData kshieldTick =
      IconData(0xecbf, fontFamily: _untitledUiFamily);
  static const IconData kshieldZap =
      IconData(0xecc0, fontFamily: _untitledUiFamily);
  static const IconData kshoppingBag03 =
      IconData(0xecc3, fontFamily: _untitledUiFamily);
  static const IconData kshoppingCart03 =
      IconData(0xecc6, fontFamily: _untitledUiFamily);
  static const IconData kshuffle01 =
      IconData(0xecc7, fontFamily: _untitledUiFamily);
  static const IconData kshuffle02 =
      IconData(0xecc8, fontFamily: _untitledUiFamily);
  static const IconData ksignal01 =
      IconData(0xecc9, fontFamily: _untitledUiFamily);
  static const IconData ksignal02 =
      IconData(0xecca, fontFamily: _untitledUiFamily);
  static const IconData ksignal03 =
      IconData(0xeccb, fontFamily: _untitledUiFamily);
  static const IconData ksimcard =
      IconData(0xeccc, fontFamily: _untitledUiFamily);
  static const IconData kskew = IconData(0xeccd, fontFamily: _untitledUiFamily);
  static const IconData kslashCircle01 =
      IconData(0xecd0, fontFamily: _untitledUiFamily);
  static const IconData kslashCircle02 =
      IconData(0xecd1, fontFamily: _untitledUiFamily);
  static const IconData kslashDivider =
      IconData(0xecd2, fontFamily: _untitledUiFamily);
  static const IconData kslashOctagon =
      IconData(0xecd3, fontFamily: _untitledUiFamily);
  static const IconData ksliders01 =
      IconData(0xecd4, fontFamily: _untitledUiFamily);
  static const IconData ksliders02 =
      IconData(0xecd5, fontFamily: _untitledUiFamily);
  static const IconData ksliders03 =
      IconData(0xecd6, fontFamily: _untitledUiFamily);
  static const IconData ksliders04 =
      IconData(0xecd7, fontFamily: _untitledUiFamily);
  static const IconData ksnowflake01 =
      IconData(0xecd8, fontFamily: _untitledUiFamily);
  static const IconData ksnowflake02 =
      IconData(0xecd9, fontFamily: _untitledUiFamily);
  static const IconData kspacingHeight01 =
      IconData(0xecda, fontFamily: _untitledUiFamily);
  static const IconData kspacingHeight02 =
      IconData(0xecdb, fontFamily: _untitledUiFamily);
  static const IconData kspacingWidth01 =
      IconData(0xecdc, fontFamily: _untitledUiFamily);
  static const IconData kspacingWidth02 =
      IconData(0xecdd, fontFamily: _untitledUiFamily);
  static const IconData kspeaker01 =
      IconData(0xecde, fontFamily: _untitledUiFamily);
  static const IconData kspeaker02 =
      IconData(0xecdf, fontFamily: _untitledUiFamily);
  static const IconData kspeaker03 =
      IconData(0xece0, fontFamily: _untitledUiFamily);
  static const IconData kspeedometer01 =
      IconData(0xece1, fontFamily: _untitledUiFamily);
  static const IconData kspeedometer02 =
      IconData(0xece2, fontFamily: _untitledUiFamily);
  static const IconData kspeedometer03 =
      IconData(0xece3, fontFamily: _untitledUiFamily);
  static const IconData kspeedometer04 =
      IconData(0xece4, fontFamily: _untitledUiFamily);
  static const IconData kstand =
      IconData(0xece6, fontFamily: _untitledUiFamily);
  static const IconData kstar01 =
      IconData(0xece7, fontFamily: _untitledUiFamily);
  static const IconData kstar02 =
      IconData(0xece8, fontFamily: _untitledUiFamily);
  static const IconData kstar03 =
      IconData(0xece9, fontFamily: _untitledUiFamily);
  static const IconData kstar04 =
      IconData(0xecea, fontFamily: _untitledUiFamily);
  static const IconData kstar05 =
      IconData(0xeceb, fontFamily: _untitledUiFamily);
  static const IconData kstar06 =
      IconData(0xecec, fontFamily: _untitledUiFamily);
  static const IconData kstar07 =
      IconData(0xeced, fontFamily: _untitledUiFamily);
  static const IconData kstars01 =
      IconData(0xecee, fontFamily: _untitledUiFamily);
  static const IconData kstars02 =
      IconData(0xecef, fontFamily: _untitledUiFamily);
  static const IconData kstars03 =
      IconData(0xecf0, fontFamily: _untitledUiFamily);
  static const IconData kstickerCircle =
      IconData(0xecf1, fontFamily: _untitledUiFamily);
  static const IconData kstickerSquare =
      IconData(0xecf2, fontFamily: _untitledUiFamily);
  static const IconData kstopSquare =
      IconData(0xecf5, fontFamily: _untitledUiFamily);
  static const IconData kstrikethrough01 =
      IconData(0xecf6, fontFamily: _untitledUiFamily);
  static const IconData kstrikethrough02 =
      IconData(0xecf7, fontFamily: _untitledUiFamily);
  static const IconData kstrikethroughSquare =
      IconData(0xecf8, fontFamily: _untitledUiFamily);
  static const IconData ksubscript =
      IconData(0xecf9, fontFamily: _untitledUiFamily);
  static const IconData ksunrise =
      IconData(0xecfb, fontFamily: _untitledUiFamily);
  static const IconData ksunset =
      IconData(0xecfc, fontFamily: _untitledUiFamily);
  static const IconData ksunSetting01 =
      IconData(0xecfd, fontFamily: _untitledUiFamily);
  static const IconData ksunSetting02 =
      IconData(0xecfe, fontFamily: _untitledUiFamily);
  static const IconData ksunSetting03 =
      IconData(0xecff, fontFamily: _untitledUiFamily);
  static const IconData kswitchHorizontal01 =
      IconData(0xed00, fontFamily: _untitledUiFamily);
  static const IconData kswitchHorizontal02 =
      IconData(0xed01, fontFamily: _untitledUiFamily);
  static const IconData kswitchVertical01 =
      IconData(0xed02, fontFamily: _untitledUiFamily);
  static const IconData kswitchVertical02 =
      IconData(0xed03, fontFamily: _untitledUiFamily);
  static const IconData ktablet01 =
      IconData(0xed05, fontFamily: _untitledUiFamily);
  static const IconData ktablet02 =
      IconData(0xed06, fontFamily: _untitledUiFamily);
  static const IconData ktag01 =
      IconData(0xed07, fontFamily: _untitledUiFamily);
  static const IconData ktag02 =
      IconData(0xed08, fontFamily: _untitledUiFamily);
  static const IconData ktag03 =
      IconData(0xed09, fontFamily: _untitledUiFamily);
  static const IconData ktarget01 =
      IconData(0xed0a, fontFamily: _untitledUiFamily);
  static const IconData ktarget02 =
      IconData(0xed0b, fontFamily: _untitledUiFamily);
  static const IconData ktarget03 =
      IconData(0xed0c, fontFamily: _untitledUiFamily);
  static const IconData ktarget04 =
      IconData(0xed0d, fontFamily: _untitledUiFamily);
  static const IconData ktarget05 =
      IconData(0xed0e, fontFamily: _untitledUiFamily);
  static const IconData ktelescope =
      IconData(0xed0f, fontFamily: _untitledUiFamily);
  static const IconData kterminalBrowser =
      IconData(0xed11, fontFamily: _untitledUiFamily);
  static const IconData kterminalCircle =
      IconData(0xed12, fontFamily: _untitledUiFamily);
  static const IconData kterminalSquare =
      IconData(0xed13, fontFamily: _untitledUiFamily);
  static const IconData ktextInput =
      IconData(0xed14, fontFamily: _untitledUiFamily);
  static const IconData kthermometer01 =
      IconData(0xed15, fontFamily: _untitledUiFamily);
  static const IconData kthermometer02 =
      IconData(0xed16, fontFamily: _untitledUiFamily);
  static const IconData kthermometer03 =
      IconData(0xed17, fontFamily: _untitledUiFamily);
  static const IconData kthermometerCold =
      IconData(0xed18, fontFamily: _untitledUiFamily);
  static const IconData kthermometerWarm =
      IconData(0xed19, fontFamily: _untitledUiFamily);
  static const IconData kthumbsDown =
      IconData(0xed1a, fontFamily: _untitledUiFamily);
  static const IconData kthumbsUp =
      IconData(0xed1b, fontFamily: _untitledUiFamily);
  static const IconData kticket01 =
      IconData(0xed1c, fontFamily: _untitledUiFamily);
  static const IconData kticket02 =
      IconData(0xed1d, fontFamily: _untitledUiFamily);
  static const IconData ktoggle01Left =
      IconData(0xed1e, fontFamily: _untitledUiFamily);
  static const IconData ktoggle01Right =
      IconData(0xed1f, fontFamily: _untitledUiFamily);
  static const IconData ktoggle02Left =
      IconData(0xed20, fontFamily: _untitledUiFamily);
  static const IconData ktoggle02Right =
      IconData(0xed21, fontFamily: _untitledUiFamily);
  static const IconData ktoggle03Left =
      IconData(0xed22, fontFamily: _untitledUiFamily);
  static const IconData ktoggle03Right =
      IconData(0xed23, fontFamily: _untitledUiFamily);
  static const IconData ktool01 =
      IconData(0xed24, fontFamily: _untitledUiFamily);
  static const IconData ktool02 =
      IconData(0xed25, fontFamily: _untitledUiFamily);
  static const IconData ktrain =
      IconData(0xed26, fontFamily: _untitledUiFamily);
  static const IconData ktram = IconData(0xed27, fontFamily: _untitledUiFamily);
  static const IconData ktransform =
      IconData(0xed28, fontFamily: _untitledUiFamily);
  static const IconData ktranslate01 =
      IconData(0xed29, fontFamily: _untitledUiFamily);
  static const IconData ktranslate02 =
      IconData(0xed2a, fontFamily: _untitledUiFamily);
  static const IconData ktrash01 =
      IconData(0xed2b, fontFamily: _untitledUiFamily);
  static const IconData ktrash02 =
      IconData(0xed2c, fontFamily: _untitledUiFamily);
  static const IconData ktrash03 =
      IconData(0xed2d, fontFamily: _untitledUiFamily);
  static const IconData ktrash04 =
      IconData(0xed2e, fontFamily: _untitledUiFamily);
  static const IconData ktrendDown01 =
      IconData(0xed2f, fontFamily: _untitledUiFamily);
  static const IconData ktrendDown02 =
      IconData(0xed30, fontFamily: _untitledUiFamily);
  static const IconData ktrendUp01 =
      IconData(0xed31, fontFamily: _untitledUiFamily);
  static const IconData ktrendUp02 =
      IconData(0xed32, fontFamily: _untitledUiFamily);
  static const IconData ktrophy01 =
      IconData(0xed34, fontFamily: _untitledUiFamily);
  static const IconData ktrophy02 =
      IconData(0xed35, fontFamily: _untitledUiFamily);
  static const IconData ktruck01 =
      IconData(0xed36, fontFamily: _untitledUiFamily);
  static const IconData ktruck02 =
      IconData(0xed37, fontFamily: _untitledUiFamily);
  static const IconData ktv01 = IconData(0xed38, fontFamily: _untitledUiFamily);
  static const IconData ktv02 = IconData(0xed39, fontFamily: _untitledUiFamily);
  static const IconData ktv03 = IconData(0xed3a, fontFamily: _untitledUiFamily);
  static const IconData ktype01 =
      IconData(0xed3b, fontFamily: _untitledUiFamily);
  static const IconData ktype02 =
      IconData(0xed3c, fontFamily: _untitledUiFamily);
  static const IconData ktypeSquare =
      IconData(0xed3d, fontFamily: _untitledUiFamily);
  static const IconData ktypeStrikethrough01 =
      IconData(0xed3e, fontFamily: _untitledUiFamily);
  static const IconData ktypeStrikethrough02 =
      IconData(0xed3f, fontFamily: _untitledUiFamily);
  static const IconData kumbrella01 =
      IconData(0xed40, fontFamily: _untitledUiFamily);
  static const IconData kumbrella02 =
      IconData(0xed41, fontFamily: _untitledUiFamily);
  static const IconData kumbrella03 =
      IconData(0xed42, fontFamily: _untitledUiFamily);
  static const IconData kunderline01 =
      IconData(0xed43, fontFamily: _untitledUiFamily);
  static const IconData kunderline02 =
      IconData(0xed44, fontFamily: _untitledUiFamily);
  static const IconData kunderlineSquare =
      IconData(0xed45, fontFamily: _untitledUiFamily);
  static const IconData kupload01 =
      IconData(0xed46, fontFamily: _untitledUiFamily);
  static const IconData kupload02 =
      IconData(0xed47, fontFamily: _untitledUiFamily);
  static const IconData kupload03 =
      IconData(0xed48, fontFamily: _untitledUiFamily);
  static const IconData kupload04 =
      IconData(0xed49, fontFamily: _untitledUiFamily);
  static const IconData kuploadCloud01 =
      IconData(0xed4a, fontFamily: _untitledUiFamily);
  static const IconData kuploadCloud02 =
      IconData(0xed4b, fontFamily: _untitledUiFamily);
  static const IconData kusbFlashDrive =
      IconData(0xed4c, fontFamily: _untitledUiFamily);
  static const IconData kuserCheck01 =
      IconData(0xed50, fontFamily: _untitledUiFamily);
  static const IconData kuserCheck02 =
      IconData(0xed51, fontFamily: _untitledUiFamily);
  static const IconData kuserDown01 =
      IconData(0xed53, fontFamily: _untitledUiFamily);
  static const IconData kuserDown02 =
      IconData(0xed54, fontFamily: _untitledUiFamily);
  static const IconData kuserEdit =
      IconData(0xed55, fontFamily: _untitledUiFamily);
  static const IconData kuserLeft01 =
      IconData(0xed56, fontFamily: _untitledUiFamily);
  static const IconData kuserLeft02 =
      IconData(0xed57, fontFamily: _untitledUiFamily);
  static const IconData kuserMinus01 =
      IconData(0xed58, fontFamily: _untitledUiFamily);
  static const IconData kuserMinus02 =
      IconData(0xed59, fontFamily: _untitledUiFamily);
  static const IconData kuserPlus01 =
      IconData(0xed5a, fontFamily: _untitledUiFamily);
  static const IconData kuserPlus02 =
      IconData(0xed5b, fontFamily: _untitledUiFamily);
  static const IconData kuserRight01 =
      IconData(0xed5c, fontFamily: _untitledUiFamily);
  static const IconData kuserRight02 =
      IconData(0xed5d, fontFamily: _untitledUiFamily);
  static const IconData kusers01 =
      IconData(0xed5e, fontFamily: _untitledUiFamily);
  static const IconData kusers02 =
      IconData(0xed5f, fontFamily: _untitledUiFamily);
  static const IconData kusers03 =
      IconData(0xed60, fontFamily: _untitledUiFamily);
  static const IconData kusersCheck =
      IconData(0xed61, fontFamily: _untitledUiFamily);
  static const IconData kusersDown =
      IconData(0xed62, fontFamily: _untitledUiFamily);
  static const IconData kusersEdit =
      IconData(0xed63, fontFamily: _untitledUiFamily);
  static const IconData kusersLeft =
      IconData(0xed64, fontFamily: _untitledUiFamily);
  static const IconData kusersMinus =
      IconData(0xed65, fontFamily: _untitledUiFamily);
  static const IconData kusersPlus =
      IconData(0xed66, fontFamily: _untitledUiFamily);
  static const IconData kusersRight =
      IconData(0xed68, fontFamily: _untitledUiFamily);
  static const IconData kusersUp =
      IconData(0xed69, fontFamily: _untitledUiFamily);
  static const IconData kusersX =
      IconData(0xed6a, fontFamily: _untitledUiFamily);
  static const IconData kuserUp01 =
      IconData(0xed6b, fontFamily: _untitledUiFamily);
  static const IconData kuserUp02 =
      IconData(0xed6c, fontFamily: _untitledUiFamily);
  static const IconData kuserX01 =
      IconData(0xed6d, fontFamily: _untitledUiFamily);
  static const IconData kuserX02 =
      IconData(0xed6e, fontFamily: _untitledUiFamily);
  static const IconData kvariable =
      IconData(0xed6f, fontFamily: _untitledUiFamily);
  static const IconData kvideoRecorder =
      IconData(0xed70, fontFamily: _untitledUiFamily);
  static const IconData kvideoRecorderOff =
      IconData(0xed71, fontFamily: _untitledUiFamily);
  static const IconData kvirus =
      IconData(0xed72, fontFamily: _untitledUiFamily);
  static const IconData kvoicemail =
      IconData(0xed73, fontFamily: _untitledUiFamily);
  static const IconData kvolumeX =
      IconData(0xed78, fontFamily: _untitledUiFamily);
  static const IconData kwallet01 =
      IconData(0xed79, fontFamily: _untitledUiFamily);
  static const IconData kwallet02 =
      IconData(0xed7a, fontFamily: _untitledUiFamily);
  static const IconData kwallet03 =
      IconData(0xed7b, fontFamily: _untitledUiFamily);
  static const IconData kwallet04 =
      IconData(0xed7c, fontFamily: _untitledUiFamily);
  static const IconData kwallet05 =
      IconData(0xed7d, fontFamily: _untitledUiFamily);
  static const IconData kwatchCircle =
      IconData(0xed7e, fontFamily: _untitledUiFamily);
  static const IconData kwatchSquare =
      IconData(0xed7f, fontFamily: _untitledUiFamily);
  static const IconData kwaves =
      IconData(0xed80, fontFamily: _untitledUiFamily);
  static const IconData kwebcam01 =
      IconData(0xed81, fontFamily: _untitledUiFamily);
  static const IconData kwebcam02 =
      IconData(0xed82, fontFamily: _untitledUiFamily);
  static const IconData kwifi = IconData(0xed83, fontFamily: _untitledUiFamily);
  static const IconData kwind01 =
      IconData(0xed85, fontFamily: _untitledUiFamily);
  static const IconData kwind02 =
      IconData(0xed86, fontFamily: _untitledUiFamily);
  static const IconData kwind03 =
      IconData(0xed87, fontFamily: _untitledUiFamily);
  static const IconData kx = IconData(0xed88, fontFamily: _untitledUiFamily);
  static const IconData kxClose =
      IconData(0xed8a, fontFamily: _untitledUiFamily);
  static const IconData kxSquare =
      IconData(0xed8b, fontFamily: _untitledUiFamily);
  static const IconData kyoutube =
      IconData(0xed8c, fontFamily: _untitledUiFamily);
  static const IconData kzap = IconData(0xed8d, fontFamily: _untitledUiFamily);
  static const IconData kzapCircle =
      IconData(0xed8e, fontFamily: _untitledUiFamily);
  static const IconData kzapFast =
      IconData(0xed8f, fontFamily: _untitledUiFamily);
  static const IconData kzapOff =
      IconData(0xed90, fontFamily: _untitledUiFamily);
  static const IconData kzapSquare =
      IconData(0xed91, fontFamily: _untitledUiFamily);
  static const IconData kzoomIn =
      IconData(0xed92, fontFamily: _untitledUiFamily);
  static const IconData kzoomOut =
      IconData(0xed93, fontFamily: _untitledUiFamily);

  // Untitled-Filled
  static const IconData kcloud0112w1 =
      IconData(0xe900, fontFamily: _untitledFilledFamily);
  static const IconData kcloud0212w1 =
      IconData(0xe901, fontFamily: _untitledFilledFamily);
  static const IconData kcloud0324w1 =
      IconData(0xe902, fontFamily: _untitledFilledFamily);
  static const IconData kcloudLightning0w10 =
      IconData(0xe903, fontFamily: _untitledFilledFamily);
  static const IconData kcloud0moonw1 =
      IconData(0xe904, fontFamily: _untitledFilledFamily);
  static const IconData kcloudOff0w1 =
      IconData(0xe905, fontFamily: _untitledFilledFamily);
  static const IconData kcloudRaining01e2tw15 =
      IconData(0xe906, fontFamily: _untitledFilledFamily);
  static const IconData kcloudRaining02tw15 =
      IconData(0xe907, fontFamily: _untitledFilledFamily);
  static const IconData kcloudRaining0tw153 =
      IconData(0xe908, fontFamily: _untitledFilledFamily);
  static const IconData kcloudRaining0w1t54 =
      IconData(0xe909, fontFamily: _untitledFilledFamily);
  static const IconData kcloudRaining0w15t5 =
      IconData(0xe90a, fontFamily: _untitledFilledFamily);
  static const IconData kcloudRainingT5w106 =
      IconData(0xe90b, fontFamily: _untitledFilledFamily);
  static const IconData kcloudSnowingW10t51 =
      IconData(0xe90c, fontFamily: _untitledFilledFamily);
  static const IconData kcloudSnowing0t5w12 =
      IconData(0xe90d, fontFamily: _untitledFilledFamily);
  static const IconData kcloudSun01tw15 =
      IconData(0xe90e, fontFamily: _untitledFilledFamily);
  static const IconData kcloudSun0w12t5 =
      IconData(0xe90f, fontFamily: _untitledFilledFamily);
  static const IconData kcloudSun0tw153 =
      IconData(0xe910, fontFamily: _untitledFilledFamily);
  static const IconData kdroplets01w1t5 =
      IconData(0xe911, fontFamily: _untitledFilledFamily);
  static const IconData kdroplets0w12t5 =
      IconData(0xe912, fontFamily: _untitledFilledFamily);
  static const IconData kdroplets03w1t5 =
      IconData(0xe913, fontFamily: _untitledFilledFamily);
  static const IconData khurricane01t5w1 =
      IconData(0xe914, fontFamily: _untitledFilledFamily);
  static const IconData khurricane02w1t5 =
      IconData(0xe915, fontFamily: _untitledFilledFamily);
  static const IconData klightning0w11t5 =
      IconData(0xe916, fontFamily: _untitledFilledFamily);
  static const IconData klightning02w1t5 =
      IconData(0xe917, fontFamily: _untitledFilledFamily);
  static const IconData kmoon0w11t5 =
      IconData(0xe918, fontFamily: _untitledFilledFamily);
  static const IconData kmoon0w12t5 =
      IconData(0xe919, fontFamily: _untitledFilledFamily);
  static const IconData kmoonEclipset5w1 =
      IconData(0xe91a, fontFamily: _untitledFilledFamily);
  static const IconData kmoonStart5w1 =
      IconData(0xe91b, fontFamily: _untitledFilledFamily);
  static const IconData kstars01t5w1 =
      IconData(0xe91c, fontFamily: _untitledFilledFamily);
  static const IconData kstars02t5w1 =
      IconData(0xe91d, fontFamily: _untitledFilledFamily);
  static const IconData kstars03t5w1 =
      IconData(0xe91e, fontFamily: _untitledFilledFamily);
  static const IconData ksunt5w1 =
      IconData(0xe91f, fontFamily: _untitledFilledFamily);
  static const IconData ksunriset5w1 =
      IconData(0xe920, fontFamily: _untitledFilledFamily);
  static const IconData ksunsett5w1 =
      IconData(0xe921, fontFamily: _untitledFilledFamily);
  static const IconData ksunSetting01tw15 =
      IconData(0xe922, fontFamily: _untitledFilledFamily);
  static const IconData ksunSetting02t5w1 =
      IconData(0xe923, fontFamily: _untitledFilledFamily);
  static const IconData ksunSetting03tw15 =
      IconData(0xe924, fontFamily: _untitledFilledFamily);
  static const IconData kthermometer0tw151 =
      IconData(0xe925, fontFamily: _untitledFilledFamily);
  static const IconData kthermometer0tw152 =
      IconData(0xe926, fontFamily: _untitledFilledFamily);
  static const IconData kthermometer03tw15 =
      IconData(0xe927, fontFamily: _untitledFilledFamily);
  static const IconData kthermometerCtw15old =
      IconData(0xe928, fontFamily: _untitledFilledFamily);
  static const IconData kthermometerWatw15rm =
      IconData(0xe929, fontFamily: _untitledFilledFamily);
  static const IconData kumbrella01t5w1 =
      IconData(0xe92a, fontFamily: _untitledFilledFamily);
  static const IconData kumbrella02t5w1 =
      IconData(0xe92b, fontFamily: _untitledFilledFamily);
  static const IconData kumbrella03t5w1 =
      IconData(0xe92c, fontFamily: _untitledFilledFamily);
  static const IconData kfaceContentt5w1 =
      IconData(0xe92d, fontFamily: _untitledFilledFamily);
  static const IconData kfaceFrownt5w1 =
      IconData(0xe92e, fontFamily: _untitledFilledFamily);
  static const IconData kfaceHappyt5w1 =
      IconData(0xe92f, fontFamily: _untitledFilledFamily);
  static const IconData kfaceNeutralt5w1 =
      IconData(0xe930, fontFamily: _untitledFilledFamily);
  static const IconData kfaceSadt5w1 =
      IconData(0xe931, fontFamily: _untitledFilledFamily);
  static const IconData kfaceSmilet5w1 =
      IconData(0xe932, fontFamily: _untitledFilledFamily);
  static const IconData kfaceWinkt5w1 =
      IconData(0xe933, fontFamily: _untitledFilledFamily);
  static const IconData kuser01t5w1 =
      IconData(0xe934, fontFamily: _untitledFilledFamily);
  static const IconData kuser02t5w1 =
      IconData(0xe935, fontFamily: _untitledFilledFamily);
  static const IconData kuser03t5w1 =
      IconData(0xe936, fontFamily: _untitledFilledFamily);
  static const IconData kuserCheck01t5w1 =
      IconData(0xe937, fontFamily: _untitledFilledFamily);
  static const IconData kuserCheck02t5w1 =
      IconData(0xe938, fontFamily: _untitledFilledFamily);
  static const IconData kuserCirclet5w1 =
      IconData(0xe939, fontFamily: _untitledFilledFamily);
  static const IconData kuserDown01t5w1 =
      IconData(0xe93a, fontFamily: _untitledFilledFamily);
  static const IconData kuserDown02t5w1 =
      IconData(0xe93b, fontFamily: _untitledFilledFamily);
  static const IconData kuserEditt5w1 =
      IconData(0xe93c, fontFamily: _untitledFilledFamily);
  static const IconData kuserLeft01t5w1 =
      IconData(0xe93d, fontFamily: _untitledFilledFamily);
  static const IconData kuserLeft02t5w1 =
      IconData(0xe93e, fontFamily: _untitledFilledFamily);
  static const IconData kuserMinus01t5w1 =
      IconData(0xe93f, fontFamily: _untitledFilledFamily);
  static const IconData kuserMinus02t5w1 =
      IconData(0xe940, fontFamily: _untitledFilledFamily);
  static const IconData kuserPlus01t5w1 =
      IconData(0xe941, fontFamily: _untitledFilledFamily);
  static const IconData kuserPlus02t5w1 =
      IconData(0xe942, fontFamily: _untitledFilledFamily);
  static const IconData kuserRight01t5w1 =
      IconData(0xe943, fontFamily: _untitledFilledFamily);
  static const IconData kuserRight02t5w1 =
      IconData(0xe944, fontFamily: _untitledFilledFamily);
  static const IconData kusers01t5w1 =
      IconData(0xe945, fontFamily: _untitledFilledFamily);
  static const IconData kusers02t5w1 =
      IconData(0xe946, fontFamily: _untitledFilledFamily);
  static const IconData kusers03t5w1 =
      IconData(0xe947, fontFamily: _untitledFilledFamily);
  static const IconData kusersCheckt5w1 =
      IconData(0xe948, fontFamily: _untitledFilledFamily);
  static const IconData kusersDownt5w1 =
      IconData(0xe949, fontFamily: _untitledFilledFamily);
  static const IconData kusersEditt5w1 =
      IconData(0xe94a, fontFamily: _untitledFilledFamily);
  static const IconData kusersLeftt5w1 =
      IconData(0xe94b, fontFamily: _untitledFilledFamily);
  static const IconData kusersMinust5w1 =
      IconData(0xe94c, fontFamily: _untitledFilledFamily);
  static const IconData kusersPlust5w1 =
      IconData(0xe94d, fontFamily: _untitledFilledFamily);
  static const IconData kuserSquaret5w1 =
      IconData(0xe94e, fontFamily: _untitledFilledFamily);
  static const IconData kusersRightt5w1 =
      IconData(0xe94f, fontFamily: _untitledFilledFamily);
  static const IconData kusersUpt5w1 =
      IconData(0xe950, fontFamily: _untitledFilledFamily);
  static const IconData kusersXw1w1 =
      IconData(0xe951, fontFamily: _untitledFilledFamily);
  static const IconData kuserUp01w1w1 =
      IconData(0xe952, fontFamily: _untitledFilledFamily);
  static const IconData kuserUp02w1w1 =
      IconData(0xe953, fontFamily: _untitledFilledFamily);
  static const IconData kuserX01w1 =
      IconData(0xe954, fontFamily: _untitledFilledFamily);
  static const IconData kuserX02w1 =
      IconData(0xe955, fontFamily: _untitledFilledFamily);
  static const IconData kalarmClockw1 =
      IconData(0xe956, fontFamily: _untitledFilledFamily);
  static const IconData kalarmClockChecw1k =
      IconData(0xe957, fontFamily: _untitledFilledFamily);
  static const IconData kalarmClockMinw1us =
      IconData(0xe958, fontFamily: _untitledFilledFamily);
  static const IconData kalarmClockOffw1 =
      IconData(0xe959, fontFamily: _untitledFilledFamily);
  static const IconData kalarmClockPlusw1 =
      IconData(0xe95a, fontFamily: _untitledFilledFamily);
  static const IconData kcalendarw1 =
      IconData(0xe95b, fontFamily: _untitledFilledFamily);
  static const IconData kcalendarCheckW101 =
      IconData(0xe95c, fontFamily: _untitledFilledFamily);
  static const IconData kcalendarCw1heck02 =
      IconData(0xe95d, fontFamily: _untitledFilledFamily);
  static const IconData kcalendarDatw1e =
      IconData(0xe95e, fontFamily: _untitledFilledFamily);
  static const IconData kcalendarHeartW101 =
      IconData(0xe95f, fontFamily: _untitledFilledFamily);
  static const IconData kcalendarHeart0w12 =
      IconData(0xe960, fontFamily: _untitledFilledFamily);
  static const IconData kcalendarMinus0w11 =
      IconData(0xe961, fontFamily: _untitledFilledFamily);
  static const IconData kcalendarMinusW102 =
      IconData(0xe962, fontFamily: _untitledFilledFamily);
  static const IconData kcalendarPlusW101 =
      IconData(0xe963, fontFamily: _untitledFilledFamily);
  static const IconData kcalendarPlusW102 =
      IconData(0xe964, fontFamily: _untitledFilledFamily);
  static const IconData kclockw1 =
      IconData(0xe965, fontFamily: _untitledFilledFamily);
  static const IconData kclockCheckw1 =
      IconData(0xe966, fontFamily: _untitledFilledFamily);
  static const IconData kclockPlusw1 =
      IconData(0xe967, fontFamily: _untitledFilledFamily);
  static const IconData kclockSnoozew1 =
      IconData(0xe968, fontFamily: _untitledFilledFamily);
  static const IconData kclockStopwatchw1 =
      IconData(0xe969, fontFamily: _untitledFilledFamily);
  static const IconData khourglass01w1 =
      IconData(0xe96a, fontFamily: _untitledFilledFamily);
  static const IconData khourglass02w1 =
      IconData(0xe96b, fontFamily: _untitledFilledFamily);
  static const IconData khourglass03w1 =
      IconData(0xe96c, fontFamily: _untitledFilledFamily);
  static const IconData kwatchCirclew1 =
      IconData(0xe96d, fontFamily: _untitledFilledFamily);
  static const IconData kwatchSquarew1 =
      IconData(0xe96e, fontFamily: _untitledFilledFamily);
  static const IconData kcirclew1 =
      IconData(0xe96f, fontFamily: _untitledFilledFamily);
  static const IconData kcube01w1 =
      IconData(0xe970, fontFamily: _untitledFilledFamily);
  static const IconData kcube02w1 =
      IconData(0xe971, fontFamily: _untitledFilledFamily);
  static const IconData kcube03w1 =
      IconData(0xe972, fontFamily: _untitledFilledFamily);
  static const IconData kcube04w1 =
      IconData(0xe973, fontFamily: _untitledFilledFamily);
  static const IconData kdice1w1 =
      IconData(0xe974, fontFamily: _untitledFilledFamily);
  static const IconData kdice2w1 =
      IconData(0xe975, fontFamily: _untitledFilledFamily);
  static const IconData kdice3w1 =
      IconData(0xe976, fontFamily: _untitledFilledFamily);
  static const IconData kdice4w1 =
      IconData(0xe977, fontFamily: _untitledFilledFamily);
  static const IconData kdice5w1 =
      IconData(0xe978, fontFamily: _untitledFilledFamily);
  static const IconData kdice6w1 =
      IconData(0xe979, fontFamily: _untitledFilledFamily);
  static const IconData khexagon01w1 =
      IconData(0xe97a, fontFamily: _untitledFilledFamily);
  static const IconData khexagon02w1 =
      IconData(0xe97b, fontFamily: _untitledFilledFamily);
  static const IconData koctagonw1 =
      IconData(0xe97c, fontFamily: _untitledFilledFamily);
  static const IconData kpentagonw1 =
      IconData(0xe97d, fontFamily: _untitledFilledFamily);
  static const IconData ksquarew1 =
      IconData(0xe97e, fontFamily: _untitledFilledFamily);
  static const IconData kstar01w1 =
      IconData(0xe97f, fontFamily: _untitledFilledFamily);
  static const IconData kstar02w1 =
      IconData(0xe980, fontFamily: _untitledFilledFamily);
  static const IconData kstar03w1 =
      IconData(0xe981, fontFamily: _untitledFilledFamily);
  static const IconData kstar04w1 =
      IconData(0xe982, fontFamily: _untitledFilledFamily);
  static const IconData kstar05w1 =
      IconData(0xe983, fontFamily: _untitledFilledFamily);
  static const IconData kstar06w1 =
      IconData(0xe984, fontFamily: _untitledFilledFamily);
  static const IconData ktrianglew1 =
      IconData(0xe985, fontFamily: _untitledFilledFamily);
  static const IconData kfaceIdSquarew1 =
      IconData(0xe986, fontFamily: _untitledFilledFamily);
  static const IconData kfileLock01w1 =
      IconData(0xe987, fontFamily: _untitledFilledFamily);
  static const IconData kfileLock02w1 =
      IconData(0xe988, fontFamily: _untitledFilledFamily);
  static const IconData kfileLock03w1 =
      IconData(0xe989, fontFamily: _untitledFilledFamily);
  static const IconData kfileShield01w1 =
      IconData(0xe98a, fontFamily: _untitledFilledFamily);
  static const IconData kfileShield02w1 =
      IconData(0xe98b, fontFamily: _untitledFilledFamily);
  static const IconData kfileShield03w1 =
      IconData(0xe98c, fontFamily: _untitledFilledFamily);
  static const IconData kfolderShieldw1 =
      IconData(0xe98d, fontFamily: _untitledFilledFamily);
  static const IconData kkey01w1 =
      IconData(0xe98e, fontFamily: _untitledFilledFamily);
  static const IconData kkey02w1 =
      IconData(0xe98f, fontFamily: _untitledFilledFamily);
  static const IconData klock01w1 =
      IconData(0xe990, fontFamily: _untitledFilledFamily);
  static const IconData klock02w1 =
      IconData(0xe991, fontFamily: _untitledFilledFamily);
  static const IconData klock03w1 =
      IconData(0xe992, fontFamily: _untitledFilledFamily);
  static const IconData klock04w1 =
      IconData(0xe993, fontFamily: _untitledFilledFamily);
  static const IconData klockKeyholeCirclew1 =
      IconData(0xe994, fontFamily: _untitledFilledFamily);
  static const IconData klockKeyholeSquarew1 =
      IconData(0xe995, fontFamily: _untitledFilledFamily);
  static const IconData klockUnlocked01w1 =
      IconData(0xe996, fontFamily: _untitledFilledFamily);
  static const IconData klockUnlocked02w1 =
      IconData(0xe997, fontFamily: _untitledFilledFamily);
  static const IconData klockUnlocked03w1 =
      IconData(0xe998, fontFamily: _untitledFilledFamily);
  static const IconData klockUnlocked04w1 =
      IconData(0xe999, fontFamily: _untitledFilledFamily);
  static const IconData kpasscodew1 =
      IconData(0xe99a, fontFamily: _untitledFilledFamily);
  static const IconData kshield01w1 =
      IconData(0xe99b, fontFamily: _untitledFilledFamily);
  static const IconData kshield02w1 =
      IconData(0xe99c, fontFamily: _untitledFilledFamily);
  static const IconData kshield03w1 =
      IconData(0xe99d, fontFamily: _untitledFilledFamily);
  static const IconData kshieldDollarw1 =
      IconData(0xe99e, fontFamily: _untitledFilledFamily);
  static const IconData kshieldOffw1 =
      IconData(0xe99f, fontFamily: _untitledFilledFamily);
  static const IconData kshieldPlusw1 =
      IconData(0xe9a0, fontFamily: _untitledFilledFamily);
  static const IconData kshieldTickw1 =
      IconData(0xe9a1, fontFamily: _untitledFilledFamily);
  static const IconData kshieldZapw1 =
      IconData(0xe9a2, fontFamily: _untitledFilledFamily);
  static const IconData kairplayw1 =
      IconData(0xe9a3, fontFamily: _untitledFilledFamily);
  static const IconData kairpodsw1 =
      IconData(0xe9a4, fontFamily: _untitledFilledFamily);
  static const IconData kbatteryCharging01w1 =
      IconData(0xe9a5, fontFamily: _untitledFilledFamily);
  static const IconData kbatteryCharging02w1 =
      IconData(0xe9a6, fontFamily: _untitledFilledFamily);
  static const IconData kbatteryEmptyw1 =
      IconData(0xe9a7, fontFamily: _untitledFilledFamily);
  static const IconData kbatteryFullw1 =
      IconData(0xe9a8, fontFamily: _untitledFilledFamily);
  static const IconData kbatteryLoww1 =
      IconData(0xe9a9, fontFamily: _untitledFilledFamily);
  static const IconData kbatteryMidw1 =
      IconData(0xe9aa, fontFamily: _untitledFilledFamily);
  static const IconData kchromeCastw1 =
      IconData(0xe9ab, fontFamily: _untitledFilledFamily);
  static const IconData kclapperboardw1 =
      IconData(0xe9ac, fontFamily: _untitledFilledFamily);
  static const IconData kdisc01w1 =
      IconData(0xe9ad, fontFamily: _untitledFilledFamily);
  static const IconData kdisc02w1 =
      IconData(0xe9ae, fontFamily: _untitledFilledFamily);
  static const IconData kfastBackwardw1 =
      IconData(0xe9af, fontFamily: _untitledFilledFamily);
  static const IconData kfastForwardw1 =
      IconData(0xe9b0, fontFamily: _untitledFilledFamily);
  static const IconData kfilm01w1 =
      IconData(0xe9b1, fontFamily: _untitledFilledFamily);
  static const IconData kfilm02w1 =
      IconData(0xe9b2, fontFamily: _untitledFilledFamily);
  static const IconData kfilm03w1 =
      IconData(0xe9b3, fontFamily: _untitledFilledFamily);
  static const IconData kgamingPad01w1 =
      IconData(0xe9b4, fontFamily: _untitledFilledFamily);
  static const IconData kgamingPad02w1 =
      IconData(0xe9b5, fontFamily: _untitledFilledFamily);
  static const IconData khardDrivew1 =
      IconData(0xe9b6, fontFamily: _untitledFilledFamily);
  static const IconData kheadphones01w1 =
      IconData(0xe9b7, fontFamily: _untitledFilledFamily);
  static const IconData kheadphones02w1 =
      IconData(0xe9b8, fontFamily: _untitledFilledFamily);
  static const IconData kkeyboard01w1 =
      IconData(0xe9b9, fontFamily: _untitledFilledFamily);
  static const IconData kkeyboard02w1 =
      IconData(0xe9ba, fontFamily: _untitledFilledFamily);
  static const IconData klaptop01w1 =
      IconData(0xe9bb, fontFamily: _untitledFilledFamily);
  static const IconData klaptop02w1 =
      IconData(0xe9bc, fontFamily: _untitledFilledFamily);
  static const IconData klightbulb01w1 =
      IconData(0xe9bd, fontFamily: _untitledFilledFamily);
  static const IconData klightbulb02w1 =
      IconData(0xe9be, fontFamily: _untitledFilledFamily);
  static const IconData klightbulb03w1 =
      IconData(0xe9bf, fontFamily: _untitledFilledFamily);
  static const IconData klightbulb04w1 =
      IconData(0xe9c0, fontFamily: _untitledFilledFamily);
  static const IconData klightbulb05w1 =
      IconData(0xe9c1, fontFamily: _untitledFilledFamily);
  static const IconData kmicrophone01w1 =
      IconData(0xe9c2, fontFamily: _untitledFilledFamily);
  static const IconData kmicrophone02w1 =
      IconData(0xe9c3, fontFamily: _untitledFilledFamily);
  static const IconData kmicrophoneOff01w1 =
      IconData(0xe9c4, fontFamily: _untitledFilledFamily);
  static const IconData kmicrophoneOff02w1 =
      IconData(0xe9c5, fontFamily: _untitledFilledFamily);
  static const IconData kmodem01w1 =
      IconData(0xe9c6, fontFamily: _untitledFilledFamily);
  static const IconData kmodem02w1 =
      IconData(0xe9c7, fontFamily: _untitledFilledFamily);
  static const IconData kmonitor01w1 =
      IconData(0xe9c8, fontFamily: _untitledFilledFamily);
  static const IconData kmonitor02w1 =
      IconData(0xe9c9, fontFamily: _untitledFilledFamily);
  static const IconData kmonitor03w1 =
      IconData(0xe9ca, fontFamily: _untitledFilledFamily);
  static const IconData kmonitor04w1 =
      IconData(0xe9cb, fontFamily: _untitledFilledFamily);
  static const IconData kmonitor05w1 =
      IconData(0xe9cc, fontFamily: _untitledFilledFamily);
  static const IconData kmousew1 =
      IconData(0xe9cd, fontFamily: _untitledFilledFamily);
  static const IconData kmusicNote01w1 =
      IconData(0xe9ce, fontFamily: _untitledFilledFamily);
  static const IconData kphone01w1 =
      IconData(0xe9d2, fontFamily: _untitledFilledFamily);
  static const IconData kphone02w1 =
      IconData(0xe9d3, fontFamily: _untitledFilledFamily);
  static const IconData kplayw1 =
      IconData(0xe9d4, fontFamily: _untitledFilledFamily);
  static const IconData kplayCirclew1 =
      IconData(0xe9d5, fontFamily: _untitledFilledFamily);
  static const IconData kplaySquarew1 =
      IconData(0xe9d6, fontFamily: _untitledFilledFamily);
  static const IconData kpodcastw1 =
      IconData(0xe9d7, fontFamily: _untitledFilledFamily);
  static const IconData kpower02w1 =
      IconData(0xe9d8, fontFamily: _untitledFilledFamily);
  static const IconData kpower03w1 =
      IconData(0xe9d9, fontFamily: _untitledFilledFamily);
  static const IconData kprinterw1 =
      IconData(0xe9da, fontFamily: _untitledFilledFamily);
  static const IconData krecording03w1 =
      IconData(0xe9db, fontFamily: _untitledFilledFamily);
  static const IconData ksimcardw1 =
      IconData(0xe9dc, fontFamily: _untitledFilledFamily);
  static const IconData kskipBackw1 =
      IconData(0xe9dd, fontFamily: _untitledFilledFamily);
  static const IconData kskipForwardw1 =
      IconData(0xe9de, fontFamily: _untitledFilledFamily);
  static const IconData ksliders03w1 =
      IconData(0xe9df, fontFamily: _untitledFilledFamily);
  static const IconData kspeaker01w1 =
      IconData(0xe9e0, fontFamily: _untitledFilledFamily);
  static const IconData kspeaker02w1 =
      IconData(0xe9e1, fontFamily: _untitledFilledFamily);
  static const IconData kspeaker03w1 =
      IconData(0xe9e2, fontFamily: _untitledFilledFamily);
  static const IconData kstopw1 =
      IconData(0xe9e3, fontFamily: _untitledFilledFamily);
  static const IconData kstopCirclew1 =
      IconData(0xe9e4, fontFamily: _untitledFilledFamily);
  static const IconData kstopSquarew1 =
      IconData(0xe9e5, fontFamily: _untitledFilledFamily);
  static const IconData ktablet01w1 =
      IconData(0xe9e6, fontFamily: _untitledFilledFamily);
  static const IconData ktablet02w1 =
      IconData(0xe9e7, fontFamily: _untitledFilledFamily);
  static const IconData ktv01w1 =
      IconData(0xe9e8, fontFamily: _untitledFilledFamily);
  static const IconData ktv02w1 =
      IconData(0xe9e9, fontFamily: _untitledFilledFamily);
  static const IconData ktv03w1 =
      IconData(0xe9ea, fontFamily: _untitledFilledFamily);
  static const IconData kusbFlashDrivew1 =
      IconData(0xe9eb, fontFamily: _untitledFilledFamily);
  static const IconData kvideoRecorderw1 =
      IconData(0xe9ec, fontFamily: _untitledFilledFamily);
  static const IconData kvideoRecorderOffw1 =
      IconData(0xe9ed, fontFamily: _untitledFilledFamily);
  static const IconData kvoicemailw1 =
      IconData(0xe9ee, fontFamily: _untitledFilledFamily);
  static const IconData kvolumeMaxw1 =
      IconData(0xe9ef, fontFamily: _untitledFilledFamily);
  static const IconData kvolumeMinw1 =
      IconData(0xe9f0, fontFamily: _untitledFilledFamily);
  static const IconData kvolumeMinusw1 =
      IconData(0xe9f1, fontFamily: _untitledFilledFamily);
  static const IconData kvolumePlusw1 =
      IconData(0xe9f2, fontFamily: _untitledFilledFamily);
  static const IconData kvolumeXw1 =
      IconData(0xe9f3, fontFamily: _untitledFilledFamily);
  static const IconData kwebcam01w1 =
      IconData(0xe9f4, fontFamily: _untitledFilledFamily);
  static const IconData kwebcam02w1 =
      IconData(0xe9f5, fontFamily: _untitledFilledFamily);
  static const IconData kyoutubew1 =
      IconData(0xe9f6, fontFamily: _untitledFilledFamily);
  static const IconData kbusw1 =
      IconData(0xe9f7, fontFamily: _untitledFilledFamily);
  static const IconData kcar01w1 =
      IconData(0xe9f8, fontFamily: _untitledFilledFamily);
  static const IconData kcar02w1 =
      IconData(0xe9f9, fontFamily: _untitledFilledFamily);
  static const IconData kcompass01w1 =
      IconData(0xe9fa, fontFamily: _untitledFilledFamily);
  static const IconData kcompass02w1 =
      IconData(0xe9fb, fontFamily: _untitledFilledFamily);
  static const IconData kcompass03w1 =
      IconData(0xe9fc, fontFamily: _untitledFilledFamily);
  static const IconData kflag01w1 =
      IconData(0xe9fd, fontFamily: _untitledFilledFamily);
  static const IconData kflag02w1 =
      IconData(0xe9fe, fontFamily: _untitledFilledFamily);
  static const IconData kflag03w1 =
      IconData(0xe9ff, fontFamily: _untitledFilledFamily);
  static const IconData kflag04w1 =
      IconData(0xea00, fontFamily: _untitledFilledFamily);
  static const IconData kflag05w1 =
      IconData(0xea01, fontFamily: _untitledFilledFamily);
  static const IconData kflag06w1 =
      IconData(0xea02, fontFamily: _untitledFilledFamily);
  static const IconData kglobe01w1 =
      IconData(0xea03, fontFamily: _untitledFilledFamily);
  static const IconData kglobe02w1 =
      IconData(0xea04, fontFamily: _untitledFilledFamily);
  static const IconData kglobe03w1 =
      IconData(0xea05, fontFamily: _untitledFilledFamily);
  static const IconData kglobe04w1 =
      IconData(0xea06, fontFamily: _untitledFilledFamily);
  static const IconData kglobe05w1 =
      IconData(0xea07, fontFamily: _untitledFilledFamily);
  static const IconData kglobe06w1 =
      IconData(0xea08, fontFamily: _untitledFilledFamily);
  static const IconData kluggage01w1 =
      IconData(0xea09, fontFamily: _untitledFilledFamily);
  static const IconData kluggage02w1 =
      IconData(0xea0a, fontFamily: _untitledFilledFamily);
  static const IconData kluggage03w1 =
      IconData(0xea0b, fontFamily: _untitledFilledFamily);
  static const IconData kmap01w1 =
      IconData(0xea0c, fontFamily: _untitledFilledFamily);
  static const IconData kmap02w1 =
      IconData(0xea0d, fontFamily: _untitledFilledFamily);
  static const IconData kmarkw1 =
      IconData(0xea0e, fontFamily: _untitledFilledFamily);
  static const IconData kmarkerPin01w1 =
      IconData(0xea0f, fontFamily: _untitledFilledFamily);
  static const IconData kmarkerPin02w1 =
      IconData(0xea10, fontFamily: _untitledFilledFamily);
  static const IconData kmarkerPin03w1 =
      IconData(0xea11, fontFamily: _untitledFilledFamily);
  static const IconData kmarkerPin04w1 =
      IconData(0xea12, fontFamily: _untitledFilledFamily);
  static const IconData kmarkerPin05w1 =
      IconData(0xea13, fontFamily: _untitledFilledFamily);
  static const IconData kmarkerPin06w1 =
      IconData(0xea14, fontFamily: _untitledFilledFamily);
  static const IconData knavigationPointer01w1 =
      IconData(0xea15, fontFamily: _untitledFilledFamily);
  static const IconData knavigationPointer02w1 =
      IconData(0xea16, fontFamily: _untitledFilledFamily);
  static const IconData knavigationPointerOff01w1 =
      IconData(0xea17, fontFamily: _untitledFilledFamily);
  static const IconData knavigationPointerOff02w1 =
      IconData(0xea18, fontFamily: _untitledFilledFamily);
  static const IconData kpassportw1 =
      IconData(0xea19, fontFamily: _untitledFilledFamily);
  static const IconData kplanew1 =
      IconData(0xea1a, fontFamily: _untitledFilledFamily);
  static const IconData krocket01w1 =
      IconData(0xea1b, fontFamily: _untitledFilledFamily);
  static const IconData krocket02w1 =
      IconData(0xea1c, fontFamily: _untitledFilledFamily);
  static const IconData kroutew1w1 =
      IconData(0xea1d, fontFamily: _untitledFilledFamily);
  static const IconData kticket01w1 =
      IconData(0xea1e, fontFamily: _untitledFilledFamily);
  static const IconData kticket02w1 =
      IconData(0xea1f, fontFamily: _untitledFilledFamily);
  static const IconData ktrainw1 =
      IconData(0xea20, fontFamily: _untitledFilledFamily);
  static const IconData ktramw1 =
      IconData(0xea21, fontFamily: _untitledFilledFamily);
  static const IconData ktruck01w1 =
      IconData(0xea22, fontFamily: _untitledFilledFamily);
  static const IconData ktruck02w1 =
      IconData(0xea23, fontFamily: _untitledFilledFamily);
  static const IconData kalignBottomW102 =
      IconData(0xea24, fontFamily: _untitledFilledFamily);
  static const IconData kalignHorizontalw1Centre02 =
      IconData(0xea25, fontFamily: _untitledFilledFamily);
  static const IconData kalignLeft02w1 =
      IconData(0xea26, fontFamily: _untitledFilledFamily);
  static const IconData kalignRight02w1 =
      IconData(0xea27, fontFamily: _untitledFilledFamily);
  static const IconData kalignTop02w1 =
      IconData(0xea28, fontFamily: _untitledFilledFamily);
  static const IconData kalignVerticalCw1enter02 =
      IconData(0xea29, fontFamily: _untitledFilledFamily);
  static const IconData kcolumns01w1 =
      IconData(0xea2a, fontFamily: _untitledFilledFamily);
  static const IconData kcolumns02w1 =
      IconData(0xea2b, fontFamily: _untitledFilledFamily);
  static const IconData kcolumns03w1 =
      IconData(0xea2c, fontFamily: _untitledFilledFamily);
  static const IconData kdistributeSpacingHorizontalw1 =
      IconData(0xea2d, fontFamily: _untitledFilledFamily);
  static const IconData kdistributeSpacingVerticalw1 =
      IconData(0xea2e, fontFamily: _untitledFilledFamily);
  static const IconData kdividerw1 =
      IconData(0xea2f, fontFamily: _untitledFilledFamily);
  static const IconData kflexAlignBottomw1 =
      IconData(0xea30, fontFamily: _untitledFilledFamily);
  static const IconData kflexAlignLeftw1 =
      IconData(0xea31, fontFamily: _untitledFilledFamily);
  static const IconData kflexAlignRightw1 =
      IconData(0xea32, fontFamily: _untitledFilledFamily);
  static const IconData kflexAlignTopw1 =
      IconData(0xea33, fontFamily: _untitledFilledFamily);
  static const IconData kgrid01w1 =
      IconData(0xea34, fontFamily: _untitledFilledFamily);
  static const IconData kintersectSquarew1 =
      IconData(0xea35, fontFamily: _untitledFilledFamily);
  static const IconData klayerSinglew1 =
      IconData(0xea36, fontFamily: _untitledFilledFamily);
  static const IconData klayersThree01w1 =
      IconData(0xea37, fontFamily: _untitledFilledFamily);
  static const IconData klayersThree02w1 =
      IconData(0xea38, fontFamily: _untitledFilledFamily);
  static const IconData klayersTwo01w1 =
      IconData(0xea39, fontFamily: _untitledFilledFamily);
  static const IconData klayersTwo02w1 =
      IconData(0xea3a, fontFamily: _untitledFilledFamily);
  static const IconData klayoutAlt01w1 =
      IconData(0xea3b, fontFamily: _untitledFilledFamily);
  static const IconData klayoutAlt02w1 =
      IconData(0xea3c, fontFamily: _untitledFilledFamily);
  static const IconData klayoutAlt03w1 =
      IconData(0xea3d, fontFamily: _untitledFilledFamily);
  static const IconData klayoutAlt04w1 =
      IconData(0xea3e, fontFamily: _untitledFilledFamily);
  static const IconData klayoutBottomw1 =
      IconData(0xea3f, fontFamily: _untitledFilledFamily);
  static const IconData klayoutGrid01w1 =
      IconData(0xea40, fontFamily: _untitledFilledFamily);
  static const IconData klayoutGrid02w1 =
      IconData(0xea41, fontFamily: _untitledFilledFamily);
  static const IconData klayoutLeftw1 =
      IconData(0xea42, fontFamily: _untitledFilledFamily);
  static const IconData klayoutRightw1 =
      IconData(0xea43, fontFamily: _untitledFilledFamily);
  static const IconData klayoutTopw1 =
      IconData(0xea44, fontFamily: _untitledFilledFamily);
  static const IconData krows01w1 =
      IconData(0xea45, fontFamily: _untitledFilledFamily);
  static const IconData krows02w1 =
      IconData(0xea46, fontFamily: _untitledFilledFamily);
  static const IconData krows03w1 =
      IconData(0xea47, fontFamily: _untitledFilledFamily);
  static const IconData ktablew1 =
      IconData(0xea48, fontFamily: _untitledFilledFamily);
  static const IconData kcamera01w1 =
      IconData(0xea49, fontFamily: _untitledFilledFamily);
  static const IconData kcamera02w1 =
      IconData(0xea4a, fontFamily: _untitledFilledFamily);
  static const IconData kcamera03w1 =
      IconData(0xea4b, fontFamily: _untitledFilledFamily);
  static const IconData kcameraLensw1 =
      IconData(0xea4c, fontFamily: _untitledFilledFamily);
  static const IconData kcameraOffw1 =
      IconData(0xea4d, fontFamily: _untitledFilledFamily);
  static const IconData kcameraPlusw1 =
      IconData(0xea4e, fontFamily: _untitledFilledFamily);
  static const IconData kcolorsw1 =
      IconData(0xea4f, fontFamily: _untitledFilledFamily);
  static const IconData kflashw1 =
      IconData(0xea50, fontFamily: _untitledFilledFamily);
  static const IconData kflashOffw1 =
      IconData(0xea51, fontFamily: _untitledFilledFamily);
  static const IconData kimage01w1 =
      IconData(0xea52, fontFamily: _untitledFilledFamily);
  static const IconData kimage02w1 =
      IconData(0xea53, fontFamily: _untitledFilledFamily);
  static const IconData kimage03w1 =
      IconData(0xea54, fontFamily: _untitledFilledFamily);
  static const IconData kimage04w1 =
      IconData(0xea55, fontFamily: _untitledFilledFamily);
  static const IconData kimage05w1 =
      IconData(0xea56, fontFamily: _untitledFilledFamily);
  static const IconData kimageCheckw1 =
      IconData(0xea57, fontFamily: _untitledFilledFamily);
  static const IconData kimageDownw1 =
      IconData(0xea58, fontFamily: _untitledFilledFamily);
  static const IconData kimageLeftw1 =
      IconData(0xea59, fontFamily: _untitledFilledFamily);
  static const IconData kimagePlusw1 =
      IconData(0xea5a, fontFamily: _untitledFilledFamily);
  static const IconData kimageRightw1 =
      IconData(0xea5b, fontFamily: _untitledFilledFamily);
  static const IconData kimageUpw1 =
      IconData(0xea5c, fontFamily: _untitledFilledFamily);
  static const IconData kimageUserw1 =
      IconData(0xea5d, fontFamily: _untitledFilledFamily);
  static const IconData kimageUserCheckw1 =
      IconData(0xea5e, fontFamily: _untitledFilledFamily);
  static const IconData kimageUserDownw1 =
      IconData(0xea5f, fontFamily: _untitledFilledFamily);
  static const IconData kimageUserLeftw1 =
      IconData(0xea60, fontFamily: _untitledFilledFamily);
  static const IconData kimageUserPlusw1 =
      IconData(0xea61, fontFamily: _untitledFilledFamily);
  static const IconData kimageUserRightw1 =
      IconData(0xea62, fontFamily: _untitledFilledFamily);
  static const IconData kimageUserUpw1 =
      IconData(0xea63, fontFamily: _untitledFilledFamily);
  static const IconData kimageUserXw1 =
      IconData(0xea64, fontFamily: _untitledFilledFamily);
  static const IconData kimageXw1 =
      IconData(0xea65, fontFamily: _untitledFilledFamily);
  static const IconData kactivityHeartw1 =
      IconData(0xea66, fontFamily: _untitledFilledFamily);
  static const IconData karchivew1 =
      IconData(0xea67, fontFamily: _untitledFilledFamily);
  static const IconData kbookmarkw1 =
      IconData(0xea68, fontFamily: _untitledFilledFamily);
  static const IconData kbookmarkAddw1 =
      IconData(0xea69, fontFamily: _untitledFilledFamily);
  static const IconData kbookmarkCheckw1 =
      IconData(0xea6a, fontFamily: _untitledFilledFamily);
  static const IconData kbookmarkMinusw1 =
      IconData(0xea6b, fontFamily: _untitledFilledFamily);
  static const IconData kbookmarkXw1 =
      IconData(0xea6c, fontFamily: _untitledFilledFamily);
  static const IconData kbuilding01w1 =
      IconData(0xea6d, fontFamily: _untitledFilledFamily);
  static const IconData kbuilding02w1 =
      IconData(0xea6e, fontFamily: _untitledFilledFamily);
  static const IconData kbuilding03w1 =
      IconData(0xea6f, fontFamily: _untitledFilledFamily);
  static const IconData kbuilding04w1 =
      IconData(0xea70, fontFamily: _untitledFilledFamily);
  static const IconData kbuilding05w1 =
      IconData(0xea71, fontFamily: _untitledFilledFamily);
  static const IconData kbuilding06w1 =
      IconData(0xea72, fontFamily: _untitledFilledFamily);
  static const IconData kbuilding07w1 =
      IconData(0xea73, fontFamily: _untitledFilledFamily);
  static const IconData kbuilding08w1 =
      IconData(0xea74, fontFamily: _untitledFilledFamily);
  static const IconData kcheckCirclew1 =
      IconData(0xea75, fontFamily: _untitledFilledFamily);
  static const IconData kcheckCircleW1broken =
      IconData(0xea76, fontFamily: _untitledFilledFamily);
  static const IconData kcheckDone01w1 =
      IconData(0xea77, fontFamily: _untitledFilledFamily);
  static const IconData kcheckDone02w1 =
      IconData(0xea78, fontFamily: _untitledFilledFamily);
  static const IconData kcheckHeartw1 =
      IconData(0xea79, fontFamily: _untitledFilledFamily);
  static const IconData kcheckSquarew1 =
      IconData(0xea7a, fontFamily: _untitledFilledFamily);
  static const IconData kcheckSquareBrokenw1 =
      IconData(0xea7b, fontFamily: _untitledFilledFamily);
  static const IconData kcheckVerified0w11 =
      IconData(0xea7c, fontFamily: _untitledFilledFamily);
  static const IconData kcheckVerified0w12 =
      IconData(0xea7d, fontFamily: _untitledFilledFamily);
  static const IconData kcheckVerified0w13 =
      IconData(0xea7e, fontFamily: _untitledFilledFamily);
  static const IconData kcloudBlank01w1 =
      IconData(0xea7f, fontFamily: _untitledFilledFamily);
  static const IconData kcloudBlank02w1 =
      IconData(0xea80, fontFamily: _untitledFilledFamily);
  static const IconData kcopy01w1 =
      IconData(0xea81, fontFamily: _untitledFilledFamily);
  static const IconData kcopy02w1 =
      IconData(0xea82, fontFamily: _untitledFilledFamily);
  static const IconData kcopy03w1 =
      IconData(0xea83, fontFamily: _untitledFilledFamily);
  static const IconData kcopy04w1 =
      IconData(0xea84, fontFamily: _untitledFilledFamily);
  static const IconData kcopy05w1 =
      IconData(0xea85, fontFamily: _untitledFilledFamily);
  static const IconData kcopy06w1 =
      IconData(0xea86, fontFamily: _untitledFilledFamily);
  static const IconData kcopy07w1 =
      IconData(0xea87, fontFamily: _untitledFilledFamily);
  static const IconData kdivide03w1 =
      IconData(0xea88, fontFamily: _untitledFilledFamily);
  static const IconData kdownload01Altw1 =
      IconData(0xea89, fontFamily: _untitledFilledFamily);
  static const IconData kdownload03w1 =
      IconData(0xea8a, fontFamily: _untitledFilledFamily);
  static const IconData kdownload04w1 =
      IconData(0xea8b, fontFamily: _untitledFilledFamily);
  static const IconData kdownloadCloudw101 =
      IconData(0xea8c, fontFamily: _untitledFilledFamily);
  static const IconData kdownloadClouw1d02 =
      IconData(0xea8d, fontFamily: _untitledFilledFamily);
  static const IconData kedit01w1 =
      IconData(0xea8e, fontFamily: _untitledFilledFamily);
  static const IconData kedit02w1 =
      IconData(0xea8f, fontFamily: _untitledFilledFamily);
  static const IconData kedit03w1 =
      IconData(0xea90, fontFamily: _untitledFilledFamily);
  static const IconData kedit04w1 =
      IconData(0xea91, fontFamily: _untitledFilledFamily);
  static const IconData kedit05w1 =
      IconData(0xea92, fontFamily: _untitledFilledFamily);
  static const IconData keyew1 =
      IconData(0xea93, fontFamily: _untitledFilledFamily);
  static const IconData keyeOffw1 =
      IconData(0xea94, fontFamily: _untitledFilledFamily);
  static const IconData kfilterFunnel01w1 =
      IconData(0xea95, fontFamily: _untitledFilledFamily);
  static const IconData kfilterFunnel02w1 =
      IconData(0xea96, fontFamily: _untitledFilledFamily);
  static const IconData kfilterLinesw1 =
      IconData(0xea97, fontFamily: _untitledFilledFamily);
  static const IconData kgoogleChromew1 =
      IconData(0xea98, fontFamily: _untitledFilledFamily);
  static const IconData khash01w1 =
      IconData(0xea99, fontFamily: _untitledFilledFamily);
  static const IconData khash02w1 =
      IconData(0xea9a, fontFamily: _untitledFilledFamily);
  static const IconData kheartw1 =
      IconData(0xea9b, fontFamily: _untitledFilledFamily);
  static const IconData kheartCirclew1 =
      IconData(0xea9c, fontFamily: _untitledFilledFamily);
  static const IconData kheartHandw1 =
      IconData(0xea9d, fontFamily: _untitledFilledFamily);
  static const IconData kheartHexagonw1 =
      IconData(0xea9e, fontFamily: _untitledFilledFamily);
  static const IconData kheartOctagonw1 =
      IconData(0xea9f, fontFamily: _untitledFilledFamily);
  static const IconData kheartRoundedw1 =
      IconData(0xeaa0, fontFamily: _untitledFilledFamily);
  static const IconData kheartsw1 =
      IconData(0xeaa1, fontFamily: _untitledFilledFamily);
  static const IconData kheartSquarew1 =
      IconData(0xeaa2, fontFamily: _untitledFilledFamily);
  static const IconData khelpCirclew1 =
      IconData(0xeaa3, fontFamily: _untitledFilledFamily);
  static const IconData khelpHexagonw1 =
      IconData(0xeaa4, fontFamily: _untitledFilledFamily);
  static const IconData khelpOctagonw1 =
      IconData(0xeaa5, fontFamily: _untitledFilledFamily);
  static const IconData khelpSquarew1 =
      IconData(0xeaa6, fontFamily: _untitledFilledFamily);
  static const IconData khome01w1 =
      IconData(0xeaa7, fontFamily: _untitledFilledFamily);
  static const IconData khome02w1 =
      IconData(0xeaa8, fontFamily: _untitledFilledFamily);
  static const IconData khome03w1 =
      IconData(0xeaa9, fontFamily: _untitledFilledFamily);
  static const IconData khome04w1 =
      IconData(0xeaaa, fontFamily: _untitledFilledFamily);
  static const IconData khome05w1 =
      IconData(0xeaab, fontFamily: _untitledFilledFamily);
  static const IconData khomeLinew1 =
      IconData(0xeaac, fontFamily: _untitledFilledFamily);
  static const IconData khomeSmilew1 =
      IconData(0xeaad, fontFamily: _untitledFilledFamily);
  static const IconData kinfoCirclew1 =
      IconData(0xeaae, fontFamily: _untitledFilledFamily);
  static const IconData kinfoHexagonw1 =
      IconData(0xeaaf, fontFamily: _untitledFilledFamily);
  static const IconData kinfoOctagonw1 =
      IconData(0xeab0, fontFamily: _untitledFilledFamily);
  static const IconData kinfoSquarew1 =
      IconData(0xeab1, fontFamily: _untitledFilledFamily);
  static const IconData klifeBuoy01w1 =
      IconData(0xeab2, fontFamily: _untitledFilledFamily);
  static const IconData klifeBuoy02w1 =
      IconData(0xeab3, fontFamily: _untitledFilledFamily);
  static const IconData klinkExternal01Altw1 =
      IconData(0xeab4, fontFamily: _untitledFilledFamily);
  static const IconData kloading03w1 =
      IconData(0xeab5, fontFamily: _untitledFilledFamily);
  static const IconData klogIn01Altw1 =
      IconData(0xeab6, fontFamily: _untitledFilledFamily);
  static const IconData klogIn02Altw1 =
      IconData(0xeab7, fontFamily: _untitledFilledFamily);
  static const IconData klogIn03Altw1 =
      IconData(0xeab8, fontFamily: _untitledFilledFamily);
  static const IconData klogIn04Altw1 =
      IconData(0xeab9, fontFamily: _untitledFilledFamily);
  static const IconData klogOut01Altw1 =
      IconData(0xeaba, fontFamily: _untitledFilledFamily);
  static const IconData klogOut02Altw1 =
      IconData(0xeabb, fontFamily: _untitledFilledFamily);
  static const IconData klogOut03Altw1 =
      IconData(0xeabc, fontFamily: _untitledFilledFamily);
  static const IconData klogOut04Altw1 =
      IconData(0xeabd, fontFamily: _untitledFilledFamily);
  static const IconData kmedicalCirclew1 =
      IconData(0xeabe, fontFamily: _untitledFilledFamily);
  static const IconData kmedicalCrossw1 =
      IconData(0xeabf, fontFamily: _untitledFilledFamily);
  static const IconData kmedicalSquarew1 =
      IconData(0xeac0, fontFamily: _untitledFilledFamily);
  static const IconData kminusCirclew1 =
      IconData(0xeac1, fontFamily: _untitledFilledFamily);
  static const IconData kminusSquarew1 =
      IconData(0xeac2, fontFamily: _untitledFilledFamily);
  static const IconData kpercent03w1 =
      IconData(0xeac3, fontFamily: _untitledFilledFamily);
  static const IconData kpin01w1 =
      IconData(0xeac4, fontFamily: _untitledFilledFamily);
  static const IconData kpin02w1 =
      IconData(0xeac5, fontFamily: _untitledFilledFamily);
  static const IconData kplusCirclew1 =
      IconData(0xeac6, fontFamily: _untitledFilledFamily);
  static const IconData kplusSquarew1 =
      IconData(0xeac7, fontFamily: _untitledFilledFamily);
  static const IconData ksave01w1 =
      IconData(0xeac8, fontFamily: _untitledFilledFamily);
  static const IconData ksave02w1 =
      IconData(0xeac9, fontFamily: _untitledFilledFamily);
  static const IconData ksave03w1 =
      IconData(0xeaca, fontFamily: _untitledFilledFamily);
  static const IconData ksettings01w1 =
      IconData(0xeacb, fontFamily: _untitledFilledFamily);
  static const IconData ksettings02w1 =
      IconData(0xeacc, fontFamily: _untitledFilledFamily);
  static const IconData ksettings03w1 =
      IconData(0xeacd, fontFamily: _untitledFilledFamily);
  static const IconData ksettings04w1 =
      IconData(0xeace, fontFamily: _untitledFilledFamily);
  static const IconData kshare01Altw1 =
      IconData(0xeacf, fontFamily: _untitledFilledFamily);
  static const IconData kshare02Altw1 =
      IconData(0xead0, fontFamily: _untitledFilledFamily);
  static const IconData kshare04Altw1 =
      IconData(0xead1, fontFamily: _untitledFilledFamily);
  static const IconData kshare06w1 =
      IconData(0xead2, fontFamily: _untitledFilledFamily);
  static const IconData kshare07w1 =
      IconData(0xead3, fontFamily: _untitledFilledFamily);
  static const IconData kslashCircle02w1 =
      IconData(0xead4, fontFamily: _untitledFilledFamily);
  static const IconData kspeedometer01w1 =
      IconData(0xead5, fontFamily: _untitledFilledFamily);
  static const IconData kspeedometer02w1 =
      IconData(0xead6, fontFamily: _untitledFilledFamily);
  static const IconData kspeedometer03w1 =
      IconData(0xead7, fontFamily: _untitledFilledFamily);
  static const IconData kspeedometer04w1 =
      IconData(0xead8, fontFamily: _untitledFilledFamily);
  static const IconData ktarget01w1 =
      IconData(0xead9, fontFamily: _untitledFilledFamily);
  static const IconData ktoggle01Leftw1 =
      IconData(0xeada, fontFamily: _untitledFilledFamily);
  static const IconData ktoggle01Rightw1 =
      IconData(0xeadb, fontFamily: _untitledFilledFamily);
  static const IconData ktoggle02Leftw1 =
      IconData(0xeadc, fontFamily: _untitledFilledFamily);
  static const IconData ktoggle02Rightw1 =
      IconData(0xeadd, fontFamily: _untitledFilledFamily);
  static const IconData ktoggle03Leftw1 =
      IconData(0xeade, fontFamily: _untitledFilledFamily);
  static const IconData ktoggle03Rightw1 =
      IconData(0xeadf, fontFamily: _untitledFilledFamily);
  static const IconData ktool01w1 =
      IconData(0xeae0, fontFamily: _untitledFilledFamily);
  static const IconData ktool02w1 =
      IconData(0xeae1, fontFamily: _untitledFilledFamily);
  static const IconData ktrash01w1 =
      IconData(0xeae2, fontFamily: _untitledFilledFamily);
  static const IconData ktrash02w1 =
      IconData(0xeae3, fontFamily: _untitledFilledFamily);
  static const IconData ktrash03w1 =
      IconData(0xeae4, fontFamily: _untitledFilledFamily);
  static const IconData ktrash04w1 =
      IconData(0xeae5, fontFamily: _untitledFilledFamily);
  static const IconData kupload01Altw1 =
      IconData(0xeae6, fontFamily: _untitledFilledFamily);
  static const IconData kupload03w1 =
      IconData(0xeae7, fontFamily: _untitledFilledFamily);
  static const IconData kupload04w1 =
      IconData(0xeae8, fontFamily: _untitledFilledFamily);
  static const IconData kuploadCloud01w1 =
      IconData(0xeae9, fontFamily: _untitledFilledFamily);
  static const IconData kuploadCloud02w1 =
      IconData(0xeaea, fontFamily: _untitledFilledFamily);
  static const IconData kvirusw1 =
      IconData(0xeaeb, fontFamily: _untitledFilledFamily);
  static const IconData kxCirclew1 =
      IconData(0xeaec, fontFamily: _untitledFilledFamily);
  static const IconData kxSquarew1 =
      IconData(0xeaed, fontFamily: _untitledFilledFamily);
  static const IconData kzapw1 =
      IconData(0xeaee, fontFamily: _untitledFilledFamily);
  static const IconData kzapCirclew1 =
      IconData(0xeaef, fontFamily: _untitledFilledFamily);
  static const IconData kzapFastw1 =
      IconData(0xeaf0, fontFamily: _untitledFilledFamily);
  static const IconData kzapOffw1 =
      IconData(0xeaf1, fontFamily: _untitledFilledFamily);
  static const IconData kzapSquarew1 =
      IconData(0xeaf2, fontFamily: _untitledFilledFamily);
  static const IconData kbankw1 =
      IconData(0xeaf3, fontFamily: _untitledFilledFamily);
  static const IconData kbankNote01w1 =
      IconData(0xeaf4, fontFamily: _untitledFilledFamily);
  static const IconData kbankNote02w1 =
      IconData(0xeaf5, fontFamily: _untitledFilledFamily);
  static const IconData kbankNote03w1 =
      IconData(0xeaf6, fontFamily: _untitledFilledFamily);
  static const IconData kcoins01w1 =
      IconData(0xeaf7, fontFamily: _untitledFilledFamily);
  static const IconData kcoins02w1 =
      IconData(0xeaf8, fontFamily: _untitledFilledFamily);
  static const IconData kcoins03w1 =
      IconData(0xeaf9, fontFamily: _untitledFilledFamily);
  static const IconData kcoins04w1 =
      IconData(0xeafa, fontFamily: _untitledFilledFamily);
  static const IconData kcoinsHandw1 =
      IconData(0xeafb, fontFamily: _untitledFilledFamily);
  static const IconData kcoinsStacked0w11 =
      IconData(0xeafc, fontFamily: _untitledFilledFamily);
  static const IconData kcoinsStacked0w12 =
      IconData(0xeafd, fontFamily: _untitledFilledFamily);
  static const IconData kcoinsStacked03w1 =
      IconData(0xeafe, fontFamily: _untitledFilledFamily);
  static const IconData kcoinsStacked04w1 =
      IconData(0xeaff, fontFamily: _untitledFilledFamily);
  static const IconData kcoinsSwap01w1 =
      IconData(0xeb00, fontFamily: _untitledFilledFamily);
  static const IconData kcoinsSwap02w1 =
      IconData(0xeb01, fontFamily: _untitledFilledFamily);
  static const IconData kcreditCard01w1 =
      IconData(0xeb02, fontFamily: _untitledFilledFamily);
  static const IconData kcreditCard02w1 =
      IconData(0xeb03, fontFamily: _untitledFilledFamily);
  static const IconData kcreditCardChew1ck =
      IconData(0xeb04, fontFamily: _untitledFilledFamily);
  static const IconData kcreditCardW1down =
      IconData(0xeb05, fontFamily: _untitledFilledFamily);
  static const IconData kcreditCardDow1wnload =
      IconData(0xeb06, fontFamily: _untitledFilledFamily);
  static const IconData kcreditCardEditw1 =
      IconData(0xeb07, fontFamily: _untitledFilledFamily);
  static const IconData kcreditCardLockw1 =
      IconData(0xeb08, fontFamily: _untitledFilledFamily);
  static const IconData kcreditCardMinuw1s =
      IconData(0xeb09, fontFamily: _untitledFilledFamily);
  static const IconData kcreditCardPlusw1 =
      IconData(0xeb0a, fontFamily: _untitledFilledFamily);
  static const IconData kcreditCardRefresw1h =
      IconData(0xeb0b, fontFamily: _untitledFilledFamily);
  static const IconData kcreditCardSearw1ch =
      IconData(0xeb0c, fontFamily: _untitledFilledFamily);
  static const IconData kcreditCardShieldw1 =
      IconData(0xeb0d, fontFamily: _untitledFilledFamily);
  static const IconData kcreditCardUpw1 =
      IconData(0xeb0e, fontFamily: _untitledFilledFamily);
  static const IconData kcreditCardUploadw1 =
      IconData(0xeb0f, fontFamily: _untitledFilledFamily);
  static const IconData kcreditCardXw1 =
      IconData(0xeb10, fontFamily: _untitledFilledFamily);
  static const IconData kcryptocurrency0w11 =
      IconData(0xeb11, fontFamily: _untitledFilledFamily);
  static const IconData kcryptocurrency0w12 =
      IconData(0xeb12, fontFamily: _untitledFilledFamily);
  static const IconData kcryptocurrency0w13 =
      IconData(0xeb13, fontFamily: _untitledFilledFamily);
  static const IconData kcryptocurrencyW104 =
      IconData(0xeb14, fontFamily: _untitledFilledFamily);
  static const IconData kcurrencyBitcoinw1 =
      IconData(0xeb15, fontFamily: _untitledFilledFamily);
  static const IconData kcurrencyBitcoinCirclew1 =
      IconData(0xeb16, fontFamily: _untitledFilledFamily);
  static const IconData kcurrencyDollarw1 =
      IconData(0xeb17, fontFamily: _untitledFilledFamily);
  static const IconData kcurrencyDollarCirclew1 =
      IconData(0xeb18, fontFamily: _untitledFilledFamily);
  static const IconData kcurrencyEthereumw1 =
      IconData(0xeb19, fontFamily: _untitledFilledFamily);
  static const IconData kcurrencyEthereumCirclew1 =
      IconData(0xeb1a, fontFamily: _untitledFilledFamily);
  static const IconData kcurrencyEuroCirclew1 =
      IconData(0xeb1b, fontFamily: _untitledFilledFamily);
  static const IconData kcurrencyPoundCirclew1 =
      IconData(0xeb1c, fontFamily: _untitledFilledFamily);
  static const IconData kcurrencyRubleCirclew1 =
      IconData(0xeb1d, fontFamily: _untitledFilledFamily);
  static const IconData kcurrencyRupeeCirclew1 =
      IconData(0xeb1e, fontFamily: _untitledFilledFamily);
  static const IconData kcurrencyW1yenCircle =
      IconData(0xeb1f, fontFamily: _untitledFilledFamily);
  static const IconData kdiamondW101 =
      IconData(0xeb20, fontFamily: _untitledFilledFamily);
  static const IconData kdiamond02w1 =
      IconData(0xeb21, fontFamily: _untitledFilledFamily);
  static const IconData kgift01w1 =
      IconData(0xeb22, fontFamily: _untitledFilledFamily);
  static const IconData kgift02w1 =
      IconData(0xeb23, fontFamily: _untitledFilledFamily);
  static const IconData kpiggyBank01w1 =
      IconData(0xeb24, fontFamily: _untitledFilledFamily);
  static const IconData kpiggyBank02w1 =
      IconData(0xeb25, fontFamily: _untitledFilledFamily);
  static const IconData kreceiptw1 =
      IconData(0xeb26, fontFamily: _untitledFilledFamily);
  static const IconData kreceiptCheckw1 =
      IconData(0xeb27, fontFamily: _untitledFilledFamily);
  static const IconData ksafew1 =
      IconData(0xeb28, fontFamily: _untitledFilledFamily);
  static const IconData ksale01w1 =
      IconData(0xeb29, fontFamily: _untitledFilledFamily);
  static const IconData ksale02w1 =
      IconData(0xeb2a, fontFamily: _untitledFilledFamily);
  static const IconData ksale03w1 =
      IconData(0xeb2b, fontFamily: _untitledFilledFamily);
  static const IconData ksale04w1 =
      IconData(0xeb2c, fontFamily: _untitledFilledFamily);
  static const IconData kscales01w1 =
      IconData(0xeb2d, fontFamily: _untitledFilledFamily);
  static const IconData kscales02w1 =
      IconData(0xeb2e, fontFamily: _untitledFilledFamily);
  static const IconData kshoppingBag0w11 =
      IconData(0xeb2f, fontFamily: _untitledFilledFamily);
  static const IconData kshoppingBag0w12 =
      IconData(0xeb30, fontFamily: _untitledFilledFamily);
  static const IconData kshoppingBag0w13 =
      IconData(0xeb31, fontFamily: _untitledFilledFamily);
  static const IconData kshoppingCart0w11 =
      IconData(0xeb32, fontFamily: _untitledFilledFamily);
  static const IconData kshoppingCart0w12 =
      IconData(0xeb33, fontFamily: _untitledFilledFamily);
  static const IconData kshoppingCart0w13 =
      IconData(0xeb34, fontFamily: _untitledFilledFamily);
  static const IconData ktag01w1 =
      IconData(0xeb35, fontFamily: _untitledFilledFamily);
  static const IconData ktag02w1 =
      IconData(0xeb36, fontFamily: _untitledFilledFamily);
  static const IconData ktag03w1 =
      IconData(0xeb37, fontFamily: _untitledFilledFamily);
  static const IconData kwallet01w1 =
      IconData(0xeb38, fontFamily: _untitledFilledFamily);
  static const IconData kwallet02w1 =
      IconData(0xeb39, fontFamily: _untitledFilledFamily);
  static const IconData kwallet03w1 =
      IconData(0xeb3a, fontFamily: _untitledFilledFamily);
  static const IconData kwallet04w1 =
      IconData(0xeb3b, fontFamily: _untitledFilledFamily);
  static const IconData kwallet05w1 =
      IconData(0xeb3c, fontFamily: _untitledFilledFamily);
  static const IconData kboxw1 =
      IconData(0xeb3d, fontFamily: _untitledFilledFamily);
  static const IconData kclipboardw1 =
      IconData(0xeb3e, fontFamily: _untitledFilledFamily);
  static const IconData kclipboardAttacw1hment =
      IconData(0xeb3f, fontFamily: _untitledFilledFamily);
  static const IconData kclipboardCheckw1 =
      IconData(0xeb40, fontFamily: _untitledFilledFamily);
  static const IconData kclipboardDownlow1ad =
      IconData(0xeb41, fontFamily: _untitledFilledFamily);
  static const IconData kclipboardMinw1us =
      IconData(0xeb42, fontFamily: _untitledFilledFamily);
  static const IconData kclipboardPlusw1 =
      IconData(0xeb43, fontFamily: _untitledFilledFamily);
  static const IconData kclipboardXw1 =
      IconData(0xeb44, fontFamily: _untitledFilledFamily);
  static const IconData kfile01w1 =
      IconData(0xeb45, fontFamily: _untitledFilledFamily);
  static const IconData kfile02w1 =
      IconData(0xeb46, fontFamily: _untitledFilledFamily);
  static const IconData kfile03w1 =
      IconData(0xeb47, fontFamily: _untitledFilledFamily);
  static const IconData kfile04w1 =
      IconData(0xeb48, fontFamily: _untitledFilledFamily);
  static const IconData kfile05w1 =
      IconData(0xeb49, fontFamily: _untitledFilledFamily);
  static const IconData kfile06w1 =
      IconData(0xeb4a, fontFamily: _untitledFilledFamily);
  static const IconData kfile07w1 =
      IconData(0xeb4b, fontFamily: _untitledFilledFamily);
  static const IconData kfileAttachment0w11 =
      IconData(0xeb4c, fontFamily: _untitledFilledFamily);
  static const IconData kfileAttachmentW102 =
      IconData(0xeb4d, fontFamily: _untitledFilledFamily);
  static const IconData kfileAttachmentW103 =
      IconData(0xeb4e, fontFamily: _untitledFilledFamily);
  static const IconData kfileAttachment0w14 =
      IconData(0xeb4f, fontFamily: _untitledFilledFamily);
  static const IconData kfileAttachmentw105 =
      IconData(0xeb50, fontFamily: _untitledFilledFamily);
  static const IconData kfileCheck01w1 =
      IconData(0xeb51, fontFamily: _untitledFilledFamily);
  static const IconData kfileCheck02w1 =
      IconData(0xeb52, fontFamily: _untitledFilledFamily);
  static const IconData kfileCheck03w1 =
      IconData(0xeb53, fontFamily: _untitledFilledFamily);
  static const IconData kfileDownload0w11 =
      IconData(0xeb54, fontFamily: _untitledFilledFamily);
  static const IconData kfileDownload0w12 =
      IconData(0xeb55, fontFamily: _untitledFilledFamily);
  static const IconData kfileDownload03w1 =
      IconData(0xeb56, fontFamily: _untitledFilledFamily);
  static const IconData kfileHeart01w1 =
      IconData(0xeb57, fontFamily: _untitledFilledFamily);
  static const IconData kfileHeart02w1 =
      IconData(0xeb58, fontFamily: _untitledFilledFamily);
  static const IconData kfileHeart03w1 =
      IconData(0xeb59, fontFamily: _untitledFilledFamily);
  static const IconData kfileMinus01w1 =
      IconData(0xeb5a, fontFamily: _untitledFilledFamily);
  static const IconData kfileMinus02w1 =
      IconData(0xeb5b, fontFamily: _untitledFilledFamily);
  static const IconData kfileMinus0w13 =
      IconData(0xeb5c, fontFamily: _untitledFilledFamily);
  static const IconData kfilePlus01w1 =
      IconData(0xeb5d, fontFamily: _untitledFilledFamily);
  static const IconData kfilePlus02w1 =
      IconData(0xeb5e, fontFamily: _untitledFilledFamily);
  static const IconData kfilePlus03w1 =
      IconData(0xeb5f, fontFamily: _untitledFilledFamily);
  static const IconData kfileQuestion0w11 =
      IconData(0xeb60, fontFamily: _untitledFilledFamily);
  static const IconData kfileQuestionW102 =
      IconData(0xeb61, fontFamily: _untitledFilledFamily);
  static const IconData kfileQuestion03w1 =
      IconData(0xeb62, fontFamily: _untitledFilledFamily);
  static const IconData kfileSearch01w1 =
      IconData(0xeb63, fontFamily: _untitledFilledFamily);
  static const IconData kfileSearch02w1 =
      IconData(0xeb64, fontFamily: _untitledFilledFamily);
  static const IconData kfileSearch03w1 =
      IconData(0xeb65, fontFamily: _untitledFilledFamily);
  static const IconData kfileX01w1 =
      IconData(0xeb66, fontFamily: _untitledFilledFamily);
  static const IconData kfileX02w1 =
      IconData(0xeb67, fontFamily: _untitledFilledFamily);
  static const IconData kfileX03w1 =
      IconData(0xeb68, fontFamily: _untitledFilledFamily);
  static const IconData kfolderw1 =
      IconData(0xeb69, fontFamily: _untitledFilledFamily);
  static const IconData kfolderCheckw1 =
      IconData(0xeb6a, fontFamily: _untitledFilledFamily);
  static const IconData kfolderClosedw1 =
      IconData(0xeb6b, fontFamily: _untitledFilledFamily);
  static const IconData kfolderDownloadw1 =
      IconData(0xeb6c, fontFamily: _untitledFilledFamily);
  static const IconData kfolderLockw1 =
      IconData(0xeb6d, fontFamily: _untitledFilledFamily);
  static const IconData kfolderMinusw1 =
      IconData(0xeb6e, fontFamily: _untitledFilledFamily);
  static const IconData kfolderPlusw1 =
      IconData(0xeb6f, fontFamily: _untitledFilledFamily);
  static const IconData kfolderQuestionw1 =
      IconData(0xeb70, fontFamily: _untitledFilledFamily);
  static const IconData kfolderSearchw1 =
      IconData(0xeb71, fontFamily: _untitledFilledFamily);
  static const IconData kfolderXw1 =
      IconData(0xeb72, fontFamily: _untitledFilledFamily);
  static const IconData kstickerCirclew1 =
      IconData(0xeb73, fontFamily: _untitledFilledFamily);
  static const IconData kstickerSquarew1 =
      IconData(0xeb74, fontFamily: _untitledFilledFamily);
  static const IconData katom01w1 =
      IconData(0xeb75, fontFamily: _untitledFilledFamily);
  static const IconData katom02w1 =
      IconData(0xeb76, fontFamily: _untitledFilledFamily);
  static const IconData kaward01w1 =
      IconData(0xeb77, fontFamily: _untitledFilledFamily);
  static const IconData kaward02w1 =
      IconData(0xeb78, fontFamily: _untitledFilledFamily);
  static const IconData kaward03w1 =
      IconData(0xeb79, fontFamily: _untitledFilledFamily);
  static const IconData kaward04w1 =
      IconData(0xeb7a, fontFamily: _untitledFilledFamily);
  static const IconData kaward05w1 =
      IconData(0xeb7b, fontFamily: _untitledFilledFamily);
  static const IconData kbackpackw1 =
      IconData(0xeb7c, fontFamily: _untitledFilledFamily);
  static const IconData kbeaker01w1 =
      IconData(0xeb7d, fontFamily: _untitledFilledFamily);
  static const IconData kbeaker02w1 =
      IconData(0xeb7e, fontFamily: _untitledFilledFamily);
  static const IconData kbookClosedw1 =
      IconData(0xeb7f, fontFamily: _untitledFilledFamily);
  static const IconData kbookOpen01w1 =
      IconData(0xeb80, fontFamily: _untitledFilledFamily);
  static const IconData kbookOpen02w1 =
      IconData(0xeb81, fontFamily: _untitledFilledFamily);
  static const IconData kbriefcase01w1 =
      IconData(0xeb82, fontFamily: _untitledFilledFamily);
  static const IconData kbriefcase02w1 =
      IconData(0xeb83, fontFamily: _untitledFilledFamily);
  static const IconData kcalculatorw1 =
      IconData(0xeb84, fontFamily: _untitledFilledFamily);
  static const IconData kcertificate01w1 =
      IconData(0xeb85, fontFamily: _untitledFilledFamily);
  static const IconData kcertificate02w1 =
      IconData(0xeb86, fontFamily: _untitledFilledFamily);
  static const IconData kcompassw1 =
      IconData(0xeb87, fontFamily: _untitledFilledFamily);
  static const IconData kglasses01w1 =
      IconData(0xeb88, fontFamily: _untitledFilledFamily);
  static const IconData kglasses02w1 =
      IconData(0xeb89, fontFamily: _untitledFilledFamily);
  static const IconData kglobeSlated01w1 =
      IconData(0xeb8a, fontFamily: _untitledFilledFamily);
  static const IconData kglobeSlated02w1 =
      IconData(0xeb8b, fontFamily: _untitledFilledFamily);
  static const IconData kgraduationHat0w11 =
      IconData(0xeb8c, fontFamily: _untitledFilledFamily);
  static const IconData kgraduationHat0w12 =
      IconData(0xeb8d, fontFamily: _untitledFilledFamily);
  static const IconData kmicroscopew1 =
      IconData(0xeb8e, fontFamily: _untitledFilledFamily);
  static const IconData krulerw1 =
      IconData(0xeb8f, fontFamily: _untitledFilledFamily);
  static const IconData kstandw1 =
      IconData(0xeb90, fontFamily: _untitledFilledFamily);
  static const IconData ktelescopew1 =
      IconData(0xeb91, fontFamily: _untitledFilledFamily);
  static const IconData ktrophy01w1 =
      IconData(0xeb92, fontFamily: _untitledFilledFamily);
  static const IconData ktrophy02w1 =
      IconData(0xeb93, fontFamily: _untitledFilledFamily);
  static const IconData kbezierCurve01w1 =
      IconData(0xeb94, fontFamily: _untitledFilledFamily);
  static const IconData kbezierCurve02w1 =
      IconData(0xeb95, fontFamily: _untitledFilledFamily);
  static const IconData kbezierCurve03w1 =
      IconData(0xeb96, fontFamily: _untitledFilledFamily);
  static const IconData kbold01w1 =
      IconData(0xeb97, fontFamily: _untitledFilledFamily);
  static const IconData kbold02w1 =
      IconData(0xeb98, fontFamily: _untitledFilledFamily);
  static const IconData kboldSquarew1 =
      IconData(0xeb99, fontFamily: _untitledFilledFamily);
  static const IconData kbrush01w1 =
      IconData(0xeb9a, fontFamily: _untitledFilledFamily);
  static const IconData kbrush02w1 =
      IconData(0xeb9b, fontFamily: _untitledFilledFamily);
  static const IconData kbrush03w1 =
      IconData(0xeb9c, fontFamily: _untitledFilledFamily);
  static const IconData kcircleCutw1 =
      IconData(0xeb9d, fontFamily: _untitledFilledFamily);
  static const IconData kcolors1w1 =
      IconData(0xeb9e, fontFamily: _untitledFilledFamily);
  static const IconData kcontrast01w1 =
      IconData(0xeb9f, fontFamily: _untitledFilledFamily);
  static const IconData kcontrast02w1 =
      IconData(0xeba0, fontFamily: _untitledFilledFamily);
  static const IconData kcontrast03w1 =
      IconData(0xeba1, fontFamily: _untitledFilledFamily);
  static const IconData kcursor01w1 =
      IconData(0xeba2, fontFamily: _untitledFilledFamily);
  static const IconData kcursor02w1 =
      IconData(0xeba3, fontFamily: _untitledFilledFamily);
  static const IconData kcursor03w1 =
      IconData(0xeba4, fontFamily: _untitledFilledFamily);
  static const IconData kcursor04w1 =
      IconData(0xeba5, fontFamily: _untitledFilledFamily);
  static const IconData kcursorBoxw1 =
      IconData(0xeba6, fontFamily: _untitledFilledFamily);
  static const IconData kcursorClick01w1 =
      IconData(0xeba7, fontFamily: _untitledFilledFamily);
  static const IconData kcursorClick02w1 =
      IconData(0xeba8, fontFamily: _untitledFilledFamily);
  static const IconData kdeletew1 =
      IconData(0xeba9, fontFamily: _untitledFilledFamily);
  static const IconData kdotpoints01w1 =
      IconData(0xebaa, fontFamily: _untitledFilledFamily);
  static const IconData kdropw1 =
      IconData(0xebab, fontFamily: _untitledFilledFamily);
  static const IconData kdropperw1 =
      IconData(0xebac, fontFamily: _untitledFilledFamily);
  static const IconData kerasew1r =
      IconData(0xebad, fontFamily: _untitledFilledFamily);
  static const IconData kfeatherw1 =
      IconData(0xebae, fontFamily: _untitledFilledFamily);
  static const IconData kfigmaw1 =
      IconData(0xebaf, fontFamily: _untitledFilledFamily);
  static const IconData kframerw1 =
      IconData(0xebb0, fontFamily: _untitledFilledFamily);
  static const IconData kheading02w1 =
      IconData(0xebb1, fontFamily: _untitledFilledFamily);
  static const IconData kheadingSquarew1 =
      IconData(0xebb2, fontFamily: _untitledFilledFamily);
  static const IconData kimageIndentLw1eft =
      IconData(0xebb3, fontFamily: _untitledFilledFamily);
  static const IconData kimageIndentRigw1ht =
      IconData(0xebb4, fontFamily: _untitledFilledFamily);
  static const IconData kitalic02w1 =
      IconData(0xebb5, fontFamily: _untitledFilledFamily);
  static const IconData kitalicSquarew1 =
      IconData(0xebb6, fontFamily: _untitledFilledFamily);
  static const IconData kleftIndent01w1 =
      IconData(0xebb7, fontFamily: _untitledFilledFamily);
  static const IconData kleftIndent02w1 =
      IconData(0xebb8, fontFamily: _untitledFilledFamily);
  static const IconData kmovew1 =
      IconData(0xebb9, fontFamily: _untitledFilledFamily);
  static const IconData kpaintw1 =
      IconData(0xebba, fontFamily: _untitledFilledFamily);
  static const IconData kpaintPourw1 =
      IconData(0xebbb, fontFamily: _untitledFilledFamily);
  static const IconData kpalettew1 =
      IconData(0xebbc, fontFamily: _untitledFilledFamily);
  static const IconData kpencil01w1 =
      IconData(0xebbd, fontFamily: _untitledFilledFamily);
  static const IconData kpencil02w1 =
      IconData(0xebbe, fontFamily: _untitledFilledFamily);
  static const IconData kpencilLinew1 =
      IconData(0xebbf, fontFamily: _untitledFilledFamily);
  static const IconData kpenTool01w1 =
      IconData(0xebc0, fontFamily: _untitledFilledFamily);
  static const IconData kpenTool02w1 =
      IconData(0xebc1, fontFamily: _untitledFilledFamily);
  static const IconData kpenToolMinusw1 =
      IconData(0xebc2, fontFamily: _untitledFilledFamily);
  static const IconData kpenToolPlusw1 =
      IconData(0xebc3, fontFamily: _untitledFilledFamily);
  static const IconData kperspective01w1 =
      IconData(0xebc4, fontFamily: _untitledFilledFamily);
  static const IconData kperspective02w1 =
      IconData(0xebc5, fontFamily: _untitledFilledFamily);
  static const IconData kpilcrow01w1 =
      IconData(0xebc6, fontFamily: _untitledFilledFamily);
  static const IconData kpilcrow02w1 =
      IconData(0xebc7, fontFamily: _untitledFilledFamily);
  static const IconData kpilcrowSquarew1 =
      IconData(0xebc8, fontFamily: _untitledFilledFamily);
  static const IconData kreflect01w1 =
      IconData(0xebc9, fontFamily: _untitledFilledFamily);
  static const IconData krightIndent01w1 =
      IconData(0xebca, fontFamily: _untitledFilledFamily);
  static const IconData krightIndent02w1 =
      IconData(0xebcb, fontFamily: _untitledFilledFamily);
  static const IconData krollerBrushw1 =
      IconData(0xebcc, fontFamily: _untitledFilledFamily);
  static const IconData kscale01w1 =
      IconData(0xebcd, fontFamily: _untitledFilledFamily);
  static const IconData kscale02w1 =
      IconData(0xebce, fontFamily: _untitledFilledFamily);
  static const IconData kscale03w1 =
      IconData(0xebcf, fontFamily: _untitledFilledFamily);
  static const IconData kskeww1 =
      IconData(0xebd0, fontFamily: _untitledFilledFamily);
  static const IconData kstrikethrough02w1 =
      IconData(0xebd1, fontFamily: _untitledFilledFamily);
  static const IconData kstrikethroughSquarew1 =
      IconData(0xebd2, fontFamily: _untitledFilledFamily);
  static const IconData ktextInputw1 =
      IconData(0xebd3, fontFamily: _untitledFilledFamily);
  static const IconData ktransformw1 =
      IconData(0xebd4, fontFamily: _untitledFilledFamily);
  static const IconData ktype01w1 =
      IconData(0xebd5, fontFamily: _untitledFilledFamily);
  static const IconData ktype02w1 =
      IconData(0xebd6, fontFamily: _untitledFilledFamily);
  static const IconData ktypeSquarew1 =
      IconData(0xebd7, fontFamily: _untitledFilledFamily);
  static const IconData ktypeStrikethrough02w1 =
      IconData(0xebd8, fontFamily: _untitledFilledFamily);
  static const IconData kunderline02w1 =
      IconData(0xebd9, fontFamily: _untitledFilledFamily);
  static const IconData kunderlineSquarew1 =
      IconData(0xebda, fontFamily: _untitledFilledFamily);
  static const IconData kzoomInw1 =
      IconData(0xebdb, fontFamily: _untitledFilledFamily);
  static const IconData kzoomOutw1 =
      IconData(0xebdc, fontFamily: _untitledFilledFamily);
  static const IconData kbracketsw1 =
      IconData(0xebdd, fontFamily: _untitledFilledFamily);
  static const IconData kbrowserw1 =
      IconData(0xebde, fontFamily: _untitledFilledFamily);
  static const IconData kcodeBrowserw1 =
      IconData(0xebdf, fontFamily: _untitledFilledFamily);
  static const IconData kcodeCircle01w1 =
      IconData(0xebe0, fontFamily: _untitledFilledFamily);
  static const IconData kcodeCircle02w1 =
      IconData(0xebe1, fontFamily: _untitledFilledFamily);
  static const IconData kcodeCircle03w1 =
      IconData(0xebe2, fontFamily: _untitledFilledFamily);
  static const IconData kcodepenw1 =
      IconData(0xebe3, fontFamily: _untitledFilledFamily);
  static const IconData kcodeSquare01w1 =
      IconData(0xebe4, fontFamily: _untitledFilledFamily);
  static const IconData kcodeSquare02w1 =
      IconData(0xebe5, fontFamily: _untitledFilledFamily);
  static const IconData kcontainerw1 =
      IconData(0xebe6, fontFamily: _untitledFilledFamily);
  static const IconData kcpuChip01w1 =
      IconData(0xebe7, fontFamily: _untitledFilledFamily);
  static const IconData kcpuChip02w1 =
      IconData(0xebe8, fontFamily: _untitledFilledFamily);
  static const IconData kdataw1 =
      IconData(0xebe9, fontFamily: _untitledFilledFamily);
  static const IconData kdatabase01w1 =
      IconData(0xebea, fontFamily: _untitledFilledFamily);
  static const IconData kdatabase02w1 =
      IconData(0xebeb, fontFamily: _untitledFilledFamily);
  static const IconData kdatabase03w1 =
      IconData(0xebec, fontFamily: _untitledFilledFamily);
  static const IconData kdataflow01w1 =
      IconData(0xebed, fontFamily: _untitledFilledFamily);
  static const IconData kdataflow02w1 =
      IconData(0xebee, fontFamily: _untitledFilledFamily);
  static const IconData kdataflow03w1 =
      IconData(0xebef, fontFamily: _untitledFilledFamily);
  static const IconData kdataflow04w1 =
      IconData(0xebf0, fontFamily: _untitledFilledFamily);
  static const IconData kfileCode01w1 =
      IconData(0xebf1, fontFamily: _untitledFilledFamily);
  static const IconData kfileCode02w1 =
      IconData(0xebf2, fontFamily: _untitledFilledFamily);
  static const IconData kfolderCodew1 =
      IconData(0xebf3, fontFamily: _untitledFilledFamily);
  static const IconData kgitBranch01w1 =
      IconData(0xebf4, fontFamily: _untitledFilledFamily);
  static const IconData kgitBranch02w1 =
      IconData(0xebf5, fontFamily: _untitledFilledFamily);
  static const IconData kgitCommitw1 =
      IconData(0xebf6, fontFamily: _untitledFilledFamily);
  static const IconData kgitMergew1 =
      IconData(0xebf7, fontFamily: _untitledFilledFamily);
  static const IconData kgitPullRequestw1 =
      IconData(0xebf8, fontFamily: _untitledFilledFamily);
  static const IconData kpackagew1 =
      IconData(0xebf9, fontFamily: _untitledFilledFamily);
  static const IconData kpackageCheckw1 =
      IconData(0xebfa, fontFamily: _untitledFilledFamily);
  static const IconData kpackageMinus1w =
      IconData(0xebfb, fontFamily: _untitledFilledFamily);
  static const IconData kpackagePlw1us =
      IconData(0xebfc, fontFamily: _untitledFilledFamily);
  static const IconData kpackageSearchw1 =
      IconData(0xebfd, fontFamily: _untitledFilledFamily);
  static const IconData kpackageXw1 =
      IconData(0xebfe, fontFamily: _untitledFilledFamily);
  static const IconData kpuzzlePiece01w1 =
      IconData(0xebff, fontFamily: _untitledFilledFamily);
  static const IconData kpuzzlePiece02w1 =
      IconData(0xec00, fontFamily: _untitledFilledFamily);
  static const IconData kqrCode01w1 =
      IconData(0xec01, fontFamily: _untitledFilledFamily);
  static const IconData kqrCode02w1 =
      IconData(0xec02, fontFamily: _untitledFilledFamily);
  static const IconData kserver01w1 =
      IconData(0xec03, fontFamily: _untitledFilledFamily);
  static const IconData kserver02w1 =
      IconData(0xec04, fontFamily: _untitledFilledFamily);
  static const IconData kserver03w1 =
      IconData(0xec05, fontFamily: _untitledFilledFamily);
  static const IconData kserver04w1 =
      IconData(0xec06, fontFamily: _untitledFilledFamily);
  static const IconData kserver05w1 =
      IconData(0xec07, fontFamily: _untitledFilledFamily);
  static const IconData kserver06w1 =
      IconData(0xec08, fontFamily: _untitledFilledFamily);
  static const IconData kterminalw1 =
      IconData(0xec09, fontFamily: _untitledFilledFamily);
  static const IconData kterminalBrowserw1 =
      IconData(0xec0a, fontFamily: _untitledFilledFamily);
  static const IconData kterminalCirclew1 =
      IconData(0xec0b, fontFamily: _untitledFilledFamily);
  static const IconData kterminalSquarew1 =
      IconData(0xec0c, fontFamily: _untitledFilledFamily);
  static const IconData kvariablew1 =
      IconData(0xec0d, fontFamily: _untitledFilledFamily);
  static const IconData kannotationw1 =
      IconData(0xec0e, fontFamily: _untitledFilledFamily);
  static const IconData kannotationAlertw1 =
      IconData(0xec0f, fontFamily: _untitledFilledFamily);
  static const IconData kannotationCheckw1 =
      IconData(0xec10, fontFamily: _untitledFilledFamily);
  static const IconData kannotationDotsw1 =
      IconData(0xec11, fontFamily: _untitledFilledFamily);
  static const IconData kannotationHeartw1 =
      IconData(0xec12, fontFamily: _untitledFilledFamily);
  static const IconData kannotationInfow1 =
      IconData(0xec13, fontFamily: _untitledFilledFamily);
  static const IconData kannotationPlusw1 =
      IconData(0xec14, fontFamily: _untitledFilledFamily);
  static const IconData kannotationQuestionw1 =
      IconData(0xec15, fontFamily: _untitledFilledFamily);
  static const IconData kannotationXw1 =
      IconData(0xec16, fontFamily: _untitledFilledFamily);
  static const IconData kinbox01w1 =
      IconData(0xec17, fontFamily: _untitledFilledFamily);
  static const IconData kinbox02w1 =
      IconData(0xec18, fontFamily: _untitledFilledFamily);
  static const IconData kmail01w1 =
      IconData(0xec19, fontFamily: _untitledFilledFamily);
  static const IconData kmail02w1 =
      IconData(0xec1a, fontFamily: _untitledFilledFamily);
  static const IconData kmail03w1 =
      IconData(0xec1b, fontFamily: _untitledFilledFamily);
  static const IconData kmail04w1 =
      IconData(0xec1c, fontFamily: _untitledFilledFamily);
  static const IconData kmail05w1 =
      IconData(0xec1d, fontFamily: _untitledFilledFamily);
  static const IconData kmessageAlertCirclew1 =
      IconData(0xec1e, fontFamily: _untitledFilledFamily);
  static const IconData kmessageAlertSquarew1 =
      IconData(0xec1f, fontFamily: _untitledFilledFamily);
  static const IconData kmessageChatCirclew1 =
      IconData(0xec20, fontFamily: _untitledFilledFamily);
  static const IconData kmessageChatSquarew1 =
      IconData(0xec21, fontFamily: _untitledFilledFamily);
  static const IconData kmessageCheckCirclew1 =
      IconData(0xec22, fontFamily: _untitledFilledFamily);
  static const IconData kmessageCheckSquarew1 =
      IconData(0xec23, fontFamily: _untitledFilledFamily);
  static const IconData kmessageCircle01w1 =
      IconData(0xec24, fontFamily: _untitledFilledFamily);
  static const IconData kmessageCircle02w1 =
      IconData(0xec25, fontFamily: _untitledFilledFamily);
  static const IconData kmessageDotsCirclew1 =
      IconData(0xec26, fontFamily: _untitledFilledFamily);
  static const IconData kmessageDotsSquarew1 =
      IconData(0xec27, fontFamily: _untitledFilledFamily);
  static const IconData kmessageHeartCirclew1 =
      IconData(0xec28, fontFamily: _untitledFilledFamily);
  static const IconData kmessageHeartSquarew1 =
      IconData(0xec29, fontFamily: _untitledFilledFamily);
  static const IconData kmessageNotificw1ationCircle =
      IconData(0xec2a, fontFamily: _untitledFilledFamily);
  static const IconData kmessageNotificaw1tionSquare =
      IconData(0xec2b, fontFamily: _untitledFilledFamily);
  static const IconData kmessagePlusCw1ircle =
      IconData(0xec2c, fontFamily: _untitledFilledFamily);
  static const IconData kmessagePluw1sSquare =
      IconData(0xec2d, fontFamily: _untitledFilledFamily);
  static const IconData kmessageQuesw1tionCircle =
      IconData(0xec2e, fontFamily: _untitledFilledFamily);
  static const IconData kmessageQuw1estionSquare =
      IconData(0xec2f, fontFamily: _untitledFilledFamily);
  static const IconData kmessageSmw1ileCircle =
      IconData(0xec30, fontFamily: _untitledFilledFamily);
  static const IconData kmessageSmilew1Square =
      IconData(0xec31, fontFamily: _untitledFilledFamily);
  static const IconData kmessageSquarw1e01 =
      IconData(0xec32, fontFamily: _untitledFilledFamily);
  static const IconData kmessageSw1quare02 =
      IconData(0xec33, fontFamily: _untitledFilledFamily);
  static const IconData kmessageTextW1circle01 =
      IconData(0xec34, fontFamily: _untitledFilledFamily);
  static const IconData kmessageTextCw1ircle02 =
      IconData(0xec35, fontFamily: _untitledFilledFamily);
  static const IconData kmessageTextSqw1uare01 =
      IconData(0xec36, fontFamily: _untitledFilledFamily);
  static const IconData kmessageTextSw1quare02 =
      IconData(0xec37, fontFamily: _untitledFilledFamily);
  static const IconData kmessageXCirw1cle =
      IconData(0xec38, fontFamily: _untitledFilledFamily);
  static const IconData kmessageXSquaw1re =
      IconData(0xec39, fontFamily: _untitledFilledFamily);
  static const IconData kphonew1 =
      IconData(0xec3a, fontFamily: _untitledFilledFamily);
  static const IconData kphoneCall01w1 =
      IconData(0xec3b, fontFamily: _untitledFilledFamily);
  static const IconData kphoneCall02w1 =
      IconData(0xec3c, fontFamily: _untitledFilledFamily);
  static const IconData kphoneHangUpw1 =
      IconData(0xec3d, fontFamily: _untitledFilledFamily);
  static const IconData kphoneIncomingW101 =
      IconData(0xec3e, fontFamily: _untitledFilledFamily);
  static const IconData kphoneIncomingW102 =
      IconData(0xec3f, fontFamily: _untitledFilledFamily);
  static const IconData kphoneOutgoingw101 =
      IconData(0xec40, fontFamily: _untitledFilledFamily);
  static const IconData kphoneOutgoingw102 =
      IconData(0xec41, fontFamily: _untitledFilledFamily);
  static const IconData kphonePausew1 =
      IconData(0xec42, fontFamily: _untitledFilledFamily);
  static const IconData kphonePlusw1 =
      IconData(0xec43, fontFamily: _untitledFilledFamily);
  static const IconData kphoneXw1 =
      IconData(0xec44, fontFamily: _untitledFilledFamily);
  static const IconData ksend01w1 =
      IconData(0xec45, fontFamily: _untitledFilledFamily);
  static const IconData ksend02w1 =
      IconData(0xec46, fontFamily: _untitledFilledFamily);
  static const IconData ksend03w1 =
      IconData(0xec47, fontFamily: _untitledFilledFamily);
  static const IconData kbarChart10w1 =
      IconData(0xec48, fontFamily: _untitledFilledFamily);
  static const IconData kbarChart11w1 =
      IconData(0xec49, fontFamily: _untitledFilledFamily);
  static const IconData kbarChart12w1 =
      IconData(0xec4a, fontFamily: _untitledFilledFamily);
  static const IconData kbarChartCircle0w11 =
      IconData(0xec4b, fontFamily: _untitledFilledFamily);
  static const IconData kbarChartCircleW102 =
      IconData(0xec4c, fontFamily: _untitledFilledFamily);
  static const IconData kbarChartCircleW103 =
      IconData(0xec4d, fontFamily: _untitledFilledFamily);
  static const IconData kbarChartSquarew101 =
      IconData(0xec4e, fontFamily: _untitledFilledFamily);
  static const IconData kbarChartSquarew102 =
      IconData(0xec4f, fontFamily: _untitledFilledFamily);
  static const IconData kbarChartSquarew103 =
      IconData(0xec50, fontFamily: _untitledFilledFamily);
  static const IconData kbarChartSquarew1Down =
      IconData(0xec51, fontFamily: _untitledFilledFamily);
  static const IconData kbarChartSquarw1eMinus =
      IconData(0xec52, fontFamily: _untitledFilledFamily);
  static const IconData kbarChartSquaw1rePlus =
      IconData(0xec53, fontFamily: _untitledFilledFamily);
  static const IconData kbarChartSquarw1eUp =
      IconData(0xec54, fontFamily: _untitledFilledFamily);
  static const IconData kbarLineChartw1 =
      IconData(0xec55, fontFamily: _untitledFilledFamily);
  static const IconData kchartBreakoutw1Circle =
      IconData(0xec56, fontFamily: _untitledFilledFamily);
  static const IconData kchartBreakoutw1Square =
      IconData(0xec57, fontFamily: _untitledFilledFamily);
  static const IconData khorizontalBaw1rChart01 =
      IconData(0xec58, fontFamily: _untitledFilledFamily);
  static const IconData khorizontalBarCw1hart02 =
      IconData(0xec59, fontFamily: _untitledFilledFamily);
  static const IconData khorizontalBarCw1hart03 =
      IconData(0xec5a, fontFamily: _untitledFilledFamily);
  static const IconData klineChartDown01w1 =
      IconData(0xec5b, fontFamily: _untitledFilledFamily);
  static const IconData klineChartDown02w1 =
      IconData(0xec5c, fontFamily: _untitledFilledFamily);
  static const IconData klineChartDown03w1 =
      IconData(0xec5d, fontFamily: _untitledFilledFamily);
  static const IconData klineChartDown04w1 =
      IconData(0xec5e, fontFamily: _untitledFilledFamily);
  static const IconData klineChartDown05w1 =
      IconData(0xec5f, fontFamily: _untitledFilledFamily);
  static const IconData klineChartUp03w1 =
      IconData(0xec60, fontFamily: _untitledFilledFamily);
  static const IconData klineChartUp04w1 =
      IconData(0xec61, fontFamily: _untitledFilledFamily);
  static const IconData klineChartUp05w1 =
      IconData(0xec62, fontFamily: _untitledFilledFamily);
  static const IconData kpieChart01w1 =
      IconData(0xec63, fontFamily: _untitledFilledFamily);
  static const IconData kpieChart02w1 =
      IconData(0xec64, fontFamily: _untitledFilledFamily);
  static const IconData kpieChart03w1 =
      IconData(0xec65, fontFamily: _untitledFilledFamily);
  static const IconData kpieChart04w1 =
      IconData(0xec66, fontFamily: _untitledFilledFamily);
  static const IconData kpresentationChart01w1 =
      IconData(0xec67, fontFamily: _untitledFilledFamily);
  static const IconData kpresentationChart02w1 =
      IconData(0xec68, fontFamily: _untitledFilledFamily);
  static const IconData kpresentationChart03w1 =
      IconData(0xec69, fontFamily: _untitledFilledFamily);
  static const IconData karrowBlockDownw1 =
      IconData(0xec6a, fontFamily: _untitledFilledFamily);
  static const IconData karrowBlockLeftw1 =
      IconData(0xec6b, fontFamily: _untitledFilledFamily);
  static const IconData karrowBlockRightw1 =
      IconData(0xec6c, fontFamily: _untitledFilledFamily);
  static const IconData karrowBlockUpw1 =
      IconData(0xec6d, fontFamily: _untitledFilledFamily);
  static const IconData karrowCircleBrokenDownw1 =
      IconData(0xec6e, fontFamily: _untitledFilledFamily);
  static const IconData karrowCircleBrokenDownLeftw1 =
      IconData(0xec6f, fontFamily: _untitledFilledFamily);
  static const IconData karrowCircleBrokenDownRightw1 =
      IconData(0xec70, fontFamily: _untitledFilledFamily);
  static const IconData karrowCircleBrokenLeftw1 =
      IconData(0xec71, fontFamily: _untitledFilledFamily);
  static const IconData karrowCircleBrokenRightw1 =
      IconData(0xec72, fontFamily: _untitledFilledFamily);
  static const IconData karrowCircleBrokenUpw1 =
      IconData(0xec73, fontFamily: _untitledFilledFamily);
  static const IconData karrowCircleBrokenUpLeftw1 =
      IconData(0xec74, fontFamily: _untitledFilledFamily);
  static const IconData karrowCircleBrokenUpRightw1 =
      IconData(0xec75, fontFamily: _untitledFilledFamily);
  static const IconData karrowCircleDownw1 =
      IconData(0xec76, fontFamily: _untitledFilledFamily);
  static const IconData karrowCircleDownLeftw1 =
      IconData(0xec77, fontFamily: _untitledFilledFamily);
  static const IconData karrowCircleDownRightw1 =
      IconData(0xec78, fontFamily: _untitledFilledFamily);
  static const IconData karrowCircleLeftw1 =
      IconData(0xec79, fontFamily: _untitledFilledFamily);
  static const IconData karrowCircleRightw1 =
      IconData(0xec7a, fontFamily: _untitledFilledFamily);
  static const IconData karrowCircleUpw1 =
      IconData(0xec7b, fontFamily: _untitledFilledFamily);
  static const IconData karrowCircleUpLeftw1 =
      IconData(0xec7c, fontFamily: _untitledFilledFamily);
  static const IconData karrowCircleUpRightw1 =
      IconData(0xec7d, fontFamily: _untitledFilledFamily);
  static const IconData karrowSquareDownw1 =
      IconData(0xec7e, fontFamily: _untitledFilledFamily);
  static const IconData karrowSquareDownLeftw1 =
      IconData(0xec7f, fontFamily: _untitledFilledFamily);
  static const IconData karrowSquareDownRightw1 =
      IconData(0xec80, fontFamily: _untitledFilledFamily);
  static const IconData karrowSquareLeftw1 =
      IconData(0xec81, fontFamily: _untitledFilledFamily);
  static const IconData karrowSquareRightw1 =
      IconData(0xec82, fontFamily: _untitledFilledFamily);
  static const IconData karrowSquareUpw1 =
      IconData(0xec83, fontFamily: _untitledFilledFamily);
  static const IconData karrowSquareUpLeftw1 =
      IconData(0xec84, fontFamily: _untitledFilledFamily);
  static const IconData karrowSquareUpRightw1 =
      IconData(0xec85, fontFamily: _untitledFilledFamily);
  static const IconData kalertCirclew1 =
      IconData(0xec86, fontFamily: _untitledFilledFamily);
  static const IconData kalertHexagonw1 =
      IconData(0xec87, fontFamily: _untitledFilledFamily);
  static const IconData kalertOctagonw1 =
      IconData(0xec88, fontFamily: _untitledFilledFamily);
  static const IconData kalertSquarew1 =
      IconData(0xec89, fontFamily: _untitledFilledFamily);
  static const IconData kalertTrianglew1 =
      IconData(0xec8a, fontFamily: _untitledFilledFamily);
  static const IconData kannouncementW101 =
      IconData(0xec8b, fontFamily: _untitledFilledFamily);
  static const IconData kannouncementW102 =
      IconData(0xec8c, fontFamily: _untitledFilledFamily);
  static const IconData kannouncementw103 =
      IconData(0xec8d, fontFamily: _untitledFilledFamily);
  static const IconData kbell01w1 =
      IconData(0xec8e, fontFamily: _untitledFilledFamily);
  static const IconData kbell02w1 =
      IconData(0xec8f, fontFamily: _untitledFilledFamily);
  static const IconData kbell03w1 =
      IconData(0xec90, fontFamily: _untitledFilledFamily);
  static const IconData kbell04w1 =
      IconData(0xec91, fontFamily: _untitledFilledFamily);
  static const IconData kbellMinusw1 =
      IconData(0xec92, fontFamily: _untitledFilledFamily);
  static const IconData kbellOff01w1 =
      IconData(0xec93, fontFamily: _untitledFilledFamily);
  static const IconData kbellOff02w1 =
      IconData(0xec94, fontFamily: _untitledFilledFamily);
  static const IconData kbellOff03w1 =
      IconData(0xec95, fontFamily: _untitledFilledFamily);
  static const IconData kbellPlusw1w1 =
      IconData(0xec96, fontFamily: _untitledFilledFamily);
  static const IconData kbellRinging0ww111 =
      IconData(0xec97, fontFamily: _untitledFilledFamily);
  static const IconData kbellRinging02w1 =
      IconData(0xec98, fontFamily: _untitledFilledFamily);
  static const IconData kbellRingingw103 =
      IconData(0xec99, fontFamily: _untitledFilledFamily);
  static const IconData kbellRinging0w14 =
      IconData(0xec9a, fontFamily: _untitledFilledFamily);
  static const IconData knotificationBow1x =
      IconData(0xec9b, fontFamily: _untitledFilledFamily);
  static const IconData knotificationMessw1age =
      IconData(0xec9c, fontFamily: _untitledFilledFamily);
  static const IconData knotificationTew1xt =
      IconData(0xec9d, fontFamily: _untitledFilledFamily);
  static const IconData kthumbsDownw1 =
      IconData(0xec9e, fontFamily: _untitledFilledFamily);
  static const IconData kthumbsUpw1 =
      IconData(0xec9f, fontFamily: _untitledFilledFamily);

  // Close_icon
  static const IconData kcancel24dpFFFFFFFILL1Wght400GRAD0Opsz24 =
      IconData(0xe900, fontFamily: _closeIconFamily);

  // Crown_Diamond
  static const IconData kh3h34h5h =
      IconData(0xe900, fontFamily: _crownDiamondFamily);
  static const IconData kcrown3t5g3g =
      IconData(0xe901, fontFamily: _crownDiamondFamily);
}
