import 'dart:async';

import 'package:collection/collection.dart';

import '/backend/schema/util/firestore_util.dart';
import '/backend/schema/util/schema_util.dart';

import 'index.dart';
import '/flutter_flow/flutter_flow_util.dart';

class VerificationsRecord extends FirestoreRecord {
  VerificationsRecord._(
    DocumentReference reference,
    Map<String, dynamic> data,
  ) : super(reference, data) {
    _initializeFields();
  }

  // "userRef" field.
  DocumentReference? _userRef;
  DocumentReference? get userRef => _userRef;
  bool hasUserRef() => _userRef != null;

  // "status" field.
  String? _status;
  String get status => _status ?? '';
  bool hasStatus() => _status != null;

  // "submittedAt" field.
  DateTime? _submittedAt;
  DateTime? get submittedAt => _submittedAt;
  bool hasSubmittedAt() => _submittedAt != null;

  // "reviewedAt" field.
  DateTime? _reviewedAt;
  DateTime? get reviewedAt => _reviewedAt;
  bool hasReviewedAt() => _reviewedAt != null;

  // "reviewedBy" field.
  String? _reviewedBy;
  String get reviewedBy => _reviewedBy ?? '';
  bool hasReviewedBy() => _reviewedBy != null;

  // "selfieUrl" field.
  String? _selfieUrl;
  String get selfieUrl => _selfieUrl ?? '';
  bool hasSelfieUrl() => _selfieUrl != null;

  void _initializeFields() {
    _userRef = snapshotData['userRef'] as DocumentReference?;
    _status = snapshotData['status'] as String?;
    _submittedAt = snapshotData['submittedAt'] as DateTime?;
    _reviewedAt = snapshotData['reviewedAt'] as DateTime?;
    _reviewedBy = snapshotData['reviewedBy'] as String?;
    _selfieUrl = snapshotData['selfieUrl'] as String?;
  }

  static CollectionReference get collection =>
      FirebaseFirestore.instance.collection('verifications');

  static Stream<VerificationsRecord> getDocument(DocumentReference ref) =>
      ref.snapshots().map((s) => VerificationsRecord.fromSnapshot(s));

  static Future<VerificationsRecord> getDocumentOnce(DocumentReference ref) =>
      ref.get().then((s) => VerificationsRecord.fromSnapshot(s));

  static VerificationsRecord fromSnapshot(DocumentSnapshot snapshot) =>
      VerificationsRecord._(
        snapshot.reference,
        mapFromFirestore(snapshot.data() as Map<String, dynamic>),
      );

  static VerificationsRecord getDocumentFromData(
    Map<String, dynamic> data,
    DocumentReference reference,
  ) =>
      VerificationsRecord._(reference, mapFromFirestore(data));

  @override
  String toString() =>
      'VerificationsRecord(reference: ${reference.path}, data: $snapshotData)';

  @override
  int get hashCode => reference.path.hashCode;

  @override
  bool operator ==(other) =>
      other is VerificationsRecord &&
      reference.path.hashCode == other.reference.path.hashCode;
}

Map<String, dynamic> createVerificationsRecordData({
  DocumentReference? userRef,
  String? status,
  DateTime? submittedAt,
  DateTime? reviewedAt,
  String? reviewedBy,
  String? selfieUrl,
}) {
  final firestoreData = mapToFirestore(
    <String, dynamic>{
      'userRef': userRef,
      'status': status,
      'submittedAt': submittedAt,
      'reviewedAt': reviewedAt,
      'reviewedBy': reviewedBy,
      'selfieUrl': selfieUrl,
    }.withoutNulls,
  );

  return firestoreData;
}

class VerificationsRecordDocumentEquality
    implements Equality<VerificationsRecord> {
  const VerificationsRecordDocumentEquality();

  @override
  bool equals(VerificationsRecord? e1, VerificationsRecord? e2) {
    return e1?.userRef == e2?.userRef &&
        e1?.status == e2?.status &&
        e1?.submittedAt == e2?.submittedAt &&
        e1?.reviewedAt == e2?.reviewedAt &&
        e1?.reviewedBy == e2?.reviewedBy &&
        e1?.selfieUrl == e2?.selfieUrl;
  }

  @override
  int hash(VerificationsRecord? e) => const ListEquality().hash([
        e?.userRef,
        e?.status,
        e?.submittedAt,
        e?.reviewedAt,
        e?.reviewedBy,
        e?.selfieUrl
      ]);

  @override
  bool isValidKey(Object? o) => o is VerificationsRecord;
}
