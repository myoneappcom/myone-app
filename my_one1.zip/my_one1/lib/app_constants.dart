import 'package:flutter/material.dart';
import 'flutter_flow/flutter_flow_util.dart';

abstract class FFAppConstants {
  static const List<String> imgList = [
    'https://firebasestorage.googleapis.com/v0/b/datinger-e2bc1.appspot.com/o/French-models-Camille-Rowe.jpg?alt=media&token=0a35d27a-cc87-462c-958c-5918f3ccbf04',
    'https://firebasestorage.googleapis.com/v0/b/datinger-e2bc1.appspot.com/o/French-models-Prune-Pauchet.jpg?alt=media&token=cda6c4b7-5a3d-4a3f-8807-eae035d8103a',
    'https://firebasestorage.googleapis.com/v0/b/datinger-e2bc1.appspot.com/o/French-models-Ophelie-Guillermand.jpg?alt=media&token=3cada1e3-cfc7-441c-971f-b6fd992aa3f0'
  ];
  static const List<int> SimpleList = [0, 1, 2, 3, 4, 5];
  static const List<int> NumberOfPhotos = [1, 2, 3, 4, 5, 6];
  static const List<String> ShowMe = ['Men', 'Women'];
  static const List<String> Languages = [
    'English',
    'Spanish',
    'French',
    'Russian',
    'Portuguese',
    'Standard Arabic',
    'Hindi',
    'Mandarin Chinese',
    'Japanese',
    'Punjabi',
    'Urdu',
    'Danish',
    'Romanian',
    'Greek',
    'Ukranian',
    'Slovak',
    'Norwegian',
    'Italian',
    'Polish'
  ];
  static const List<String> Education = [
    'High School',
    'Bachelors',
    'Masters',
    'PhD',
    'Trade School',
    'Other'
  ];
  static const List<String> FamilyPlans = [
    'Want Kids',
    'Don\'t want kids',
    'Not sure yet'
  ];
  static const List<String> Workout = [
    'Everyday',
    'Often',
    'Sometimes',
    'Never'
  ];
  static const List<String> LikesFilters = [
    'Newest',
    'Nearby',
    'Verified',
    'Recently active'
  ];
  static const List<String> ReportList = [
    '🚫 Spam or Scam',
    '🗣️ Harassment',
    '🔞 Inappropriate Content',
    '👤 Fake Profile',
    '👶 Underage User',
    '❓ Other'
  ];
}
