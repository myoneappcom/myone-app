import 'package:flutter/material.dart';
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:csv/csv.dart';
import 'package:synchronized/synchronized.dart';
import 'flutter_flow/flutter_flow_util.dart';

class FFAppState extends ChangeNotifier {
  static FFAppState _instance = FFAppState._internal();

  factory FFAppState() {
    return _instance;
  }

  FFAppState._internal();

  static void reset() {
    _instance = FFAppState._internal();
  }

  Future initializePersistedState() async {
    secureStorage = FlutterSecureStorage();
    await _safeInitAsync(() async {
      _Languages = (await secureStorage.getStringList('ff_Languages'))
              ?.map((x) {
                try {
                  return LanguagesStruct.fromSerializableMap(jsonDecode(x));
                } catch (e) {
                  print("Can't decode persisted data type. Error: $e.");
                  return null;
                }
              })
              .withoutNulls
              .toList() ??
          _Languages;
    });
    await _safeInitAsync(() async {
      _categories = (await secureStorage.getStringList('ff_categories'))
              ?.map((x) {
                try {
                  return CategoryStruct.fromSerializableMap(jsonDecode(x));
                } catch (e) {
                  print("Can't decode persisted data type. Error: $e.");
                  return null;
                }
              })
              .withoutNulls
              .toList() ??
          _categories;
    });
  }

  void update(VoidCallback callback) {
    callback();
    notifyListeners();
  }

  late FlutterSecureStorage secureStorage;

  bool _AutoUpdate = false;
  bool get AutoUpdate => _AutoUpdate;
  set AutoUpdate(bool value) {
    _AutoUpdate = value;
  }

  double _start = 0.0;
  double get start => _start;
  set start(double value) {
    _start = value;
  }

  double _end = 60.0;
  double get end => _end;
  set end(double value) {
    _end = value;
  }

  int _MatchesTab = 0;
  int get MatchesTab => _MatchesTab;
  set MatchesTab(int value) {
    _MatchesTab = value;
  }

  int _distance = 0;
  int get distance => _distance;
  set distance(int value) {
    _distance = value;
  }

  List<LanguagesStruct> _Languages = [
    LanguagesStruct.fromSerializableMap(jsonDecode(
        '{\"img\":\"https://firebasestorage.googleapis.com/v0/b/datinger-e2bc1.appspot.com/o/image_2024-09-03_21-04-31.png?alt=media&token=7d727615-4daa-4fce-8311-aaf932e7d6e8\",\"title\":\"English (US)\"}')),
    LanguagesStruct.fromSerializableMap(jsonDecode(
        '{\"img\":\"https://firebasestorage.googleapis.com/v0/b/datinger-e2bc1.appspot.com/o/image_2024-09-03_21-04-49.png?alt=media&token=86fc3a2f-af7c-4e79-a425-db3595894a77\",\"title\":\"English (UK)\"}')),
    LanguagesStruct.fromSerializableMap(jsonDecode(
        '{\"img\":\"https://firebasestorage.googleapis.com/v0/b/datinger-e2bc1.appspot.com/o/image_2024-09-03_21-05-05.png?alt=media&token=e8fc1ae4-4060-4c53-9452-17d8825120c5\",\"title\":\"Mandarin\"}')),
    LanguagesStruct.fromSerializableMap(jsonDecode(
        '{\"img\":\"https://firebasestorage.googleapis.com/v0/b/datinger-e2bc1.appspot.com/o/image_2024-09-03_21-05-19.png?alt=media&token=240aff33-6e71-4cd7-97ba-12810162bfb5\",\"title\":\"Spanish\"}')),
    LanguagesStruct.fromSerializableMap(jsonDecode(
        '{\"img\":\"https://firebasestorage.googleapis.com/v0/b/datinger-e2bc1.appspot.com/o/image_2024-09-03_21-05-36.png?alt=media&token=67367c11-1ce1-48cf-8dfb-52bc78a2e11b\",\"title\":\"Hindi\"}')),
    LanguagesStruct.fromSerializableMap(jsonDecode(
        '{\"img\":\"https://firebasestorage.googleapis.com/v0/b/datinger-e2bc1.appspot.com/o/image_2024-09-03_21-05-51.png?alt=media&token=df7d997f-7081-45bf-8f35-f2c4b904c4b8\",\"title\":\"French\"}')),
    LanguagesStruct.fromSerializableMap(jsonDecode(
        '{\"img\":\"https://firebasestorage.googleapis.com/v0/b/datinger-e2bc1.appspot.com/o/image_2024-09-03_21-06-11.png?alt=media&token=413da6b3-a070-4229-9632-a04b70e78eb1\",\"title\":\"Arabic\"}')),
    LanguagesStruct.fromSerializableMap(jsonDecode(
        '{\"img\":\"https://firebasestorage.googleapis.com/v0/b/datinger-e2bc1.appspot.com/o/image_2024-09-03_21-06-29.png?alt=media&token=45713e7e-7258-4c8d-b912-23d35d9902b8\",\"title\":\"Russian\"}')),
    LanguagesStruct.fromSerializableMap(jsonDecode(
        '{\"img\":\"https://firebasestorage.googleapis.com/v0/b/datinger-e2bc1.appspot.com/o/image_2024-09-03_21-06-45.png?alt=media&token=7188e698-9ec0-4f9b-b85d-9ed137e1c81c\",\"title\":\"Japanese\"}'))
  ];
  List<LanguagesStruct> get Languages => _Languages;
  set Languages(List<LanguagesStruct> value) {
    _Languages = value;
    secureStorage.setStringList(
        'ff_Languages', value.map((x) => x.serialize()).toList());
  }

  void deleteLanguages() {
    secureStorage.delete(key: 'ff_Languages');
  }

  void addToLanguages(LanguagesStruct value) {
    Languages.add(value);
    secureStorage.setStringList(
        'ff_Languages', _Languages.map((x) => x.serialize()).toList());
  }

  void removeFromLanguages(LanguagesStruct value) {
    Languages.remove(value);
    secureStorage.setStringList(
        'ff_Languages', _Languages.map((x) => x.serialize()).toList());
  }

  void removeAtIndexFromLanguages(int index) {
    Languages.removeAt(index);
    secureStorage.setStringList(
        'ff_Languages', _Languages.map((x) => x.serialize()).toList());
  }

  void updateLanguagesAtIndex(
    int index,
    LanguagesStruct Function(LanguagesStruct) updateFn,
  ) {
    Languages[index] = updateFn(_Languages[index]);
    secureStorage.setStringList(
        'ff_Languages', _Languages.map((x) => x.serialize()).toList());
  }

  void insertAtIndexInLanguages(int index, LanguagesStruct value) {
    Languages.insert(index, value);
    secureStorage.setStringList(
        'ff_Languages', _Languages.map((x) => x.serialize()).toList());
  }

  List<String> _chatMessages = [];
  List<String> get chatMessages => _chatMessages;
  set chatMessages(List<String> value) {
    _chatMessages = value;
  }

  void addToChatMessages(String value) {
    chatMessages.add(value);
  }

  void removeFromChatMessages(String value) {
    chatMessages.remove(value);
  }

  void removeAtIndexFromChatMessages(int index) {
    chatMessages.removeAt(index);
  }

  void updateChatMessagesAtIndex(
    int index,
    String Function(String) updateFn,
  ) {
    chatMessages[index] = updateFn(_chatMessages[index]);
  }

  void insertAtIndexInChatMessages(int index, String value) {
    chatMessages.insert(index, value);
  }

  List<CategoryStruct> _categories = [];
  List<CategoryStruct> get categories => _categories;
  set categories(List<CategoryStruct> value) {
    _categories = value;
    secureStorage.setStringList(
        'ff_categories', value.map((x) => x.serialize()).toList());
  }

  void deleteCategories() {
    secureStorage.delete(key: 'ff_categories');
  }

  void addToCategories(CategoryStruct value) {
    categories.add(value);
    secureStorage.setStringList(
        'ff_categories', _categories.map((x) => x.serialize()).toList());
  }

  void removeFromCategories(CategoryStruct value) {
    categories.remove(value);
    secureStorage.setStringList(
        'ff_categories', _categories.map((x) => x.serialize()).toList());
  }

  void removeAtIndexFromCategories(int index) {
    categories.removeAt(index);
    secureStorage.setStringList(
        'ff_categories', _categories.map((x) => x.serialize()).toList());
  }

  void updateCategoriesAtIndex(
    int index,
    CategoryStruct Function(CategoryStruct) updateFn,
  ) {
    categories[index] = updateFn(_categories[index]);
    secureStorage.setStringList(
        'ff_categories', _categories.map((x) => x.serialize()).toList());
  }

  void insertAtIndexInCategories(int index, CategoryStruct value) {
    categories.insert(index, value);
    secureStorage.setStringList(
        'ff_categories', _categories.map((x) => x.serialize()).toList());
  }

  bool _ThemeSystem = false;
  bool get ThemeSystem => _ThemeSystem;
  set ThemeSystem(bool value) {
    _ThemeSystem = value;
  }

  bool _ProfileView = false;
  bool get ProfileView => _ProfileView;
  set ProfileView(bool value) {
    _ProfileView = value;
  }

  int _Boosts = 1;
  int get Boosts => _Boosts;
  set Boosts(int value) {
    _Boosts = value;
  }

  String _LikesFiltersSelected = 'Newest';
  String get LikesFiltersSelected => _LikesFiltersSelected;
  set LikesFiltersSelected(String value) {
    _LikesFiltersSelected = value;
  }

  String _SelectedReport = '🚫 Spam or Scam';
  String get SelectedReport => _SelectedReport;
  set SelectedReport(String value) {
    _SelectedReport = value;
  }

  int _userAge = 0;
  int get userAge => _userAge;
  set userAge(int value) {
    _userAge = value;
  }

  bool _ShoosenGender = false;
  bool get ShoosenGender => _ShoosenGender;
  set ShoosenGender(bool value) {
    _ShoosenGender = value;
  }

  int _Thememode = 0;
  int get Thememode => _Thememode;
  set Thememode(int value) {
    _Thememode = value;
  }

  bool _LocationEnabled = false;
  bool get LocationEnabled => _LocationEnabled;
  set LocationEnabled(bool value) {
    _LocationEnabled = value;
  }

  bool _NotificationsEnabled = false;
  bool get NotificationsEnabled => _NotificationsEnabled;
  set NotificationsEnabled(bool value) {
    _NotificationsEnabled = value;
  }

  ///
  ///
  String _photoUrl = '';
  String get photoUrl => _photoUrl;
  set photoUrl(String value) {
    _photoUrl = value;
  }
}

void _safeInit(Function() initializeField) {
  try {
    initializeField();
  } catch (_) {}
}

Future _safeInitAsync(Function() initializeField) async {
  try {
    await initializeField();
  } catch (_) {}
}

extension FlutterSecureStorageExtensions on FlutterSecureStorage {
  static final _lock = Lock();

  Future<void> writeSync({required String key, String? value}) async =>
      await _lock.synchronized(() async {
        await write(key: key, value: value);
      });

  void remove(String key) => delete(key: key);

  Future<String?> getString(String key) async => await read(key: key);
  Future<void> setString(String key, String value) async =>
      await writeSync(key: key, value: value);

  Future<bool?> getBool(String key) async => (await read(key: key)) == 'true';
  Future<void> setBool(String key, bool value) async =>
      await writeSync(key: key, value: value.toString());

  Future<int?> getInt(String key) async =>
      int.tryParse(await read(key: key) ?? '');
  Future<void> setInt(String key, int value) async =>
      await writeSync(key: key, value: value.toString());

  Future<double?> getDouble(String key) async =>
      double.tryParse(await read(key: key) ?? '');
  Future<void> setDouble(String key, double value) async =>
      await writeSync(key: key, value: value.toString());

  Future<List<String>?> getStringList(String key) async =>
      await read(key: key).then((result) {
        if (result == null || result.isEmpty) {
          return null;
        }
        return CsvToListConverter()
            .convert(result)
            .first
            .map((e) => e.toString())
            .toList();
      });
  Future<void> setStringList(String key, List<String> value) async =>
      await writeSync(key: key, value: ListToCsvConverter().convert([value]));
}
